export class MxGalleryImageContent {
    public content: String;
    public display_on_gallery: boolean = false;
}
