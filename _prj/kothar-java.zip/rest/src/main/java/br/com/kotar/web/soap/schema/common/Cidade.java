//
// Este arquivo foi gerado pela Arquitetura JavaTM para Implementação de Referência (JAXB) de Bind XML, v2.2.7 
// Consulte <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Todas as modificações neste arquivo serão perdidas após a recompilação do esquema de origem. 
// Gerado em: 2017.11.16 às 08:40:07 AM BRST 
//


package br.com.kotar.web.soap.schema.common;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java de cidade complex type.
 * 
 * <p>O seguinte fragmento do esquema especifica o conteúdo esperado contido dentro desta classe.
 * 
 * <pre>
 * &lt;complexType name="cidade">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="cidade_nome" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="cidade_estado" type="{http://kotar.com.br/web/soap/schema/common}estado"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "cidade", propOrder = {
    "cidadeNome",
    "cidadeEstado"
})
public class Cidade {

    @XmlElement(name = "cidade_nome", required = true)
    protected String cidadeNome;
    @XmlElement(name = "cidade_estado", required = true)
    protected Estado cidadeEstado;

    /**
     * Obtém o valor da propriedade cidadeNome.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCidadeNome() {
        return cidadeNome;
    }

    /**
     * Define o valor da propriedade cidadeNome.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCidadeNome(String value) {
        this.cidadeNome = value;
    }

    /**
     * Obtém o valor da propriedade cidadeEstado.
     * 
     * @return
     *     possible object is
     *     {@link Estado }
     *     
     */
    public Estado getCidadeEstado() {
        return cidadeEstado;
    }

    /**
     * Define o valor da propriedade cidadeEstado.
     * 
     * @param value
     *     allowed object is
     *     {@link Estado }
     *     
     */
    public void setCidadeEstado(Estado value) {
        this.cidadeEstado = value;
    }

}
