//
// Este arquivo foi gerado pela Arquitetura JavaTM para Implementação de Referência (JAXB) de Bind XML, v2.2.7 
// Consulte <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Todas as modificações neste arquivo serão perdidas após a recompilação do esquema de origem. 
// Gerado em: 2017.11.16 às 08:40:07 AM BRST 
//


package br.com.kotar.web.soap.schema.common;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java de bairro complex type.
 * 
 * <p>O seguinte fragmento do esquema especifica o conteúdo esperado contido dentro desta classe.
 * 
 * <pre>
 * &lt;complexType name="bairro">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="bairro_nome" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="bairro_cidade" type="{http://kotar.com.br/web/soap/schema/common}cidade"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "bairro", propOrder = {
    "bairroNome",
    "bairroCidade"
})
public class Bairro {

    @XmlElement(name = "bairro_nome", required = true)
    protected String bairroNome;
    @XmlElement(name = "bairro_cidade", required = true)
    protected Cidade bairroCidade;

    /**
     * Obtém o valor da propriedade bairroNome.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBairroNome() {
        return bairroNome;
    }

    /**
     * Define o valor da propriedade bairroNome.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBairroNome(String value) {
        this.bairroNome = value;
    }

    /**
     * Obtém o valor da propriedade bairroCidade.
     * 
     * @return
     *     possible object is
     *     {@link Cidade }
     *     
     */
    public Cidade getBairroCidade() {
        return bairroCidade;
    }

    /**
     * Define o valor da propriedade bairroCidade.
     * 
     * @param value
     *     allowed object is
     *     {@link Cidade }
     *     
     */
    public void setBairroCidade(Cidade value) {
        this.bairroCidade = value;
    }

}
