package br.com.kotar.web.controller.publico;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import br.com.kotar.core.component.Messages;
import br.com.kotar.core.helper.email.EmailHelper;
import br.com.kotar.core.helper.response.ResponseHelper;
import br.com.kotar.core.util.StringUtil;
import br.com.kotar.domain.security.Usuario;
import br.com.kotar.web.service.UsuarioService;
import br.com.kotar.web.service.email.EmailService;

@RestController
@RequestMapping(value = { "/api/esquecisenha" })
public class EsqueciSenhaController {

	//@formatter:off
	@Autowired UsuarioService usuarioService;
	@Autowired Messages messages;
	@Autowired EmailService emailService;
	//@formatter:on

	@RequestMapping(value = "/enviar", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseHelper<Usuario>> resetPassword(@RequestBody Usuario domain) throws Exception {

		Usuario usuario = usuarioService.findByEmail(domain.getEmail());

		if (usuario != null) {
			String resetToken = StringUtil.generateRandString(12);

			usuario.setResetToken(resetToken);
			usuario.setDateResetToken(new Date());

			usuarioService.saveOrUpdate(usuario);

			EmailHelper emailHelper = new EmailHelper();

			String corpo = EmailHelper.getCorpoBase();

			//@formatter:off
			corpo = corpo.replace(":P_CONTEUDO",
					" Olá, este email foi solicitado pelo APP Kothar para redefinir a senha de seu usuário.<br>" + 
							"<br>" + 
							"Clique no link abaixo para redefinir sua senha:<br>" + 
							"<a href=http://www.kothar.com.br/reset?email&" + resetToken+ ">" + 
							"http://www.kothar.com.br/reset?email&" + resetToken + "" + 
							"</a>");
			//@formatter:on

			emailHelper.setCorpo(corpo);

			emailHelper.setPara(usuario.getEmail());
			emailHelper.setAssunto("Kothar - Redefinição de Senha");
			emailHelper.setCaminhoImagem("/static/cabecalho_email_kothar.png");
			emailHelper.setNomeEnvio("Suporte Kothar");
			emailService.sendEmail(emailHelper);

		} else {
			String message = messages.get("cliente.email.inexistente");
			return new ResponseEntity<ResponseHelper<Usuario>>(new ResponseHelper<Usuario>(message), HttpStatus.EXPECTATION_FAILED);
		}

		return new ResponseEntity<ResponseHelper<Usuario>>(new ResponseHelper<Usuario>(new Usuario()), HttpStatus.OK);
	}

}
