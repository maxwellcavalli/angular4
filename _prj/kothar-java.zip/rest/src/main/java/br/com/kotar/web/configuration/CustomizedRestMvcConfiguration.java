package br.com.kotar.web.configuration;

import org.springframework.data.rest.webmvc.config.RepositoryRestMvcConfiguration;

//@Configuration
public class CustomizedRestMvcConfiguration extends RepositoryRestMvcConfiguration {

//	@Override
//	public RepositoryRestConfiguration config() {
//		RepositoryRestConfiguration config = super.config();
//		config.setBasePath("/apiRepository");
//		return config;
//	}
}