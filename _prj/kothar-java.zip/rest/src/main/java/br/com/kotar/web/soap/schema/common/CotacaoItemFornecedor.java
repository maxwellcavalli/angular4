//
// Este arquivo foi gerado pela Arquitetura JavaTM para Implementação de Referência (JAXB) de Bind XML, v2.2.7 
// Consulte <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Todas as modificações neste arquivo serão perdidas após a recompilação do esquema de origem. 
// Gerado em: 2017.11.16 às 08:40:07 AM BRST 
//


package br.com.kotar.web.soap.schema.common;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java de cotacaoItemFornecedor complex type.
 * 
 * <p>O seguinte fragmento do esquema especifica o conteúdo esperado contido dentro desta classe.
 * 
 * <pre>
 * &lt;complexType name="cotacaoItemFornecedor">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="cotacaoItem" type="{http://kotar.com.br/web/soap/schema/common}cotacaoItem"/>
 *         &lt;element name="valor_unitario" type="{http://www.w3.org/2001/XMLSchema}double"/>
 *         &lt;element name="marca_modelo" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "cotacaoItemFornecedor", propOrder = {
    "cotacaoItem",
    "valorUnitario",
    "marcaModelo"
})
public class CotacaoItemFornecedor {

    @XmlElement(required = true)
    protected CotacaoItem cotacaoItem;
    @XmlElement(name = "valor_unitario")
    protected double valorUnitario;
    @XmlElement(name = "marca_modelo", required = true)
    protected String marcaModelo;

    /**
     * Obtém o valor da propriedade cotacaoItem.
     * 
     * @return
     *     possible object is
     *     {@link CotacaoItem }
     *     
     */
    public CotacaoItem getCotacaoItem() {
        return cotacaoItem;
    }

    /**
     * Define o valor da propriedade cotacaoItem.
     * 
     * @param value
     *     allowed object is
     *     {@link CotacaoItem }
     *     
     */
    public void setCotacaoItem(CotacaoItem value) {
        this.cotacaoItem = value;
    }

    /**
     * Obtém o valor da propriedade valorUnitario.
     * 
     */
    public double getValorUnitario() {
        return valorUnitario;
    }

    /**
     * Define o valor da propriedade valorUnitario.
     * 
     */
    public void setValorUnitario(double value) {
        this.valorUnitario = value;
    }

    /**
     * Obtém o valor da propriedade marcaModelo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMarcaModelo() {
        return marcaModelo;
    }

    /**
     * Define o valor da propriedade marcaModelo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMarcaModelo(String value) {
        this.marcaModelo = value;
    }

}
