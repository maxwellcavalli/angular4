//
// Este arquivo foi gerado pela Arquitetura JavaTM para Implementação de Referência (JAXB) de Bind XML, v2.2.7 
// Consulte <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Todas as modificações neste arquivo serão perdidas após a recompilação do esquema de origem. 
// Gerado em: 2017.11.16 às 08:40:07 AM BRST 
//


package br.com.kotar.web.soap.schema.produto;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import br.com.kotar.web.soap.schema.common.ProdutoFoto;


/**
 * <p>Classe Java de anonymous complex type.
 * 
 * <p>O seguinte fragmento do esquema especifica o conteúdo esperado contido dentro desta classe.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="nome" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="detalhamento" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="foto" type="{http://kotar.com.br/web/soap/schema/common}produtoFoto" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="precoUnitario" type="{http://www.w3.org/2001/XMLSchema}double"/>
 *         &lt;element name="uuidFornecedor" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="identificador" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="token" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "nome",
    "detalhamento",
    "foto",
    "precoUnitario",
    "uuidFornecedor",
    "identificador",
    "token"
})
@XmlRootElement(name = "persistirProdutoRequest")
public class PersistirProdutoRequest {

    @XmlElement(required = true)
    protected String nome;
    @XmlElement(required = true)
    protected String detalhamento;
    protected List<ProdutoFoto> foto;
    protected double precoUnitario;
    @XmlElement(required = true)
    protected String uuidFornecedor;
    @XmlElement(required = true)
    protected String identificador;
    @XmlElement(required = true)
    protected String token;

    /**
     * Obtém o valor da propriedade nome.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNome() {
        return nome;
    }

    /**
     * Define o valor da propriedade nome.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNome(String value) {
        this.nome = value;
    }

    /**
     * Obtém o valor da propriedade detalhamento.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDetalhamento() {
        return detalhamento;
    }

    /**
     * Define o valor da propriedade detalhamento.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDetalhamento(String value) {
        this.detalhamento = value;
    }

    /**
     * Gets the value of the foto property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the foto property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getFoto().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ProdutoFoto }
     * 
     * 
     */
    public List<ProdutoFoto> getFoto() {
        if (foto == null) {
            foto = new ArrayList<ProdutoFoto>();
        }
        return this.foto;
    }

    /**
     * Obtém o valor da propriedade precoUnitario.
     * 
     */
    public double getPrecoUnitario() {
        return precoUnitario;
    }

    /**
     * Define o valor da propriedade precoUnitario.
     * 
     */
    public void setPrecoUnitario(double value) {
        this.precoUnitario = value;
    }

    /**
     * Obtém o valor da propriedade uuidFornecedor.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUuidFornecedor() {
        return uuidFornecedor;
    }

    /**
     * Define o valor da propriedade uuidFornecedor.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUuidFornecedor(String value) {
        this.uuidFornecedor = value;
    }

    /**
     * Obtém o valor da propriedade identificador.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdentificador() {
        return identificador;
    }

    /**
     * Define o valor da propriedade identificador.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdentificador(String value) {
        this.identificador = value;
    }

    /**
     * Obtém o valor da propriedade token.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getToken() {
        return token;
    }

    /**
     * Define o valor da propriedade token.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setToken(String value) {
        this.token = value;
    }

}
