package br.com.kotar.web.repository;

import br.com.kotar.core.repository.BaseRepository;
import br.com.kotar.domain.business.CotacaoEndereco;

public interface CotacaoEnderecoRepository extends BaseRepository<CotacaoEndereco> {

	//@formatter:off

	//@formatter:on
}