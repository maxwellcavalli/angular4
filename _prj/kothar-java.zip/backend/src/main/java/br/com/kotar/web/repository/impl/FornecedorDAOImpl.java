package br.com.kotar.web.repository.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import br.com.kotar.core.repository.CrudRepository;
import br.com.kotar.core.repository.impl.BaseCrudRepositoryImpl;
import br.com.kotar.domain.business.Cliente;
import br.com.kotar.domain.business.Fornecedor;
import br.com.kotar.domain.business.GrupoProduto;
import br.com.kotar.domain.security.Usuario;
import br.com.kotar.web.repository.FornecedorRepository;
import br.com.kotar.web.service.ClienteService;

@Service
@Transactional(propagation = Propagation.REQUIRED)
public class FornecedorDAOImpl extends BaseCrudRepositoryImpl<Fornecedor> implements FornecedorRepository {
	
	//@formatter:off
	@Autowired FornecedorRepository fornecedorRepository;
	@Autowired ClienteService clienteService;
	//@formatter:on
	
	@Override
	public CrudRepository<Fornecedor> getRepository() {
		return fornecedorRepository;
	}

	public Page<Fornecedor> findByNomeOrCpfCnpjLikeIgnoreCase(String nome, String cpfCnpj, 
			Usuario usuario, Pageable pageable) throws Exception {
		
		StringBuilder hql = new StringBuilder();
		hql.append(" select fornecedor ");
		hql.append("   from Fornecedor fornecedor ");
		hql.append("  inner join fetch fornecedor.cep cep ");
		hql.append("  inner join fetch cep.bairro bairro ");
		hql.append("  inner join fetch bairro.cidade cidade ");
		hql.append("  inner join fetch cidade.estado estado ");
		hql.append("   left join fetch fornecedor.enderecoComplemento ");			
		hql.append("  where 1 = 1 ");

		Map<String, Object> parameters = new HashMap<>();
		if (nome != null && !nome.trim().isEmpty()){
			hql.append("    and upper(fornecedor.nome) like upper(:nome) ");
			parameters.put("nome", nome);			
		}
		
		if (cpfCnpj != null && !cpfCnpj.trim().isEmpty()){
			hql.append("    and upper(fornecedor.cpfCnpj) = (:cpfCnpj) ");
			parameters.put("cpfCnpj", cpfCnpj);			
		}
		
		if (!usuario.isAdmin()){
			Cliente cliente = clienteService.findByUsuario(usuario);
			
			if (cliente == null){
				if (cliente == null) {
					throw new Exception(messages.get("fornecedor.not.agent.login"));
				}
			}
			
			
			hql.append(" and exists (select 1 ");
			hql.append("               from ClienteFornecedor clienteFornecedor ");
			hql.append("              where clienteFornecedor.fornecedor = fornecedor ");
			hql.append("                and clienteFornecedor.cliente = :cliente) ");
			
			parameters.put("cliente", cliente);
		}
		
		return searchPaginated(hql.toString(), pageable, parameters);
	}
	
	public List<Fornecedor> findByGrupoProduto(GrupoProduto grupoProduto) throws Exception {
		StringBuilder hql = new StringBuilder();
		hql.append(" select fornecedor ");
		hql.append("   from Fornecedor fornecedor ");
		hql.append("  where exists (select 1 ");
		hql.append("                  from FornecedorGrupoProduto fornecedorGrupoProduto "); 
		hql.append("                 where fornecedorGrupoProduto.fornecedor = fornecedor ");
		hql.append("                   and fornecedorGrupoProduto.grupoProduto = :grupoProduto ");
		hql.append("                    and not exists (select 1");
		hql.append("                                      from FornecedorIgnoreProduto fornecedorIgnoreProduto ");
		hql.append("                                      where fornecedorIgnoreProduto.produto.grupoProduto = fornecedorGrupoProduto.grupoProduto ))");
		
		Map<String, Object> parameters = new HashMap<>();
		parameters.put("grupoProduto", grupoProduto);
		
		return search(hql.toString(), Integer.MAX_VALUE, 0, parameters);
	}

	@Override
	public List<Fornecedor> findByCliente(Cliente cliente) {
		return fornecedorRepository.findByCliente(cliente);
	}

	@Override
	public Fornecedor findByUuid(String uuid) {
		return fornecedorRepository.findByUuid(uuid);
	}
	
}
