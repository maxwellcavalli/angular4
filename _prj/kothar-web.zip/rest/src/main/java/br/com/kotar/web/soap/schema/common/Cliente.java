//
// Este arquivo foi gerado pela Arquitetura JavaTM para Implementação de Referência (JAXB) de Bind XML, v2.2.7 
// Consulte <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Todas as modificações neste arquivo serão perdidas após a recompilação do esquema de origem. 
// Gerado em: 2017.12.08 às 11:08:30 AM BRST 
//


package br.com.kotar.web.soap.schema.common;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java de cliente complex type.
 * 
 * <p>O seguinte fragmento do esquema especifica o conteúdo esperado contido dentro desta classe.
 * 
 * <pre>
 * &lt;complexType name="cliente">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="cliente_id" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="cliente_nome" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="cpf" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "cliente", propOrder = {
    "clienteId",
    "clienteNome",
    "cpf"
})
public class Cliente {

    @XmlElement(name = "cliente_id")
    protected long clienteId;
    @XmlElement(name = "cliente_nome", required = true)
    protected String clienteNome;
    @XmlElement(required = true)
    protected String cpf;

    /**
     * Obtém o valor da propriedade clienteId.
     * 
     */
    public long getClienteId() {
        return clienteId;
    }

    /**
     * Define o valor da propriedade clienteId.
     * 
     */
    public void setClienteId(long value) {
        this.clienteId = value;
    }

    /**
     * Obtém o valor da propriedade clienteNome.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClienteNome() {
        return clienteNome;
    }

    /**
     * Define o valor da propriedade clienteNome.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClienteNome(String value) {
        this.clienteNome = value;
    }

    /**
     * Obtém o valor da propriedade cpf.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCpf() {
        return cpf;
    }

    /**
     * Define o valor da propriedade cpf.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCpf(String value) {
        this.cpf = value;
    }

}
