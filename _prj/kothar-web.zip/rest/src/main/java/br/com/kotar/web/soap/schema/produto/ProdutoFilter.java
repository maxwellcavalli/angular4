//
// Este arquivo foi gerado pela Arquitetura JavaTM para Implementação de Referência (JAXB) de Bind XML, v2.2.7 
// Consulte <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Todas as modificações neste arquivo serão perdidas após a recompilação do esquema de origem. 
// Gerado em: 2017.11.23 às 11:34:09 AM BRST 
//


package br.com.kotar.web.soap.schema.produto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import br.com.kotar.web.soap.schema.common.Pageable;


/**
 * <p>Classe Java de produtoFilter complex type.
 * 
 * <p>O seguinte fragmento do esquema especifica o conteúdo esperado contido dentro desta classe.
 * 
 * <pre>
 * &lt;complexType name="produtoFilter">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="nome" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="pageable" type="{http://kotar.com.br/web/soap/schema/common}pageable"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "produtoFilter", propOrder = {
    "nome",
    "pageable"
})
public class ProdutoFilter {

    @XmlElement(required = true)
    protected String nome;
    @XmlElement(required = true)
    protected Pageable pageable;

    /**
     * Obtém o valor da propriedade nome.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNome() {
        return nome;
    }

    /**
     * Define o valor da propriedade nome.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNome(String value) {
        this.nome = value;
    }

    /**
     * Obtém o valor da propriedade pageable.
     * 
     * @return
     *     possible object is
     *     {@link Pageable }
     *     
     */
    public Pageable getPageable() {
        return pageable;
    }

    /**
     * Define o valor da propriedade pageable.
     * 
     * @param value
     *     allowed object is
     *     {@link Pageable }
     *     
     */
    public void setPageable(Pageable value) {
        this.pageable = value;
    }

}
