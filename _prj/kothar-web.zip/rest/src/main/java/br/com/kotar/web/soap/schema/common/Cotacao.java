//
// Este arquivo foi gerado pela Arquitetura JavaTM para Implementação de Referência (JAXB) de Bind XML, v2.2.7 
// Consulte <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Todas as modificações neste arquivo serão perdidas após a recompilação do esquema de origem. 
// Gerado em: 2017.12.08 às 11:08:30 AM BRST 
//


package br.com.kotar.web.soap.schema.common;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java de cotacao complex type.
 * 
 * <p>O seguinte fragmento do esquema especifica o conteúdo esperado contido dentro desta classe.
 * 
 * <pre>
 * &lt;complexType name="cotacao">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="cotacao_id" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="cotacao_nome" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="cliente" type="{http://kotar.com.br/web/soap/schema/common}cliente"/>
 *         &lt;element name="cotacao_endereco" type="{http://kotar.com.br/web/soap/schema/common}cotacaoEndereco"/>
 *         &lt;element name="codigo_voucher" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="itens" type="{http://kotar.com.br/web/soap/schema/common}cotacaoItemFornecedor" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "cotacao", propOrder = {
    "cotacaoId",
    "cotacaoNome",
    "cliente",
    "cotacaoEndereco",
    "codigoVoucher",
    "itens"
})
public class Cotacao {

    @XmlElement(name = "cotacao_id")
    protected long cotacaoId;
    @XmlElement(name = "cotacao_nome", required = true)
    protected String cotacaoNome;
    @XmlElement(required = true)
    protected Cliente cliente;
    @XmlElement(name = "cotacao_endereco", required = true)
    protected CotacaoEndereco cotacaoEndereco;
    @XmlElement(name = "codigo_voucher", required = true)
    protected String codigoVoucher;
    protected List<CotacaoItemFornecedor> itens;

    /**
     * Obtém o valor da propriedade cotacaoId.
     * 
     */
    public long getCotacaoId() {
        return cotacaoId;
    }

    /**
     * Define o valor da propriedade cotacaoId.
     * 
     */
    public void setCotacaoId(long value) {
        this.cotacaoId = value;
    }

    /**
     * Obtém o valor da propriedade cotacaoNome.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCotacaoNome() {
        return cotacaoNome;
    }

    /**
     * Define o valor da propriedade cotacaoNome.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCotacaoNome(String value) {
        this.cotacaoNome = value;
    }

    /**
     * Obtém o valor da propriedade cliente.
     * 
     * @return
     *     possible object is
     *     {@link Cliente }
     *     
     */
    public Cliente getCliente() {
        return cliente;
    }

    /**
     * Define o valor da propriedade cliente.
     * 
     * @param value
     *     allowed object is
     *     {@link Cliente }
     *     
     */
    public void setCliente(Cliente value) {
        this.cliente = value;
    }

    /**
     * Obtém o valor da propriedade cotacaoEndereco.
     * 
     * @return
     *     possible object is
     *     {@link CotacaoEndereco }
     *     
     */
    public CotacaoEndereco getCotacaoEndereco() {
        return cotacaoEndereco;
    }

    /**
     * Define o valor da propriedade cotacaoEndereco.
     * 
     * @param value
     *     allowed object is
     *     {@link CotacaoEndereco }
     *     
     */
    public void setCotacaoEndereco(CotacaoEndereco value) {
        this.cotacaoEndereco = value;
    }

    /**
     * Obtém o valor da propriedade codigoVoucher.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodigoVoucher() {
        return codigoVoucher;
    }

    /**
     * Define o valor da propriedade codigoVoucher.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodigoVoucher(String value) {
        this.codigoVoucher = value;
    }

    /**
     * Gets the value of the itens property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the itens property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getItens().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CotacaoItemFornecedor }
     * 
     * 
     */
    public List<CotacaoItemFornecedor> getItens() {
        if (itens == null) {
            itens = new ArrayList<CotacaoItemFornecedor>();
        }
        return this.itens;
    }

}
