package br.com.kotar.web.configuration;

import java.util.List;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

import com.google.common.collect.Lists;

import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.ApiKey;
import springfox.documentation.service.AuthorizationScope;
import springfox.documentation.service.Contact;
import springfox.documentation.service.SecurityReference;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spi.service.contexts.SecurityContext;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger.web.ApiKeyVehicle;
import springfox.documentation.swagger.web.SecurityConfiguration;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@Configuration
@EnableSwagger2
@Profile("dev")
public class SwaggerConfig {

	// @Bean
	// public Docket api() {
	// return new Docket(DocumentationType.SWAGGER_2)
	// .select()
	// .apis(RequestHandlerSelectors.any())
	// .paths(PathSelectors.any())
	// .securityContexts(Lists.newArrayList(securityContext()))
	// .securitySchemes(Lists.newArrayList(apiKey())
	// .build();
	//
	// }

	@Bean
	public Docket api() {
		return new Docket(DocumentationType.SWAGGER_2)
				.select()
				.apis(RequestHandlerSelectors.any())
				.paths(PathSelectors.any())
				.build()
				.enable(true)
				.apiInfo(apiInfo())
				.securityContexts(Lists.newArrayList(securityContext()))
				.securitySchemes(Lists.newArrayList(apiKey()));
	}

	private ApiInfo apiInfo() {
		return new ApiInfoBuilder().title("OSAM").description("OSAM").license("Apache 2.0")
				.licenseUrl("http://www.apache.org/licenses/LICENSE-2.0.html")
				.termsOfServiceUrl("http://swagger.io/terms/")
				.version("1.0.0")
				.contact(new Contact("", "", "pb@gmail.com"))
				.build();
	}

	private ApiKey apiKey() {
		return new ApiKey("authorization", "api_key", "header");
	}

	@Bean
	SecurityConfiguration security() {
		return new SecurityConfiguration(null, 
				null, 
				"user", // realm Needed for authenticate button to work
				"kothar", // appName Needed for authenticate button to work
				null,
				//"Bearer ", // apiKeyValue
				// +"eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ7XCJ1c2VybmFtZVwiOlwibWF4d2VsbC5jYXZhbGxpXCIsXCJlbWFpbFwiOlwibWF4d2VsbC5nb2JhdHRvY2F2YWxsaUBnbWFpbC5jb21cIixcInRlbGVmb25lXCI6XCI0MTk4ODg1MDY2OVwiLFwidXBkYXRlZFwiOjE1MDMwNjM2NDQwMDAsXCJsYXN0TG9naW5cIjoxNTAzNDk5NzM5NzY0LFwicmVzZXRUb2tlblwiOm51bGwsXCJkYXRlUmVzZXRUb2tlblwiOm51bGwsXCJpZEZhY2Vib29rXCI6bnVsbCxcInRva2VuRmFjZWJvb2tcIjpudWxsLFwiaWRHb29nbGVcIjpudWxsLFwibGFuZ3VhZ2VcIjpudWxsLFwidG9rZW5Hb29nbGVcIjpudWxsLFwicGFzc3dvcmRMb2dpblwiOm51bGwsXCJ0b2tlblwiOm51bGwsXCJsb2dpbkNsaWVudGVcIjpmYWxzZSxcImxvZ2luRm9ybmVjZWRvclwiOnRydWUsXCJhZG1pblwiOmZhbHNlLFwidXN1YXJpb19ub21lXCI6XCJNQVhXRUxMIEdPQkFUVE8gQ0FWQUxMSVwiLFwidXN1YXJpb19pZFwiOjEwLFwidXN1YXJpb19zaXR1YWNhb1wiOntcIkFUSVZPXCI6XCJBdGl2b1wifSxcInVzdWFyaW9fc2l0dWFjYW9fc3RyXCI6XCJBdGl2b1wifSIsInJvbGVzIjoidXNlciIsImlhdCI6MTUwMzQ5OTczOX0.p5fhpwZNCpazss0UzWCy6SD7p7fZtJ3tlFY8NVJqbb4", 
				ApiKeyVehicle.HEADER, "authorization", // apiKeyName
				null);
	}

	private SecurityContext securityContext() {
		return SecurityContext
				.builder()
				.securityReferences(defaultAuth())
				.forPaths(PathSelectors.regex("/anyPath.*"))
				.build();
	}

	List<SecurityReference> defaultAuth() {
		AuthorizationScope authorizationScope = new AuthorizationScope("global", "accessEverything");
		AuthorizationScope[] authorizationScopes = new AuthorizationScope[1];
		authorizationScopes[0] = authorizationScope;
		return Lists.newArrayList(new SecurityReference("authorization", authorizationScopes));
	}

}
