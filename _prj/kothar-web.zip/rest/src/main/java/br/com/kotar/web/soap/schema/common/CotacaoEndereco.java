//
// Este arquivo foi gerado pela Arquitetura JavaTM para Implementação de Referência (JAXB) de Bind XML, v2.2.7 
// Consulte <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Todas as modificações neste arquivo serão perdidas após a recompilação do esquema de origem. 
// Gerado em: 2017.12.08 às 11:08:30 AM BRST 
//


package br.com.kotar.web.soap.schema.common;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java de cotacaoEndereco complex type.
 * 
 * <p>O seguinte fragmento do esquema especifica o conteúdo esperado contido dentro desta classe.
 * 
 * <pre>
 * &lt;complexType name="cotacaoEndereco">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="cep" type="{http://kotar.com.br/web/soap/schema/common}cep"/>
 *         &lt;element name="complemento" type="{http://kotar.com.br/web/soap/schema/common}enderecoComplemento"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "cotacaoEndereco", propOrder = {
    "cep",
    "complemento"
})
public class CotacaoEndereco {

    @XmlElement(required = true)
    protected Cep cep;
    @XmlElement(required = true)
    protected EnderecoComplemento complemento;

    /**
     * Obtém o valor da propriedade cep.
     * 
     * @return
     *     possible object is
     *     {@link Cep }
     *     
     */
    public Cep getCep() {
        return cep;
    }

    /**
     * Define o valor da propriedade cep.
     * 
     * @param value
     *     allowed object is
     *     {@link Cep }
     *     
     */
    public void setCep(Cep value) {
        this.cep = value;
    }

    /**
     * Obtém o valor da propriedade complemento.
     * 
     * @return
     *     possible object is
     *     {@link EnderecoComplemento }
     *     
     */
    public EnderecoComplemento getComplemento() {
        return complemento;
    }

    /**
     * Define o valor da propriedade complemento.
     * 
     * @param value
     *     allowed object is
     *     {@link EnderecoComplemento }
     *     
     */
    public void setComplemento(EnderecoComplemento value) {
        this.complemento = value;
    }

}
