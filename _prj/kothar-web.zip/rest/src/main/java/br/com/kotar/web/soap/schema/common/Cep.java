//
// Este arquivo foi gerado pela Arquitetura JavaTM para Implementação de Referência (JAXB) de Bind XML, v2.2.7 
// Consulte <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Todas as modificações neste arquivo serão perdidas após a recompilação do esquema de origem. 
// Gerado em: 2017.11.23 às 11:34:09 AM BRST 
//


package br.com.kotar.web.soap.schema.common;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java de cep complex type.
 * 
 * <p>O seguinte fragmento do esquema especifica o conteúdo esperado contido dentro desta classe.
 * 
 * <pre>
 * &lt;complexType name="cep">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="cep_nome" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="codigoPostal" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="cep_bairro" type="{http://kotar.com.br/web/soap/schema/common}bairro"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "cep", propOrder = {
    "cepNome",
    "codigoPostal",
    "cepBairro"
})
public class Cep {

    @XmlElement(name = "cep_nome", required = true)
    protected String cepNome;
    @XmlElement(required = true)
    protected String codigoPostal;
    @XmlElement(name = "cep_bairro", required = true)
    protected Bairro cepBairro;

    /**
     * Obtém o valor da propriedade cepNome.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCepNome() {
        return cepNome;
    }

    /**
     * Define o valor da propriedade cepNome.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCepNome(String value) {
        this.cepNome = value;
    }

    /**
     * Obtém o valor da propriedade codigoPostal.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodigoPostal() {
        return codigoPostal;
    }

    /**
     * Define o valor da propriedade codigoPostal.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodigoPostal(String value) {
        this.codigoPostal = value;
    }

    /**
     * Obtém o valor da propriedade cepBairro.
     * 
     * @return
     *     possible object is
     *     {@link Bairro }
     *     
     */
    public Bairro getCepBairro() {
        return cepBairro;
    }

    /**
     * Define o valor da propriedade cepBairro.
     * 
     * @param value
     *     allowed object is
     *     {@link Bairro }
     *     
     */
    public void setCepBairro(Bairro value) {
        this.cepBairro = value;
    }

}
