//
// Este arquivo foi gerado pela Arquitetura JavaTM para Implementação de Referência (JAXB) de Bind XML, v2.2.7 
// Consulte <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Todas as modificações neste arquivo serão perdidas após a recompilação do esquema de origem. 
// Gerado em: 2017.12.08 às 11:08:30 AM BRST 
//


package br.com.kotar.web.soap.schema.common;

import javax.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the br.com.kotar.web.soap.schema.common package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: br.com.kotar.web.soap.schema.common
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link CotacaoItem }
     * 
     */
    public CotacaoItem createCotacaoItem() {
        return new CotacaoItem();
    }

    /**
     * Create an instance of {@link Cidade }
     * 
     */
    public Cidade createCidade() {
        return new Cidade();
    }

    /**
     * Create an instance of {@link Estado }
     * 
     */
    public Estado createEstado() {
        return new Estado();
    }

    /**
     * Create an instance of {@link Bairro }
     * 
     */
    public Bairro createBairro() {
        return new Bairro();
    }

    /**
     * Create an instance of {@link Pageable }
     * 
     */
    public Pageable createPageable() {
        return new Pageable();
    }

    /**
     * Create an instance of {@link CotacaoEndereco }
     * 
     */
    public CotacaoEndereco createCotacaoEndereco() {
        return new CotacaoEndereco();
    }

    /**
     * Create an instance of {@link Cep }
     * 
     */
    public Cep createCep() {
        return new Cep();
    }

    /**
     * Create an instance of {@link ProdutoFoto }
     * 
     */
    public ProdutoFoto createProdutoFoto() {
        return new ProdutoFoto();
    }

    /**
     * Create an instance of {@link Cliente }
     * 
     */
    public Cliente createCliente() {
        return new Cliente();
    }

    /**
     * Create an instance of {@link Produto }
     * 
     */
    public Produto createProduto() {
        return new Produto();
    }

    /**
     * Create an instance of {@link EnderecoComplemento }
     * 
     */
    public EnderecoComplemento createEnderecoComplemento() {
        return new EnderecoComplemento();
    }

    /**
     * Create an instance of {@link Fornecedor }
     * 
     */
    public Fornecedor createFornecedor() {
        return new Fornecedor();
    }

    /**
     * Create an instance of {@link Cotacao }
     * 
     */
    public Cotacao createCotacao() {
        return new Cotacao();
    }

    /**
     * Create an instance of {@link CotacaoItemFornecedor }
     * 
     */
    public CotacaoItemFornecedor createCotacaoItemFornecedor() {
        return new CotacaoItemFornecedor();
    }

}
