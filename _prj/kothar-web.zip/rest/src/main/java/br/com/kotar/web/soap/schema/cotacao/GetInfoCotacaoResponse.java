//
// Este arquivo foi gerado pela Arquitetura JavaTM para Implementação de Referência (JAXB) de Bind XML, v2.2.7 
// Consulte <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Todas as modificações neste arquivo serão perdidas após a recompilação do esquema de origem. 
// Gerado em: 2017.12.08 às 11:08:30 AM BRST 
//


package br.com.kotar.web.soap.schema.cotacao;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import br.com.kotar.web.soap.schema.common.Cotacao;


/**
 * <p>Classe Java de anonymous complex type.
 * 
 * <p>O seguinte fragmento do esquema especifica o conteúdo esperado contido dentro desta classe.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="cotacao" type="{http://kotar.com.br/web/soap/schema/common}cotacao"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "cotacao"
})
@XmlRootElement(name = "getInfoCotacaoResponse")
public class GetInfoCotacaoResponse {

    @XmlElement(required = true)
    protected Cotacao cotacao;

    /**
     * Obtém o valor da propriedade cotacao.
     * 
     * @return
     *     possible object is
     *     {@link Cotacao }
     *     
     */
    public Cotacao getCotacao() {
        return cotacao;
    }

    /**
     * Define o valor da propriedade cotacao.
     * 
     * @param value
     *     allowed object is
     *     {@link Cotacao }
     *     
     */
    public void setCotacao(Cotacao value) {
        this.cotacao = value;
    }

}
