//
// Este arquivo foi gerado pela Arquitetura JavaTM para Implementação de Referência (JAXB) de Bind XML, v2.2.7 
// Consulte <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Todas as modificações neste arquivo serão perdidas após a recompilação do esquema de origem. 
// Gerado em: 2017.11.23 às 11:34:09 AM BRST 
//

@javax.xml.bind.annotation.XmlSchema(namespace = "http://kotar.com.br/web/soap/schema/usuario", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package br.com.kotar.web.soap.schema.usuario;
