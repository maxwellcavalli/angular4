package br.com.kotar.web.controller.base;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;

import br.com.kotar.core.controller.BaseController;
import br.com.kotar.core.domain.BaseDomain;
import br.com.kotar.core.exception.InvalidTokenException;
import br.com.kotar.core.service.BaseService;
import br.com.kotar.domain.security.Usuario;
import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Element;

public abstract class BaseLoggedUserController<T extends BaseDomain> extends BaseController<T> {

	//@formatter:off
	@Autowired protected HttpServletRequest request;
	@Autowired protected CacheManager cacheManager;
	//@formatter:on

	protected Usuario getLoggedUser() throws InvalidTokenException {
		final String token = getToken();
		
		Usuario user = null;
		Cache cache = cacheManager.getCache("userCache");
		if (cache.isElementInMemory(token)){
			Element element = cache.get(token);
			user = (Usuario) element.getObjectValue();
		}
		
		if (user == null){
			throw new InvalidTokenException();
		}

		return user;
	}
	
	protected String getToken(){
		final String authHeader = request.getHeader("authorization");
		final String token = authHeader.substring(7);
		
		return token;
	}

	@Override
	public void beforeSave(T t) {
	}

	@Override
	public void validationBeforeSave(T t) throws Exception {
	}
	
	@Override
	public BaseService<T> getService() {
		return null;
	}

}
