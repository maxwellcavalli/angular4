package br.com.kotar.web.repository;

import br.com.kotar.core.repository.CrudRepository;
import br.com.kotar.domain.business.Cotacao;

public interface EstatisticasCotacaoRepository extends CrudRepository<Cotacao>{
	//@formatter:off
	//@formatter:on
}