package br.com.kotar.web.repository.impl;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import br.com.kotar.core.repository.BaseRepository;
import br.com.kotar.core.repository.impl.BaseRepositoryImpl;
import br.com.kotar.domain.business.Avaliacao;
import br.com.kotar.domain.business.Cotacao;
import br.com.kotar.domain.business.Fornecedor;
import br.com.kotar.domain.helper.AvaliacaoFilter;
import br.com.kotar.domain.security.Usuario;
import br.com.kotar.web.repository.AvaliacaoRepository;
import br.com.kotar.web.service.ClienteService;

@Service
@Transactional(propagation = Propagation.REQUIRED)
public class AvaliacaoDAOImpl extends BaseRepositoryImpl<Avaliacao> implements AvaliacaoRepository {
	
	//@formatter:off
	@Autowired AvaliacaoRepository avaliacaoRepository;
	@Autowired ClienteService clienteService;
	//@formatter:on
	
	@Override
	public BaseRepository<Avaliacao> getRepository() {
		return avaliacaoRepository;
	}

	public Page<Avaliacao> findAvaliacao(Usuario usuario, AvaliacaoFilter avaliacaoFilter) throws Exception {
		Pageable pageable = avaliacaoFilter.getPageable();
		
		if (avaliacaoFilter.getFornecedor() != null) {
			return findByFornecedor(avaliacaoFilter.getFornecedor(), pageable);
		}
		else {
			return findByUsuario(usuario, pageable);
		}
	}
	
	public Page<Avaliacao> findByUsuario(Usuario usuario, Pageable pageable) throws Exception {
		
		StringBuilder hql = new StringBuilder();
		
		hql.append(" select avaliacao ");
		hql.append("   from Avaliacao avaliacao ");
		hql.append(" inner join fetch avaliacao.cotacaoFornecedor cotacaoFornecedor ");
		hql.append(" inner join fetch cotacaoFornecedor.cotacao cotacao ");		
		hql.append(" inner join fetch cotacao.cliente cliente ");			
		hql.append(" where cliente.usuario = :usuario ");

		Map<String, Object> parameters = new HashMap<>();
		parameters.put("usuario", usuario);
		
		return searchPaginated(hql.toString(), pageable, parameters);
	}
	
	public Page<Avaliacao> findByFornecedor(Fornecedor fornecedor, Pageable pageable) throws Exception {
		
		StringBuilder hql = new StringBuilder();
		
		hql.append(" select avaliacao ");
		hql.append("   from Avaliacao avaliacao ");
		hql.append(" inner join fetch avaliacao.cotacaoFornecedor cotacaoFornecedor ");
		hql.append(" where cotacaoFornecedor.fornecedor = :fornecedor ");

		Map<String, Object> parameters = new HashMap<>();
		parameters.put("fornecedor", fornecedor);
		
		return searchPaginated(hql.toString(), pageable, parameters);
	}

	@Override
	public Avaliacao findByUsuario(Usuario usuario) {
		return avaliacaoRepository.findByUsuario(usuario);
	}

	@Override
	public Avaliacao findByCotacao(Cotacao cotacao) {
		return avaliacaoRepository.findByCotacao(cotacao);
	}
}