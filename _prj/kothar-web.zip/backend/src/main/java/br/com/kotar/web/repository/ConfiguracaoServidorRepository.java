package br.com.kotar.web.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import br.com.kotar.core.repository.BaseRepository;
import br.com.kotar.domain.business.ConfiguracaoServidor;

public interface ConfiguracaoServidorRepository extends BaseRepository<ConfiguracaoServidor> {

	//@formatter:off
	@Query(value = "select cep "
			+ "       from Cep cep "
			+ "      inner join fetch cep.bairro bairro "
			+ "      inner join fetch bairro.cidade cidade "
			+ "      inner join fetch cidade.estado "
			+ "      where cep.id = :id "
			)
	public ConfiguracaoServidor findById(@Param("id") Long id);	
	//@formatter:on
}