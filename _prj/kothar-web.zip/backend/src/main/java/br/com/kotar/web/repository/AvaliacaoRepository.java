package br.com.kotar.web.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import br.com.kotar.core.repository.BaseRepository;
import br.com.kotar.domain.business.Avaliacao;
import br.com.kotar.domain.business.Cotacao;
import br.com.kotar.domain.security.Usuario;

public interface AvaliacaoRepository extends BaseRepository<Avaliacao> {
	
	//@formatter:off
	@Query(value = "select avaliacao "
			+ "       from Avaliacao avaliacao "
			+ "      inner join fetch avaliacao.cotacaoFornecedor cotacaoFornecedor "
			+ "      inner join fetch cotacaoFornecedor.cotacao cotacao "		
			+ "      where avaliacao.id = :id ")
	public Avaliacao findById(@Param("id") Long id);
	
	@Query(value = "select avaliacao "
			+ "       from Avaliacao avaliacao "
			+ "      inner join fetch avaliacao.cotacaoFornecedor cotacaoFornecedor "
			+ "      inner join fetch cotacaoFornecedor.cotacao cotacao "		
			+ "      inner join fetch cotacao.cliente cliente "			
			+ "      where cliente.usuario = :usuario ") 
	public Avaliacao findByUsuario(@Param("usuario") Usuario usuario);	
	
	@Query(value = "select avaliacao "
			+ "       from Avaliacao avaliacao "
			+ "      inner join fetch avaliacao.cotacaoFornecedor cotacaoFornecedor "
			+ "      inner join fetch cotacaoFornecedor.cotacao cotacao "		
			+ "      where cotacaoFornecedor.cotacao = :cotacao "
			+ "        and cotacaoFornecedor.vencedorByUser = 1")
	public Avaliacao findByCotacao(@Param("cotacao") Cotacao cotacao);
	
	//@formatter:on	
}