package br.com.kotar.web.repository;

import br.com.kotar.core.repository.BaseRepository;
import br.com.kotar.domain.business.PendenciaIntegracao;

public interface PendenciaIntegracaoRepository extends BaseRepository<PendenciaIntegracao>{

	//@formatter:off
	
	//@formatter:on
	
}