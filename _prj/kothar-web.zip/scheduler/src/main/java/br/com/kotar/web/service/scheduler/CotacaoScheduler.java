package br.com.kotar.web.service.scheduler;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import br.com.kotar.domain.business.Cotacao;
import br.com.kotar.domain.business.type.SituacaoCotacaoType;
import br.com.kotar.web.service.CotacaoService;

@Component
public class CotacaoScheduler {

	 private static final Logger log = LoggerFactory.getLogger(CotacaoScheduler.class);
	 
	//@formatter:off
	@Autowired CotacaoService cotacaoService;
	//@formatter:on
	
	@Scheduled(fixedRate = 2000)
    public void reportCurrentTime() {
		log.info("Verificando situacao da cotacao");
		
		List<Cotacao> list = cotacaoService.findCotacaoExpirada();
		log.info("Quantidade de cotacoes expiradas: " + list.size());		
		
		for (Cotacao cotacao : list){
			Long quantidadeRespostas = cotacao.getQuantidadeRespostas();
			cotacao = cotacaoService.findOne(cotacao.getId());
			
			if (quantidadeRespostas == 0){
				cotacao.setSituacaoCotacao(SituacaoCotacaoType.FINALIZADA);	
			} else {
				cotacao.setSituacaoCotacao(SituacaoCotacaoType.ENCERRADA);
			}
			
			cotacaoService.save(cotacao);
		}
    }
}
