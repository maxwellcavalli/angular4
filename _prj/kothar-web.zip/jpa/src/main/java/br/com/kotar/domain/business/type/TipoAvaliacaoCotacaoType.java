package br.com.kotar.domain.business.type;

public enum TipoAvaliacaoCotacaoType {

	ITEM,
	GLOBAL
}
