import { PeriodoHelper } from "./periodo-helper";

export class PendenciasIntegracaoFilter {

    periodoCadastro: PeriodoHelper = new PeriodoHelper();

}