export class PeriodoHelper {
    inicio: Date;
    fim: Date;
}