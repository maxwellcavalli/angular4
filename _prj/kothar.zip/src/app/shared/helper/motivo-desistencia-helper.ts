import { PeriodoHelper } from "./periodo-helper";


export class MotivoDesistenciaCompraHelper {

    value: any;
    description: String;

}