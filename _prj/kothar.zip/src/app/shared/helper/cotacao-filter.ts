import { PeriodoHelper } from "./periodo-helper";


export class CotacaoFilter {

    nome: String = '';
    periodoCadastro: PeriodoHelper = new PeriodoHelper();
    periodoEnvio: PeriodoHelper = new PeriodoHelper();
    periodoRetorno: PeriodoHelper = new PeriodoHelper();
    situacaoCotacao: any;

}