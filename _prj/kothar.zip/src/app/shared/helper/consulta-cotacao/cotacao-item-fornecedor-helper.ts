import { CotacaoFornecedorHelper } from "./cotacao-fornecedor-helper";
import { CotacaoItemFornecedorValorHelper } from "./cotacao-item-fornecedor-valor-helper";
import { CotacaoItemHelper } from "./cotacao-item-helper";

export class CotacaoItemFornecedorHelper {
    cotacao_item_fornecedor_id: Number;
    cotacao_item_fornecedor_fornecedor: CotacaoFornecedorHelper;
    cotacao_item_fornecedor_valores: Array<CotacaoItemFornecedorValorHelper>;
    cotacao_item_fornecedor_melhor_valor: CotacaoItemFornecedorValorHelper;
    cotacao_item_fornecedor_valor_total: String;

    cotacao_item_fornecedor_item: CotacaoItemHelper;
    cotacao_item_fornecedor_possui_pendencias: Boolean;

    cotacao_item_fornecedor_variacao_valor: String;


    toggle_details: boolean = false;



}
