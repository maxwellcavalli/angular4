import { CotacaoItemFornecedorHelper } from "./cotacao-item-fornecedor-helper";
import { Produto } from "../../entity/produto";
import { CotacaoItemArquivo } from "../../entity/cotacao-item-arquivo";

export class CotacaoItemHelper {

    cotacao_item_id: Number;
    cotacao_item_produto: Produto;
    cotacao_item_quantidade: Number;
    cotacao_item_observacao: String;
    cotacao_item_arquivos: Array<CotacaoItemArquivo>;
    cotacao_item_fornecedor:Array<CotacaoItemFornecedorHelper>;
    cotacao_item_pendencias_valores: boolean;
    cotacao_item_fornecedor_vencedor: CotacaoItemFornecedorHelper;

}
