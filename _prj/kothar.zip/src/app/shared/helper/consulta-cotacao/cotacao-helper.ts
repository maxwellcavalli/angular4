import { CotacaoItemHelper } from "./cotacao-item-helper";
import { CotacaoFornecedorHelper } from "./cotacao-fornecedor-helper";
import { CotacaoEndereco } from "../../entity/cotacao-endereco";


export class CotacaoHelper {

    cotacao_id: Number;
    cotacao_nome: String;
    cotacao_data_cadastro: Date;
    cotacao_data_limite_retorno: Date;
    cotacao_data_envio: Date;
    cotacao_endereco: CotacaoEndereco;
    cotacao_itens: Array<CotacaoItemHelper>;
    cotacao_situacao_str: String;
    cotacao_fornecedores: Array<CotacaoFornecedorHelper>;
    cotacao_pode_finalizar: boolean;
    cotacao_finalizada: boolean;
    cotacao_cliente_nome: String;

}
