import { FornecedorHelper } from "./fornecedor-helper";
import { CotacaoItemFornecedorHelper } from "./cotacao-item-fornecedor-helper";
import { CotacaoFornecedorCondicoesPagamentoHelper } from "./cotacao-fornecedor-condicoes-pagamento-helper";

export class CotacaoFornecedorHelper {
    cotacao_fornecedor_id: Number;
    cotacao_fornecedor_fornecedor: FornecedorHelper;
    cotacao_fornecedor_pagamentos: String;    
    cotacao_fornecedor_valor_global: Number;
    cotacao_fornecedor_colocacao: Number;
    cotacao_fornecedor_valor_global_fmt: String;
    cotacao_fornecedor_pendencia: boolean;
    cotacao_fornecedor_prazo_entrega: String;

    cotacao_fornecedor_variacao_preco_min: String;
    cotacao_fornecedor_variacao_preco_max: String;

    cotacao_fornecedor_itens: Array<CotacaoItemFornecedorHelper>;
    cotacao_fornecedor_icon: string;
    codigo_aprovacao_vencedor: String;
    cotacao_fornecedor_data_validade: String;

    cotacao_fornecedor_condicoes_pagamento: CotacaoFornecedorCondicoesPagamentoHelper;
    distancia_formatada: String;

}
