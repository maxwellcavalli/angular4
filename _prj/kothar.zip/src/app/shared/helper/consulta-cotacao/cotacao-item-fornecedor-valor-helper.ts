export class CotacaoItemFornecedorValorHelper {

    cotacao_item_fornecedor_valor_id: Number;
    cotacao_item_fornecedor_valor_unitario: Number;
    cotacao_item_fornecedor_valor_marca_modelo: String;
    cotacao_item_fornecedor_valor_unitario_fmt: String;

    cotacao_item_fornecedor_valor_selecionado: Boolean;
    
}
