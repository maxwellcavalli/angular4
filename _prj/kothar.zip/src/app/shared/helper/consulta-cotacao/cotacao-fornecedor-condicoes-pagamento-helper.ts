import { FornecedorHelper } from "./fornecedor-helper";
import { CotacaoItemFornecedorHelper } from "./cotacao-item-fornecedor-helper";

export class CotacaoFornecedorCondicoesPagamentoHelper {
    
    condicoes_pagamento_tipo: String;
    condicoes_pagamento_numero_parcelas: Number;
    condicoes_pagamento_juros: String;
    condicoes_pagamento_texto_prazo: String;

}
