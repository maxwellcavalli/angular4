import { Cep } from "../../entity/cep";
import { EnderecoComplemento } from "../../entity/endereco-complemento";


export class FornecedorHelper {
    fornecedor_id: Number;
    fornecedor_nome: String;
    fornecedor_cpf_cnpj: String;
    fornecedor_cep: Cep;
    fornecedor_endereco: EnderecoComplemento;    

    fornecedor_endereco_formatado: String;
}
