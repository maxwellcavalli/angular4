import { CotacaoHelper } from "./cotacao-helper";

export class RetornoConsultaCotacaoHelper {
    
    cotacao: CotacaoHelper;

}
