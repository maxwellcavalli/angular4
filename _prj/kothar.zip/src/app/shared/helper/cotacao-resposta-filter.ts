import { PeriodoHelper } from "./periodo-helper";
import { CotacaoFilter } from "./cotacao-filter";
import { Fornecedor } from "../entity/fornecedor";


export class CotacaoRespostaFilter extends CotacaoFilter {

    fornecedor: Fornecedor;
    situacaoRespostaFornecedor: any;

}