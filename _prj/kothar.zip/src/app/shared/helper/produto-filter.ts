export class ProdutoFilter {
    nome: String;
}