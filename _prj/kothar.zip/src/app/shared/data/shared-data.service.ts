import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { Cotacao } from '../entity/cotacao';
import { Fornecedor } from '../entity/fornecedor';

@Injectable()
export class SharedDataService {

  public cotacao: BehaviorSubject<Cotacao> = new BehaviorSubject<Cotacao>(null);
  public fornecedor: BehaviorSubject<Fornecedor> = new BehaviorSubject<Fornecedor>(null);
  public menus: BehaviorSubject<Array<any>> = new BehaviorSubject<Array<any>>(null);

  public clearAll() {
    this.cotacao.next(null);
    this.fornecedor.next(null);
    this.menus.next(null);
  }

}
