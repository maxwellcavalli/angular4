import { AuthenticationService } from "../../service/security/authentication.service";
import { Router, ActivatedRoute } from "@angular/router";
import { Optional } from "@angular/core";
import { MxBaseCrudController, MxBaseService } from "mx-core";
import { TranslateService } from "@ngx-translate/core";

import { CategoriaService } from "../../service/categoria.service";

export class LoggedCrudController<T> extends MxBaseCrudController<T> {

    constructor(
        public _service: any,
        public translate: any,
        @Optional() protected _authenticationService: AuthenticationService,
        @Optional() protected router: Router,
        @Optional() protected route: ActivatedRoute,
        createServerObject: boolean) {

        super(_service, translate, router, route, createServerObject);
    }

    ngOnInit() {     
        // let _url = this.router.url;
        // if (localStorage.getItem('currentUser')) {
        //     this._authenticationService.validateToken().toPromise().then(

        //         value => {
        //             let valid = (value.object as boolean)
        //             if (!valid) {

        //                 let urlReturn = _url === '' ? '/dashboard' : _url;
        //                 this.router.navigate(['/signin'], { queryParams: { returnUrl: urlReturn } });
        //             }

        //             return valid;
        //         },
        //         response => {
        //             if (response.status == 504) {
        //                 let urlReturn = _url === '' ? '/dashboard' : _url;
        //                 this.router.navigate(['/signin'], { queryParams: { returnUrl: urlReturn } });
        //                 return false;
        //             }
        //         }
        //     );

        // } else {
        //     //console.log('not logged');

        //     // not logged in so redirect to login page with the return url
        //     let urlReturn = _url === '' ? '/dashboard' : _url;
        //     this.router.navigate(['/signin'], { queryParams: { returnUrl: urlReturn } });
        // }

        super.ngOnInit();
    }

}

