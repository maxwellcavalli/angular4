import { AuthenticationService } from "../../service/security/authentication.service";
import { Router, ActivatedRoute } from "@angular/router";
import { Optional } from "@angular/core";
import { MxBaseCrudController, MxBaseService } from "mx-core";
import { TranslateService } from "@ngx-translate/core";

import { CategoriaService } from "../../service/categoria.service";

export class LoggedCrudController<T> extends MxBaseCrudController<T> {

    constructor(
        public _service: any,
        public translate: any,
        @Optional() protected _authenticationService: AuthenticationService,
        @Optional() protected router: Router,
        @Optional() protected route: ActivatedRoute,
        createServerObject: boolean) {

        super(_service, translate, router, route, createServerObject);
    }

    ngOnInit() {             
        super.ngOnInit();
    }

}

