import { Injectable } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { AuthenticationService } from '../../service/security/authentication.service';
import { Menu } from '../../layout/template/menu';
import { AcessosService } from '../../service/acessos.service';
import { SharedDataService } from '../data/shared-data.service';
import { BehaviorSubject } from 'rxjs';
import { Observable } from 'rxjs/Observable';

@Injectable()
export class AuthGuard implements CanActivate {

    constructor(
        private router: Router,
        private _acessosService: AcessosService,
        private _sharedDataService: SharedDataService,
        private _authenticationService: AuthenticationService) { }

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
        if (localStorage.getItem('currentUser')) {

            return new Observable<boolean>((observer) => {
                this._authenticationService.validateToken().subscribe(
                    dataToken => {
                        let _logged = dataToken.object as boolean;
                        if (_logged == false){
                            let urlReturn = state.url === '' ? '/dashboard' : state.url;
                            this.router.navigate(['/signin'], { queryParams: { returnUrl: urlReturn } });

                            observer.next(false);
                            observer.complete();
                        } else {
                            if (state.url == '/'){
                                this.router.navigate(['/dashboard']);

                                observer.next(false);
                                observer.complete();
                            } else {
                                //validar os acessos
                                let _m = this._sharedDataService.menus.value;
                                if (_m == null || _m == undefined) {
                                    this._acessosService.getMenus().subscribe(
                                        retM => {
                                            let _m = retM.object as Array<any>;
                                            this._sharedDataService.menus.next(_m);
                
                                            let _h = Menu.getHierarquiaMenuByUrl(state.url, _m);
                                            if (_h.length > 0) {
                                                observer.next(true);
                                            } else {
                                                observer.next(false);
                                                this.router.navigate(['/not-found']);
                                            }
                                            observer.complete();
                                        });
                                } else {
                                    let _h = Menu.getHierarquiaMenuByUrl(state.url, _m);
                                    if (_h.length > 0) {
                                        observer.next(true);
                                    } else {
                                        observer.next(false);
                                        this.router.navigate(['/not-found']);
                                    }
                                    observer.complete();
                                }
                            }
                        }
                    }
                );
            });

        } else {
            //console.log('not logged');            

            // not logged in so redirect to login page with the return url
            let urlReturn = state.url === '' ? '/dashboard' : state.url;
            this.router.navigate(['/signin'], { queryParams: { returnUrl: urlReturn } });
            return false;
        }
    }

}

