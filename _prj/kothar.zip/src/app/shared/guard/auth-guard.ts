import { Injectable } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { AuthenticationService } from '../../service/security/authentication.service';

@Injectable()
export class AuthGuard implements CanActivate {

    constructor(private router: Router) { }

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
        //console.log('canActivate');

        if (localStorage.getItem('currentUser')) {
            return true;
        } else {
            //console.log('not logged');            

            // not logged in so redirect to login page with the return url
            let urlReturn = state.url === '' ? '/dashboard' : state.url;
            this.router.navigate(['/signin'], { queryParams: { returnUrl: urlReturn } });
            return false;
        }
    }
}
