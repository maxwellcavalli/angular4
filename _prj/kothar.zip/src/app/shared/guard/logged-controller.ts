import { AuthenticationService } from "../../service/security/authentication.service";
import { Router, ActivatedRoute } from "@angular/router";
import { Optional } from "@angular/core";

export class LoggedController {

    constructor(
        @Optional() protected _authenticationService: AuthenticationService,
        @Optional() protected router: Router,
        @Optional() protected route: ActivatedRoute) {


    }

    ngOnInit() {
        
    }

}

