import { AuthenticationService } from "../../service/security/authentication.service";
import { Router, ActivatedRoute } from "@angular/router";
import { Optional } from "@angular/core";

export class LoggedController {

    constructor(
        @Optional() protected _authenticationService: AuthenticationService,
        @Optional() protected router: Router,
        @Optional() protected route: ActivatedRoute) {


    }

    ngOnInit() {
        // let _url = this.router.url;
        // if (localStorage.getItem('currentUser')) {
        //     this._authenticationService.validateToken().toPromise().then(

        //         value => {
        //             let valid = (value.object as boolean)
        //             if (!valid) {

        //                 let urlReturn = _url === '' ? '/dashboard' : _url;
        //                 this.router.navigate(['/signin'], { queryParams: { returnUrl: urlReturn } });
        //             }

        //             return valid;
        //         },
        //         response => {
        //             if (response.status == 504) {
        //                 let urlReturn = _url === '' ? '/dashboard' : _url;
        //                 this.router.navigate(['/signin'], { queryParams: { returnUrl: urlReturn } });
        //                 return false;
        //             }
        //         }
        //     );

        // } else {
        //     console.log('not logged');

        //     // not logged in so redirect to login page with the return url
        //     let urlReturn = _url === '' ? '/dashboard' : _url;
        //     this.router.navigate(['/signin'], { queryParams: { returnUrl: urlReturn } });
        // }
    }

}

