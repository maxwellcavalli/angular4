import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PainelCepComponent } from './painel-cep.component';
import { SharedModule } from '../../shared.module';


@NgModule({
  imports: [
    CommonModule,
    SharedModule
  ],
  declarations: [PainelCepComponent],
  exports: [PainelCepComponent]
})
export class PainelCepModule { }
