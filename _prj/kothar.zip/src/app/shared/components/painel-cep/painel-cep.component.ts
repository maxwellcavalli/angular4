import { Component, OnInit, forwardRef, ChangeDetectorRef, Input } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl, ControlValueAccessor, NG_VALUE_ACCESSOR } from "@angular/forms";
import { Observable } from "rxjs/Rx";
import { BaseComponent } from '../base/base-component';
import { CepService } from '../../../service/cep.service';
import { Cep } from '../../entity/cep';
import { EnderecoComplemento } from '../../entity/endereco-complemento';
import { MxPageFilter } from 'mx-core';

const CUSTOM_INPUT_CONTROL_VALUE_ACCESSOR: any = {
  provide: NG_VALUE_ACCESSOR,
  useExisting: forwardRef(() => PainelCepComponent),
  multi: true
};

@Component({
  selector: 'painel-cep',
  templateUrl: './painel-cep.component.html',
  styleUrls: ['./painel-cep.component.scss'],
  providers: [CUSTOM_INPUT_CONTROL_VALUE_ACCESSOR]
})
export class PainelCepComponent extends BaseComponent {

  @Input() disabled: boolean = false;

  form: FormGroup;
  codigoPostal: String;
  cep: Cep = new Cep();
  oldValue: String = '';

  constructor(public _service: CepService, 
    private formBuilder: FormBuilder, public cdRef: ChangeDetectorRef) {
    super();

    this.form = formBuilder.group({
      codigoPostal: [{ value: '', disabled: this.disabled }, [
        Validators.required,
        Validators.minLength(8),
      ]],
      numero: [{ value: '', disabled: this.disabled }, []],
      complemento: [{ value: '', disabled: this.disabled }, []],
    });
  }

  ngAfterViewInit() {
    if (this.disabled) {
      this.form.disable({ onlySelf: true });
    }
  }

  public onWriteValue(_val: any) {
    if (_val !== undefined && _val !== null) {
      this.cep = _val;
      this.codigoPostal = this.cep.codigoPostal;

      if (this.cep.endereco_complemento === undefined || this.cep.endereco_complemento === null) {
        this.cep.endereco_complemento = new EnderecoComplemento();
      }
    } else {
      this.cep = new Cep();
      this.codigoPostal = undefined;
    }

    //this.cdRef.detectChanges();
  }

  onchange(event) {
    let value = event.target.value;
    if (value !== undefined && value !== null && value !== '') {
      if (this.isFilterUpdated) {
        this.oldValue = this.codigoPostal;
        if (this.codigoPostal != undefined && this.codigoPostal !== '') {
          this.search();
        } else {
          this.cep = new Cep();
        }
      }
    } else {
      this.cep = new Cep();
      this.oldValue = '';
    }
  }

  get isFilterUpdated(): boolean {
    return this.oldValue !== this.codigoPostal;
  }

  search() {
    let pageFilter = new MxPageFilter();
    pageFilter.filterValue = this.codigoPostal;

    this._service.searchCode(pageFilter)
      .subscribe(data => {
        let cep = data.object;

        if (cep != undefined && cep != null) {
          this.cep = cep;
          this.value = cep;
        } else {
          this.value = null;
          this.cep = new Cep();
        }

        this.cep.endereco_complemento = new EnderecoComplemento();

        this.writeValue(this.cep);
      });
  }
}
