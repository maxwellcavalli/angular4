import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { BairrAutocompleteComponent } from "./bairro.component";
import { CidadeAutocompleteModule } from "../cidade/cidade.module";
import { SharedModule } from '../../../shared.module';


@NgModule({
  imports: [
    CommonModule,
    SharedModule,

    CidadeAutocompleteModule    
  ],
  declarations: [BairrAutocompleteComponent],
  exports: [BairrAutocompleteComponent]
})
export class BairroAutocompleteModule { }
