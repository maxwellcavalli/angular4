import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ClienteAutocompleteComponent } from "./cliente.component";
import { SharedModule } from '../../../shared.module';

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    
  ],
  declarations: [ClienteAutocompleteComponent],
  exports: [ClienteAutocompleteComponent]


})
export class ClienteAutocompleteModule { }
