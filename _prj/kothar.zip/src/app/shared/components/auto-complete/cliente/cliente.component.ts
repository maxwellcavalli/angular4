import { Component, OnInit, Input, forwardRef, ChangeDetectorRef } from '@angular/core';
import { FormControl, ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';
import 'rxjs/add/operator/distinctUntilChanged';
import 'rxjs/add/operator/debounceTime';
import { BaseAutoComplete } from '../../base/base-auto-complete';
import { ClienteService } from '../../../../service/cliente.service';
import { MxPageFilter } from 'mx-core';


const CUSTOM_INPUT_CONTROL_VALUE_ACCESSOR: any = {
  provide: NG_VALUE_ACCESSOR,
  useExisting: forwardRef(() => ClienteAutocompleteComponent),
  multi: true
};

@Component({
  selector: 'cliente-auto-complete',
  templateUrl: './cliente.component.html',
  styleUrls: ['./cliente.component.scss'],
  providers: [CUSTOM_INPUT_CONTROL_VALUE_ACCESSOR]
})
export class ClienteAutocompleteComponent extends BaseAutoComplete {

  reactiveClientes: any;

  @Input() formControl: any;
  @Input() placeholder: any;

  constructor(public _service: ClienteService, public cdRef: ChangeDetectorRef) {
    super();
  }

  private getValue(): string {
    let startSearch = this.formControl.value === undefined ? '' : this.formControl.value;
    if (startSearch == null) {
      startSearch = '';
    }

    return startSearch;
  }

  ngAfterViewInit() {
    this.reactiveClientes = this.formControl.valueChanges
      .distinctUntilChanged()
      .debounceTime(300)
      .map(val => this.displayFn(val))
      .map(name => this.pesquisar(name));

    this.cdRef.detectChanges();
  }

  private pesquisar(_value) {
    let _data = new Array();

    this.filter(_value).subscribe(d => {
      super.responseEntityToArray(_data, d);
    });

    return _data;
  }

  displayFn(value: any): string {
    return value && typeof value === 'object'  ? value.cliente_nome : value;
  }

  private filter(val: string) {
    let searchValue = val === undefined ? '' : val;
    if (searchValue == null) {
      searchValue = '';
    }

    let _pageFilter = new MxPageFilter();
    _pageFilter.filterValue = "%" + searchValue + "%";
    _pageFilter.page.pageNumber = 0;
    _pageFilter.page.size = 100;

    return this._service.search(_pageFilter);
  }

}
