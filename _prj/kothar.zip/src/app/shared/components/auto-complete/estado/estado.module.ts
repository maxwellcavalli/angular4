import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';


import { EstadoAutocompleteComponent } from './estado.component';
import { SharedModule } from '../../../shared.module';

@NgModule({
  imports: [
    CommonModule,
    SharedModule,

  ],
  declarations: [EstadoAutocompleteComponent],
  exports: [EstadoAutocompleteComponent]
})
export class EstadoAutocompleteModule { }


