import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { GrupoProdutoAutocompleteComponent } from './grupo-produto.component';
import { SharedModule } from '../../../shared.module';

@NgModule({
  imports: [
    CommonModule,
    SharedModule
  ],
  declarations: [GrupoProdutoAutocompleteComponent],
  exports: [GrupoProdutoAutocompleteComponent]
})
export class GrupoProdutoAutocompleteModule { }
