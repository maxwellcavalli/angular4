import { Component, OnInit, Input, forwardRef, ChangeDetectorRef, DoCheck, EventEmitter } from '@angular/core';
import { FormControl, ControlValueAccessor, NG_VALUE_ACCESSOR, FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Subject } from "rxjs/Subject";
import 'rxjs/add/operator/distinctUntilChanged';
import 'rxjs/add/operator/debounceTime';


import { CidadeService } from "./../../../../service/cidade.service";
import { BaseAutoComplete } from '../../base/base-auto-complete';
import { MxPageFilter } from 'mx-core';
import { Estado } from '../../../entity/estado';



const CUSTOM_INPUT_CONTROL_VALUE_ACCESSOR: any = {
  provide: NG_VALUE_ACCESSOR,
  useExisting: forwardRef(() => CidadeAutocompleteComponent),
  multi: true
};

@Component({
  selector: 'cidade-auto-complete',
  templateUrl: './cidade.component.html',
  styleUrls: ['./cidade.component.scss'],
  providers: [CUSTOM_INPUT_CONTROL_VALUE_ACCESSOR]
})
export class CidadeAutocompleteComponent extends BaseAutoComplete {

  reactiveCidades: any;
  estado: Estado;

  disableCidade: Boolean = true;

  @Input() formControl: FormControl;
  @Input() placeholder: any;
  @Input() form: FormGroup;

  private loading: boolean;

  constructor(public _service: CidadeService, public cdRef: ChangeDetectorRef) {
    super();
  }

  public onWriteValue(_val: any) {
    if (_val !== undefined) {

      this.loading = true;

      this.estado = _val.cidade_estado;
      (this.formControl as FormControl).enable();
      this.cdRef.detectChanges();

      this.loading = false;
    }
  }

  onChangeEstado(event) {

    if (this.loading === false) {
      this.estado = event;
      if (event !== undefined && event !== null && typeof event !== 'string') {
        (this.formControl as FormControl).enable();
        this.createAutocompleteEvent();

      } else {
        (this.formControl as FormControl).disable();
      }
      this.value = null;
    }
  }

  ngOnInit() {
    this.loading = true;

    this.form.addControl('estado',
      new FormControl('', Validators.required));

    if (this.estado === undefined) {
      (this.formControl as FormControl).disable();
    }
  }

  private getValue(): string {
    let startSearch = this.formControl.value === undefined ? '' : this.formControl.value;
    if (startSearch == null) {
      startSearch = '';
    }

    return startSearch;
  }

  ngAfterViewInit() {
    this.createAutocompleteEvent();
    this.cdRef.detectChanges();

    this.loading = false;
  }

  private createAutocompleteEvent() {
    this.reactiveCidades = this.formControl.valueChanges
      .distinctUntilChanged()
      .debounceTime(300)
      .map(val => this.displayFn(val))
      .map(name => this.pesquisar(name));
  }

  private pesquisar(_value) {
    let _data = new Array();

    this.filter(_value).subscribe(d => {
      super.responseEntityToArray(_data, d);
    });

    return _data;
  }

  displayFn(value: any): string {
    return value && typeof value === 'object' ? (value.cidade_nome) : value;
  }

  filter(val: string) {
    let searchValue = val === undefined ? '' : val;
    if (searchValue == null) {
      searchValue = '';
    }

    let estadoId: Number;
    if (this.estado !== undefined && this.estado !== null) {
      estadoId = this.estado.estado_id;
    }

    let _pageFilter = new MxPageFilter();
    _pageFilter.filterValue = {
      cidade: "%" + searchValue + "%",
      estado: estadoId
    };

    _pageFilter.page.pageNumber = 0;
    _pageFilter.page.size = 100;
    return this._service.searchAutocomplete(_pageFilter);
  }

}

