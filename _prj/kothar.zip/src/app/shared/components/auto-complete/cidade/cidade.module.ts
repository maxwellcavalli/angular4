import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { EstadoAutocompleteModule } from "../estado/estado.module";
import { CidadeAutocompleteComponent } from "./cidade.component";
import { SharedModule } from '../../../shared.module';

@NgModule({
  imports: [
    CommonModule,
    SharedModule,

    EstadoAutocompleteModule,

  ],
  declarations: [CidadeAutocompleteComponent],
  exports: [CidadeAutocompleteComponent]
})
export class CidadeAutocompleteModule { }
