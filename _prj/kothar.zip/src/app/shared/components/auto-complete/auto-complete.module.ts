import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { GrupoProdutoAutocompleteModule } from './grupo-produto/grupo-produto.module';
import { EstadoAutocompleteModule } from './estado/estado.module';
import { CidadeAutocompleteModule } from './cidade/cidade.module';
import { BairroAutocompleteModule } from './bairro/bairro.module';
import { ClienteAutocompleteModule } from './cliente/cliente.module';

@NgModule({
  imports: [
    CommonModule
  ],
  exports: [
    GrupoProdutoAutocompleteModule,
    EstadoAutocompleteModule,
    CidadeAutocompleteModule,
    BairroAutocompleteModule,
    ClienteAutocompleteModule
  ],
  declarations: []
})
export class AutoCompleteModule { }
