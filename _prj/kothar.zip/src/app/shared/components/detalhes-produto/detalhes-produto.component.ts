import { Component, OnInit, ViewChild, Input } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { MxGalleryImageContent, MxDialogComponent } from 'mx-components';

import { Produto } from '../../entity/produto';
import { ProdutoService } from '../../../service/produto.service';
import { ProdutoImagem } from '../../entity/produto-imagem';
import { MxBaseController } from 'mx-core';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'detalhes-produto',
  templateUrl: './detalhes-produto.component.html',
  styleUrls: ['./detalhes-produto.component.css']
})
export class DetalhesProdutoComponent extends MxBaseController implements OnInit {

  @ViewChild('dialogItemDetail') dialogItemDetail: MxDialogComponent;

  _produto: Produto;
  images: BehaviorSubject<Array<MxGalleryImageContent>> = new BehaviorSubject<Array<MxGalleryImageContent>>(null);

  mostrarDetalhesProduto: boolean = false;

  constructor(private _produtoService: ProdutoService,
    public translate: TranslateService) {
    super(translate);
  }

  ngOnInit() {

  }

  get produto() {
    return this._produto;
  }

  public openDialog(produto: Produto) {
    if (this._produto != produto) {
      this._produto = produto;
      this.images.next(null);

      if (this._produto != null && this._produto != undefined) {
        let id = this._produto.produto_id;
        this.getProduto(id)
      }
    }
  }

  private getProduto(id: Number) {
    this._produtoService.get(id).subscribe(
      ret => {
        let _prod = (ret.object as Produto);

        let _imagens = new Array<MxGalleryImageContent>();

        this.mostrarDetalhesProduto = _prod.detalhamento !== undefined && _prod.detalhamento !== null &&
          _prod.detalhamento.replace(new RegExp('\\/', 'g'), '') !== '';

        let count = 0;
        _prod.produto_imagens.forEach(el => {
          this._produtoService.getImagem(el.produto_imagem_id).subscribe(
            img => {
              let _img = (img.object as ProdutoImagem);

              let _imgContent: MxGalleryImageContent = new MxGalleryImageContent();
              _imgContent.content = _img.imagem64;

              _imagens.push(_imgContent);

              count++;

              if (count == _prod.produto_imagens.length) {
                this.images.next(_imagens);
              }
            },
            responseImg => this.afterResponse(responseImg));
        });

        this._produto = _prod;
        this.dialogItemDetail.openDialog();
      },
      response => this.afterResponse(response));
  }


  ngOnDestroy() {
    this.images.unsubscribe();
  }

}
