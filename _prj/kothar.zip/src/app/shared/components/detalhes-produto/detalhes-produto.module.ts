import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DetalhesProdutoComponent } from './detalhes-produto.component';
import { SharedModule } from '../../shared.module';

@NgModule({
  imports: [
    CommonModule,
    SharedModule
  ],
  declarations: [DetalhesProdutoComponent],
  exports: [DetalhesProdutoComponent]
})
export class DetalhesProdutoModule { }
