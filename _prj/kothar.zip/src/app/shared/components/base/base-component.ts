import { ControlValueAccessor } from '@angular/forms';
import { EventEmitter } from "@angular/core";

const noop = () => { }

export class BaseComponent implements ControlValueAccessor {

    _value: any = '';
    _disabled: boolean = false;

    private onTouchedCallback: () => void = noop;
    private onChangeCallback: (_: any) => void = noop;

    protected onWriteValue(_val: any) { }

    constructor() { }

    protected responseEntityToArray(arr: any, value: any) {
        let _responseEntity: any = value;
        let temp = _responseEntity.object.content;
        for (var x in temp) {
            arr.push(temp[x]);
        }
    }

    get value(): any {
        return this._value;
    }

    set value(v: any) {
        if (v !== this._value) {
            this._value = v;
            this.onChangeCallback(v);
        }
    }

    writeValue(obj: any): void {
        if (obj !== this._value) {
            this._value = obj;
            this.onWriteValue(obj);
        }
    }

    registerOnChange(fn: any): void {
        this.onChangeCallback = fn;
    }

    registerOnTouched(fn: any): void {
        this.onTouchedCallback = fn;
    }

    setDisabledState(isDisabled: boolean): void {
        this._disabled = isDisabled;
    }

    get disable(): boolean {
        return this._disabled;
    }

    protected mask(pattern: String): Array<any> {
        let ar = new Array<any>();
    
        for (let i = 0; i < pattern.length; i++) {
          if (pattern.charAt(i) == '9') {
            ar.push(/\d/);
          } else {
            ar.push(pattern.charAt(i));
          }
        }
        return ar;
      }
}
