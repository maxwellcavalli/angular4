import { BaseComponent } from "./base-component";

export class BaseAutoComplete extends BaseComponent {
    
    protected responseEntityToArray(arr: any, value: any) {
        let _responseEntity: any = value;
        let temp = _responseEntity.object.content;
        for (var x in temp) {
            arr.push(temp[x]);
        }
    }
}