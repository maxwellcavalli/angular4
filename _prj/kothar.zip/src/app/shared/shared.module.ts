import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TranslateModule } from '@ngx-translate/core';
import { RouterModule } from '@angular/router';
import { FlexLayoutModule } from '@angular/flex-layout';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { CKEditorModule } from 'ng2-ckeditor';

import { CurrencyMaskModule } from "ng2-currency-mask";
import { CurrencyMaskConfig, CURRENCY_MASK_CONFIG } from 'ng2-currency-mask/src/currency-mask.config';


import {
  MatFormFieldModule, MatInputModule, MatRippleModule,
  MatSidenavModule, MatToolbarModule, MatIconModule,
  MatButtonModule, MatAutocompleteModule, MatCheckboxModule, MAT_DATE_FORMATS,
  MAT_DATE_LOCALE, DateAdapter, MatMenuModule, MatSelectModule, MatRadioModule,
  MatDatepickerModule, MatPaginatorModule, MatExpansionModule


} from '@angular/material';


import {
  MxAccordionModule, MxSearchBoxModule, MxDataTableModule,
  MxCardModule, MxCrudBoxModule, MxDialogModule, MxUploadModule,
  MxInputTelefoneModule, MxInputCnpjCpfModule, MxTreeViewModule,
  MxDateModule, MxClockPickerModule, CUSTOM_DATE_FORMATS, CustomDateAdapter,
  MxGalleryModule, MxRatingModule
} from 'mx-components';

import { ServiceModule } from '../service/service.module';
import { Decode64Pipe } from './pipe/decode64.pipe';
import { SafeHtmlPipe } from './pipe/safe-html.pipe';
import { AutofocusDirective } from './directive/auto-focus';
import { TextMaskModule } from 'angular2-text-mask';
import { AgmCoreModule } from '@agm/core';
import { DirectionsMapDirective } from './directive/directions.directive';
import { NumberOnlyDirective } from './directive/only-number';

export const CustomCurrencyMaskConfig: CurrencyMaskConfig = {
  align: "right",
  allowNegative: true,
  allowZero: true,
  decimal: ",",
  precision: 2,
  prefix: "",
  suffix: "",
  thousands: "."
};


@NgModule({
  imports: [
    CommonModule
  ],
  exports: [
    RouterModule,
    TranslateModule,

    MxAccordionModule, MxSearchBoxModule, MxDataTableModule,
    MxCardModule, MxCrudBoxModule, MxDialogModule, MxUploadModule,
    MxInputTelefoneModule, MxInputCnpjCpfModule, MxTreeViewModule,
    MxDateModule, MxClockPickerModule, MxGalleryModule, MxRatingModule,

    FlexLayoutModule,
    FormsModule, ReactiveFormsModule,

    MatFormFieldModule, MatInputModule, MatRippleModule,
    MatSidenavModule, MatToolbarModule, MatIconModule,
    MatButtonModule, MatAutocompleteModule, MatCheckboxModule,
    MatExpansionModule, MatSelectModule, MatRadioModule,
    MatDatepickerModule, MatPaginatorModule, MatMenuModule, 
    AgmCoreModule,

    ServiceModule,

    Decode64Pipe, SafeHtmlPipe,
    AutofocusDirective,
    DirectionsMapDirective,
    NumberOnlyDirective,

    CKEditorModule,

    TextMaskModule,
    CurrencyMaskModule,


  ],
  declarations: [Decode64Pipe, SafeHtmlPipe, AutofocusDirective, DirectionsMapDirective, NumberOnlyDirective],
  providers: [
    { provide: MAT_DATE_FORMATS, useValue: CUSTOM_DATE_FORMATS },
    { provide: MAT_DATE_LOCALE, useValue: 'pt-BR' },
    { provide: DateAdapter, useClass: CustomDateAdapter },
    { provide: CURRENCY_MASK_CONFIG, useValue: CustomCurrencyMaskConfig }

  ]
})
export class SharedModule { }
