import { GoogleMapsAPIWrapper } from '@agm/core/services/google-maps-api-wrapper';
import { Directive, Input } from '@angular/core';
declare var google: any;

@Directive({
    selector: '<agm-map-directions  [origin]="origin" [destination]="destination" #test></agm-map-directions>'
})
export class DirectionsMapDirective {
    @Input() origin: any;
    @Input() destination: any;

    constructor(private gmapsApi: GoogleMapsAPIWrapper) {
    }

    ngOnDestroy () {
    }

    ngAfterViewInit(){
    }

    ngAfterViewChecked(){
        let _div = document.getElementById('directionsPanel') as HTMLDivElement;
        if (_div){
            if (_div.childNodes.length > 1){
                _div.removeChild(_div.firstChild);
            }
        }
    }

    ngOnInit() {
        this.gmapsApi.getNativeMap().then(map => {
            let _div = document.getElementById('directionsPanel') as HTMLDivElement;

            var directionsService = new google.maps.DirectionsService;
            var directionsDisplay = new google.maps.DirectionsRenderer;

            directionsDisplay.setMap(map);            
            directionsDisplay.setPanel(document.getElementById('directionsPanel'));

            directionsService.route({
                origin: { lat: this.origin.latitude, lng: this.origin.longitude },
                destination: { lat: this.destination.latitude, lng: this.destination.longitude },
                waypoints: [],
                optimizeWaypoints: true,
                travelMode: 'DRIVING'
            }, function (response: any, status: any) {
                if (status === 'OK') {
                    directionsDisplay.setDirections(response);
                } else {
                    window.alert('Directions request failed due to ' + status);
                }
            });

        });
    }
}