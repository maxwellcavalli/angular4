import { Directive, ElementRef, Renderer, Input, Inject, ChangeDetectorRef } from '@angular/core';

@Directive({
    selector: '[focus]'
})
export class AutofocusDirective {
    constructor(private el: ElementRef, private renderer: Renderer,
        private cdRef: ChangeDetectorRef) {
    }

    ngAfterViewInit() {
        this.renderer.invokeElementMethod(this.el.nativeElement, 'focus');
        this.cdRef.detectChanges();
    }

    ngOnInit() { }


}