import { MxBaseEntity } from "mx-core";

export class Categoria extends MxBaseEntity {

    categoria_id: Number;
    categoria_nome: String;
    imagem64: String;

}
