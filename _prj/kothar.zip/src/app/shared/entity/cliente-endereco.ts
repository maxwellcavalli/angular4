import { MxBaseEntity } from "mx-core";

import { Usuario } from "./usuario";
import { Cep } from "./cep";
import { EnderecoComplemento } from "./endereco-complemento";

export class ClienteEndereco extends MxBaseEntity {

    cliente_endereco_id: Number;
    cliente_endereco_cep: Cep = new Cep();
    cliente_endereco_complemento: EnderecoComplemento = new EnderecoComplemento();    
    cliente_endereco_principal: boolean;
    cliente_endereco_alias: String;
    

    //utilizado para selecionar o endereco para o envio da cotacao
    cliente_endereco_selecionado: boolean = false;
        
}
