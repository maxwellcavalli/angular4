import { MxBaseEntity } from "mx-core";

import { GrupoProduto } from "./grupo-produto";
import { Fornecedor } from "./fornecedor";

export class FornecedorGrupoProduto extends MxBaseEntity {

    fornecedor_grupo_produto_id: Number;
    fornecedor: Fornecedor;
    grupoProduto: GrupoProduto;

}
