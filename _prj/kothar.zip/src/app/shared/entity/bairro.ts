import { Cidade } from "./cidade";
import { MxBaseEntity } from "mx-core";

export class Bairro extends MxBaseEntity {
    bairro_id: Number;
    bairro_nome: String;
    bairro_cidade: Cidade = new Cidade();

}