import { MxBaseEntity } from "mx-core";

export class Estado extends MxBaseEntity {
    estado_id: Number;
    estado_nome: String;
    sigla: String;

}