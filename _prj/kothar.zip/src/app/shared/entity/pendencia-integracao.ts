import { Usuario } from "./usuario";
import { MxBaseEntity } from "mx-core";

export class PendenciaIntegracao extends MxBaseEntity {

    pendencia_integracao_id: Number;
    data_criacao: Date;
    data_alteracao: Date;
    usuario_criacao: Usuario;
    tipo_pendencia: any;
    tipo_pendencia_str: String;
    finalizado: boolean;

    objectStr: String; 

}
