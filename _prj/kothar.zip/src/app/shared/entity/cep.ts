import { MxBaseEntity } from "mx-core";

import { Bairro } from "./bairro";
import { EnderecoComplemento } from "./endereco-complemento";

export class Cep extends MxBaseEntity {
    cep_id: Number;
    cep_nome: String;
    codigoPostal: String;
    cep_bairro: Bairro = new Bairro();
    endereco_complemento: EnderecoComplemento = new EnderecoComplemento();

}