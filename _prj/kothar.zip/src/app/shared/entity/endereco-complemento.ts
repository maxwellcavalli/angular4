import { MxBaseEntity } from "mx-core";

export class EnderecoComplemento extends MxBaseEntity {
    endereco_complemento_id: Number;
    numero: String;
    complemento: String;

    latitude: Number;
    longitude: Number;

}
