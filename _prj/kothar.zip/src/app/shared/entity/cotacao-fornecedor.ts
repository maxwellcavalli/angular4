import { MxBaseEntity } from "mx-core";

import { Categoria } from "./categoria";
import { Cliente } from "./cliente";
import { CotacaoItem } from "./cotacao-item";
import { CotacaoItemFornecedor } from "./cotacao-item-fornecedor";
import { Fornecedor } from "./fornecedor";

export class CotacaoFornecedor extends MxBaseEntity {
    cotacao_fornecedor_id: Number;
    fornecedor: Fornecedor;
    data_recusa: Date;
    enviado: boolean;
    entrega: String;

    tipo_pagamento: any;
    numero_parcelas: Number;
    juros_parcelamento: Number;

    tipo_juros_pagamento: any;
    data_validade: Date;

}