import { MxBaseEntity } from "mx-core";

export class GrupoProduto extends MxBaseEntity {
    grupo_produto_id: Number;
    grupo_produto_nome: string;
    grupo_produto_parent: GrupoProduto;
    grupo_produto_children: Array<GrupoProduto>;

    selecionado: boolean;
    indeterminate: boolean;
}
