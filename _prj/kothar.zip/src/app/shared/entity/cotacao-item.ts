import { MxBaseEntity } from "mx-core";

import { Produto } from "./produto";
import { CotacaoItemArquivo } from "./cotacao-item-arquivo";

export class CotacaoItem extends MxBaseEntity {
    
cotacao_item_id: Number;
cotacao_item_produto: Produto;
quantidade: Number;
observacao: String;

cotacao_item_arquivos: Array<CotacaoItemArquivo> = new Array<CotacaoItemArquivo>();

}