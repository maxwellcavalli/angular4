import { Cidade } from "./cidade";
import { MxBaseEntity } from "mx-core";
import { CotacaoFornecedor } from "./cotacao-fornecedor";

export class Avaliacao extends MxBaseEntity {
    
    avaliacao_id: Number;
    detalhamento: String;
    numero_estrelas: number;
    cotacaoFornecedor: CotacaoFornecedor;
    motivoDesistenciaCompraType: any;
    motivo_desistencia_compra_str: String;


}