import { MxBaseEntity } from "mx-core";
import { Produto } from "./produto";
import { CotacaoItemArquivo } from "./cotacao-item-arquivo";

export class CotacaoItemFornecedorValor extends MxBaseEntity {

    cotacao_item_fornecedor_valor_id: Number;
    valor_unitario: Number;
    marca_modelo: String;
    data_atualizacao: Date;
    selecionado: Boolean;
}