import { MxBaseEntity } from "mx-core";

import { Cep } from "./cep";
import { EnderecoComplemento } from "./endereco-complemento";

export class CotacaoEndereco extends MxBaseEntity {
    cotacao_endereco_id: Number;
    cotacao_endereco_alias: String;
    cotacao_endereco_cep: Cep = new Cep();
    cotacao_endereco_complemento: EnderecoComplemento = new EnderecoComplemento();

}