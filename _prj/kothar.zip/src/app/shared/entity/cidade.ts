import { MxBaseEntity } from "mx-core";

import { Estado } from "./estado";

export class Cidade extends MxBaseEntity {
    cidade_id: Number;
    cidade_nome: String;
    cidade_estado: Estado = new Estado();

}