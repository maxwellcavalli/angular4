import { MxBaseEntity } from "mx-core";

import { Usuario } from "./usuario";
import { ClienteEndereco } from "./cliente-endereco";

export class Cliente extends MxBaseEntity {

    cliente_id: Number;
    cliente_nome: String;
    cpf: String;
    cpf_format: String;
    cliente_usuario: Usuario = new Usuario();
    cliente_primeiro_nome: String;
    
    cliente_enderecos: Array<ClienteEndereco> = new Array<ClienteEndereco>();
}
