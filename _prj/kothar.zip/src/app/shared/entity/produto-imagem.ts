import { MxBaseEntity } from "mx-core";

export class ProdutoImagem extends MxBaseEntity {
    produto_imagem_id: Number;
    produto_imagem_nome: string;    
    imagem64: String;    
    produto_imagem_principal: Boolean;
    ativo: Boolean;

    display_on_gallery: boolean = false;

}
