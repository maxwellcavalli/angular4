import { MxBaseEntity } from "mx-core";

import { Usuario } from "./usuario";
import { Cep } from "./cep";
import { EnderecoComplemento } from "./endereco-complemento";
import { GrupoProduto } from "./grupo-produto";
import { ClienteFornecedor } from "./cliente-fornecedor";

export class Fornecedor extends MxBaseEntity {

    fornecedor_id: Number;
    fornecedor_nome: String;
    cpf_cnpj: String;
    cpf_cnpj_format: String;    
    fornecedor_cep: Cep;
    fornecedor_endereco: EnderecoComplemento = new EnderecoComplemento();
    fornecedor_grupo: Array<GrupoProduto>;
    email: String;
    telefone: String;
    uuid: String;

    clientes: Array<ClienteFornecedor>;

}
