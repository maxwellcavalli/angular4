import { MxBaseEntity } from "mx-core";

export class Usuario extends MxBaseEntity{
    usuario_id: Number;
    usuario_nome: String;
    username: String;
    password: String;
    email: String;
    updated: Date;
    lastLogin: Date;
    token: String;
    telefone: String;
    passwordLogin: String;
    usuario_situacoes: Array<any>;
    usuario_situacao: any;
    usuario_situacao_str: String;

    admin: boolean;

}