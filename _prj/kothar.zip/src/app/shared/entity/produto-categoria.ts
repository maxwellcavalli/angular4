import { MxBaseEntity } from "mx-core";
import { Produto } from "./produto";
import { Categoria } from "./categoria";

export class ProdutoCategoria extends MxBaseEntity {

    produto_categoria_id: Number;
    produto_categoria_produto: Produto;
    produto_categoria_categoria: Categoria;

}