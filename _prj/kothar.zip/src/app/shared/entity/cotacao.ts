import { MxBaseEntity } from "mx-core";

import { Categoria } from "./categoria";
import { Cliente } from "./cliente";
import { CotacaoItem } from "./cotacao-item";
import { CotacaoItemFornecedor } from "./cotacao-item-fornecedor";
import { CotacaoFornecedor } from "./cotacao-fornecedor";
import { CotacaoEndereco } from "./cotacao-endereco";

export class Cotacao extends MxBaseEntity {
    cotacao_id: Number;
    cotacao_nome: String;

    dataCadastro: Date = new Date();
    dataLimiteRetorno: Date;
    dataEnvio: Date;
    
    cotacao_cliente: Cliente = new Cliente();
    situacaoCotacao: any;
    observacao: String;
    cotacao_situacao_str: String;

    cotacao_item: Array<CotacaoItem> = new Array<CotacaoItem>();
    cotacao_fornecedor_item: Array<CotacaoItemFornecedor> = new Array<CotacaoItemFornecedor>();

    //utilizado para informar para qual endereco a cotacao tera como destino de entrega
    cotacao_endereco: CotacaoEndereco = new CotacaoEndereco();

    //usado somente para enviar a resposta
    cotacao_fornecedor: CotacaoFornecedor = new CotacaoFornecedor();
    cotacao_permite_resposta: boolean;
    cotacao_permite_recusar: boolean;
    cotacao_situacao_resposta_fornecedor: String;

    //utilizado somente para controle da cotacao
    cotacao_permite_alteracoes: boolean;

    cotacao_quantidade_respostas: Number;
    //utilizado para validar se o usuario pode cancelar uma cotacao
    cotacao_permite_cancelar: boolean;

    cotacao_iniciada: boolean = false;

    cotacao_hora: string;

    /*usado na avaliacao */
    cotacao_data_lembrete_avaliacao: Date;
    cotacao_data_avaliacao: Date;

}