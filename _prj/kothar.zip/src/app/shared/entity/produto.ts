import { MxBaseEntity } from "mx-core";

import { GrupoProduto } from './grupo-produto';
import { Categoria } from "./categoria";
import { ProdutoImagem } from "./produto-imagem";

export class Produto extends MxBaseEntity {
    produto_id: Number;
    produto_nome: string;
	produto_grupo_produto: GrupoProduto;
    generico: boolean = false;
    detalhamento: string;
    situacaoProduto: any;

    em_cotacao: boolean;

    produto_imagens: Array<ProdutoImagem> = new Array<ProdutoImagem>();
    produto_imagem_principal: ProdutoImagem;

    possui_imagem: boolean = false;


    //atributo nao persistente
    selecionado: boolean = false;

}
