import { MxBaseEntity } from "mx-core";

import { Produto } from "./produto";

export class CotacaoItemArquivo extends MxBaseEntity {
    
cotacao_item_arquivo_id: Number;
cotacao_item_arquivo_nome: String;
imagem64: String;

}