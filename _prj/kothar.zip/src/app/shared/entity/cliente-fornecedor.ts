import { MxBaseEntity } from "mx-core";

import { Fornecedor } from "./fornecedor";
import { Cliente } from "./cliente";

export class ClienteFornecedor extends MxBaseEntity {

    cliente_fornecedor_id: Number;
    fornecedor: Fornecedor; 
    cliente: Cliente;
    internalIndex: number;
   
}
