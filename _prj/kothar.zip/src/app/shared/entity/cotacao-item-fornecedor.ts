import { MxBaseEntity } from "mx-core";

import { CotacaoItem } from "./cotacao-item";
import { CotacaoItemFornecedorValor } from "./cotacao-item-fornecedor-valor";
import { CotacaoFornecedor } from "./cotacao-fornecedor";

export class CotacaoItemFornecedor extends MxBaseEntity {

    cotacao_item_fornecedor_id: Number;
    cotacao_item: CotacaoItem;
    cotacao_fornecedor: CotacaoFornecedor;
    data_recusa: Date;
    valores: Array<CotacaoItemFornecedorValor> = new Array<CotacaoItemFornecedorValor>();
    ignorar_item: boolean;

    /*somente para itens nao genericos */
    valor_unitario: Number;
}