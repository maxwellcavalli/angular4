import { Component, OnInit, HostListener, NgZone, ViewChild, ElementRef } from '@angular/core';
import { TemplateComponent } from '../template/template.component';
import { LoggedController } from '../../shared/guard/logged-controller';
import { AuthenticationService } from '../../service/security/authentication.service';
import { Router, ActivatedRoute } from '@angular/router';
import { ClienteService } from '../../service/cliente.service';
import { MxResponseEntity, MxBaseController } from 'mx-core';
import { TranslateService } from '@ngx-translate/core';
import { Cliente } from '../../shared/entity/cliente';
import { CotacaoService } from '../../service/cotacao.service';
import { SharedDataService } from '../../shared/data/shared-data.service';
import { Subject } from 'rxjs';
import { log } from 'util';
import { Menu } from '../template/menu';

declare const google: any;

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
  host: {
    '(window:resize)': 'onResize($event)'
  }
})
export class DashboardComponent extends MxBaseController implements OnInit {

  cliente: Cliente;
  private _destroy: Subject<any> = new Subject<any>();
  dataAtualizacao: Date = null;
  quantidadePendentes: Number = 0;

  private interval: any;

  public mostraFornecedor: boolean = false;

  public rating = 25;
  public totalAvaliacoes = 150;

  constructor(
    protected _authenticationService: AuthenticationService,
    protected router: Router,
    protected route: ActivatedRoute,
    public translate: TranslateService,
    private _clienteService: ClienteService,
    private ngZone: NgZone,
    private _cotacaoService: CotacaoService,
    private _sharedDataService: SharedDataService) {

    super(translate);

    _sharedDataService.fornecedor
      .takeUntil(this._destroy)
      .subscribe(ret => {
        this.mostraFornecedor = ret != undefined && ret != null;
      })
  }

  onResize(event) {
    this.initGraphicsFornecedor();
    this.initGraphicsCliente(this.cliente);
  }

  ngOnInit() {
    this._authenticationService.isLogged().subscribe(el => {
      if (el === true) {
        this.init();

        this.interval = window.setInterval(() => {
          this.initGraphicsFornecedor();
          this.initGraphicsCliente(this.cliente);

        }, 1000 * 60);
      }
    });
  }

  ngOnDestroy() {
    window.clearInterval(this.interval);

    this._destroy.next();
    this._destroy.unsubscribe();
  }

  private init() {
    this._clienteService.getLogged().subscribe(
      data => this.afterGet(data),
      response => this.afterResponse(response));

    this.initGraphicsFornecedor();
  }

  private initGraphicsFornecedor() {
    if (!this._destroy.isStopped) {
      this._sharedDataService.fornecedor
        .takeUntil(this._destroy)
        .subscribe(
        data => {
          this.loadInfoCotacoesVencedorasFornecedor(data);
          this.loadEstatisticasCotacoesFornecedor(data);
        },
        response => this.afterResponse(response)
        );
    }
  }

  private initGraphicsCliente(cliente: Cliente) {
    this.loadEstatisticasCotacoesCliente(cliente);
  }

  private loadEstatisticasCotacoesFornecedor(fornecedor) {
    if (fornecedor == undefined || fornecedor == null) {
      return;
    }

    this._cotacaoService.findEstatisticasCotacaoFornecedor(fornecedor).subscribe(
      data => {
        this.createGraphicsStatisticsFornecedor(data);
        this.dataAtualizacao = new Date();
        this.quantidadePendentes = (data.object as any)[0].pendente;

        let _m = Menu.getMenuByKey('menu_resposta_cotacao');
        _m.badge = this.quantidadePendentes;
      },
      response => this.afterResponse(response)
    );
  }

  private loadEstatisticasCotacoesCliente(cliente) {
    if (cliente == undefined || cliente == null) {
      return;
    }

    this._cotacaoService.findEstatisticasCotacaoCliente(cliente).subscribe(
      data => {
        this.createGraphicsStatisticsCliente(data);
      },
      response => this.afterResponse(response)
    );
  }

  private loadInfoCotacoesVencedorasFornecedor(fornecedor) {
    if (fornecedor == undefined || fornecedor == null) {
      return;
    }

    this._cotacaoService.findMinhasCotacoesVencedorasFornecedor(fornecedor).subscribe(
      data => this.createGraphicMonth(data),
      response => this.afterResponse(response)
    )
  }

  private createGraphicsStatisticsFornecedor(data: any) {

    google.charts.load("current", { packages: ["corechart"] });
    google.charts.setOnLoadCallback(drawChart);
    function drawChart() {

      let _row = data.object as any;
      let pendente = _row[0].pendente;
      let perdedor = _row[0].perdedor;
      let recusado = _row[0].recusado;
      let total = _row[0].total;
      let vencedor = _row[0].vencedor;

      var dataWinner = google.visualization.arrayToDataTable([
        ['Budget', 'Total'],
        ['All', (total - vencedor)],
        ['Winner', vencedor]
      ]);

      var dataRefused = google.visualization.arrayToDataTable([
        ['Budget', 'Total'],
        ['All', (total - recusado)],
        ['Refused', recusado]
      ]);

      var dataAllStatus = google.visualization.arrayToDataTable([
        ['Budget', 'Total'],
        ['Loser', perdedor],
        ['Winner', vencedor],
        ['Pending', pendente],
        ['Refused', recusado]
      ]);

      var options = {
        pieHole: 0.5,
        backgroundColor: 'transparent',
        pieSliceText: 'value',
        pieSliceTextStyle: {
          color: 'black',
        },
        legend: 'none',
        width: '100%',
        height: '100%',

        colors: ['#d4d4d4', '#92cf77', '#f5bc33', '#d77e7f'],
        chartArea: { left: 50, top: 20, width: '100%', height: '70%' },
      };

    //d4d4d4
      var colorsGraph1 = { colors: ['#9a99fd', '#92cf77'] };
      var colorsGraph2 = { colors: ['#9a99fd', '#d77e7f'] };
      var colorsGraph3 = { colors: ['#a7a6a6', '#92cf77', '#f5bc33', '#d77e7f'] };


      var optionsGraph1 = Object.assign({}, options);
      var optionsGraph2 = Object.assign({}, options);
      var optionsGraph3 = Object.assign({}, options);

      optionsGraph1.colors = colorsGraph1.colors;
      optionsGraph2.colors = colorsGraph2.colors;
      optionsGraph3.colors = colorsGraph3.colors;

      var chart = new google.visualization.PieChart(document.getElementById('winnerChart'));
      chart.draw(dataWinner, optionsGraph1);

      var chart = new google.visualization.PieChart(document.getElementById('refusedChart'));
      chart.draw(dataRefused, optionsGraph2);

      var chart = new google.visualization.PieChart(document.getElementById('allStatusChart'));
      chart.draw(dataAllStatus, optionsGraph3);

      let winnerChart = document.getElementById('winnerChart');
      (winnerChart.firstChild.firstChild as HTMLElement).style.removeProperty('width');
      (winnerChart.firstChild.firstChild as HTMLElement).style.removeProperty('height');

      let refusedChart = document.getElementById('refusedChart');
      (refusedChart.firstChild.firstChild as HTMLElement).style.removeProperty('width');
      (refusedChart.firstChild.firstChild as HTMLElement).style.removeProperty('height');

      let allStatusChart = document.getElementById('allStatusChart');
      (allStatusChart.firstChild.firstChild as HTMLElement).style.removeProperty('width');
      (allStatusChart.firstChild.firstChild as HTMLElement).style.removeProperty('height');
    }
  }

  private createGraphicsStatisticsCliente(data: any) {

    google.charts.load("current", { packages: ["corechart"] });
    google.charts.setOnLoadCallback(drawChart);
    function drawChart() {

      let _row = data.object as any;

      console.log(_row);
      
      let pendente = _row[0].pendente;
      let enviadoSemResposta = _row[0].enviadoSemResposta;
      let enviadoComResposta = _row[0].enviadoComResposta;
      let cancelado = _row[0].cancelado;
      let total = _row[0].total;

      var dataPending = google.visualization.arrayToDataTable([
        ['Budget', 'Total'],
        ['All', (total - pendente)],
        ['Pending', pendente]
      ]);

      var dataAnswear = google.visualization.arrayToDataTable([
        ['Budget', 'Total'],
        ['All', (total - enviadoSemResposta - enviadoComResposta)],
        ['With Answear', enviadoComResposta],
        ['Without Answear', enviadoSemResposta]
      ]);

      var dataAllStatus = google.visualization.arrayToDataTable([
        ['Budget', 'Total'],
        ['Without Answear', enviadoSemResposta],
        ['With Answear', enviadoComResposta],
        ['Pending', pendente],
        ['Canceled', cancelado]
      ]);


      var options = {
        pieHole: 0.5,
        backgroundColor: 'transparent',
        pieSliceText: 'value',
        pieSliceTextStyle: {
          color: 'black',
        },
        legend: 'none',
        width: '100%',
        height: '100%',

        colors: ['#d4d4d4', '#92cf77', '#f5bc33', '#d77e7f'],
        chartArea: { left: 50, top: 20, width: '100%', height: '70%' },
      };

      var colorsGraph1 = { colors: ['#9a99fd', '#92cf77'] };
      var colorsGraph2 = { colors: ['#9a99fd', '#92cf77', '#f5bc33'] };
      var colorsGraph3 = { colors: ['#a7a6a6', '#92cf77', '#f5bc33', '#d77e7f'] };


      var optionsGraph1 = Object.assign({}, options);
      var optionsGraph2 = Object.assign({}, options);
      var optionsGraph3 = Object.assign({}, options);

      optionsGraph1.colors = colorsGraph1.colors;
      optionsGraph2.colors = colorsGraph2.colors;
      optionsGraph3.colors = colorsGraph3.colors;

      var chart = new google.visualization.PieChart(document.getElementById('penddingChart'));
      chart.draw(dataPending, optionsGraph1);

      var chart = new google.visualization.PieChart(document.getElementById('answearChart'));
      chart.draw(dataAnswear, optionsGraph2);

      var chart = new google.visualization.PieChart(document.getElementById('allStatusClienteChart'));
      chart.draw(dataAllStatus, optionsGraph3);


      let penddingChart = document.getElementById('penddingChart');
      (penddingChart.firstChild.firstChild as HTMLElement).style.removeProperty('width');
      (penddingChart.firstChild.firstChild as HTMLElement).style.removeProperty('height');

      let answearChart = document.getElementById('answearChart');
      (answearChart.firstChild.firstChild as HTMLElement).style.removeProperty('width');
      (answearChart.firstChild.firstChild as HTMLElement).style.removeProperty('height');

      let allStatusClienteChart = document.getElementById('allStatusClienteChart');
      (allStatusClienteChart.firstChild.firstChild as HTMLElement).style.removeProperty('width');
      (allStatusClienteChart.firstChild.firstChild as HTMLElement).style.removeProperty('height');
    }
  }

  private createGraphicMonth(data: any) {
    google.charts.load("current", { packages: ["corechart"] });
    google.charts.setOnLoadCallback(drawChart);
    function drawChart() {

      let dados = data.object as any;

      let _arr = new Array<any>();

      _arr.push(['Month', 'Budgets']);
      dados.forEach(el => {
        let _o = [el.mesAno, el.quantidade];
        _arr.push(_o)
      });

      var dataGraph = google.visualization.arrayToDataTable(_arr);

      var optionsLine = {
        legend: { position: 'none' },
        backgroundColor: 'transparent',
        height: 235,
        chartArea: { left: 50, top: 20, width: '100%', height: '70%' },
      };

      var chart = new google.visualization.LineChart(document.getElementById('curve_chart'));
      chart.draw(dataGraph, optionsLine);

    }
  }

  ngAfterViewInit() {
    //this.loadChart();

  }

  protected afterGet(data: MxResponseEntity) {
    this.cliente = (data.object as Cliente)
    this.initGraphicsCliente(this.cliente);
  }

  private loadChart() {
    if (document.getElementById('winnerChart') == null) {
      return;
    }


  }


}
