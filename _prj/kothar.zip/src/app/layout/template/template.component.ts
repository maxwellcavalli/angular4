import { Component, OnInit, ViewChild, ElementRef, HostListener } from '@angular/core';
import { MatSidenav } from '@angular/material';
import { Usuario } from '../../shared/entity/usuario';
import { Fornecedor } from '../../shared/entity/fornecedor';
import { AuthenticationService } from '../../service/security/authentication.service';
import { SharedDataService } from '../../shared/data/shared-data.service';
import { Subject, BehaviorSubject } from 'rxjs';
import { FornecedorService } from '../../service/fornecedor.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Cotacao } from '../../shared/entity/cotacao';
import { CotacaoService } from '../../service/cotacao.service';
import { MxBaseController } from 'mx-core';
import { TranslateService } from '@ngx-translate/core';
import { Menu } from './menu';
import { AcessosService } from '../../service/acessos.service';
import { ClienteService } from '../../service/cliente.service';
import { Cliente } from '../../shared/entity/cliente';

@Component({
  selector: 'app-template',
  templateUrl: './template.component.html',
  styleUrls: ['./template.component.scss']
})
export class TemplateComponent extends MxBaseController implements OnInit {

  @ViewChild('sidemenu') sidemenu: MatSidenav;
  @ViewChild('dadosCotacao') dadosCotacao: ElementRef;
  @ViewChild('menuUsuario') menuUsuario: ElementRef;

  URL_EDIT: String = "/modules/budget/cotacao/cotacao-form/";

  collapseSidebar: boolean;

  usuario: Usuario;
  fornecedor: Fornecedor = new Fornecedor();
  mostraFornecedor: boolean = false;

  mostraComboFornecedor: boolean = false;

  fornecedores: BehaviorSubject<Array<Fornecedor>> = new BehaviorSubject<Array<Fornecedor>>(null);
  private _destroy: Subject<Fornecedor> = new Subject<Fornecedor>();

  quantidadeItens: string = '0';
  cotacao: Cotacao;
  menus: any;

  constructor(
    public router: Router,
    public route: ActivatedRoute,
    public translate: TranslateService,
    private _authenticationService: AuthenticationService,
    private _sharedDataService: SharedDataService,
    private _fornecedorService: FornecedorService,
    private _cotacaoService: CotacaoService,
    private _acessosService: AcessosService,
    private _clienteService: ClienteService) {
    super(translate);
  }

  private afterLoadMenus() {
    let _m = this._sharedDataService.menus.value;
    if (_m != null && _m != undefined){
      let _menus = new Array<any>();

      _m.forEach(el => {
        let _r = this.loadMenusAtivos(el);
        if (_r != null) {
          _menus.push(_r);
        }
      });

      this.menus = _menus; 
    }
  }

  private loadMenusAtivos(menu: any) {
    if (menu.visible == true) {
      let _newMenu = Object.assign({}, menu);
      _newMenu.children = new Array<any>();

      if (menu.children) {
        menu.children.forEach(el => {
            let _r = this.loadMenusAtivos(el);
            if (_r != null) {
              _newMenu.children.push(_r);
            }
        });
      }

      return _newMenu;
    } else {
      return null;
    }
  }

  ngOnInit() {
    this.afterLoadMenus();    

    let _usu = this._authenticationService.getUser();
    this.usuario = _usu;

    this._sharedDataService.fornecedor
      .takeUntil(this._destroy)
      .subscribe(data => {
        this.fornecedor = data;
      });

    this._sharedDataService.cotacao
      .takeUntil(this._destroy)
      .subscribe(data => {
        this.cotacao = data;
        if (data) {
          if (data.cotacao_item !== undefined && data.cotacao_item !== null) {
            if (data.cotacao_item.length > 99) {
              this.quantidadeItens = data.cotacao_item.length + '+';
            } else {
              this.quantidadeItens = data.cotacao_item.length + '';
            }
          }
        }
      });

    this._fornecedorService.searchFornecedoresByCliente().subscribe(data => {
      let fornecedores = data.object as Array<Fornecedor>;
      this.fornecedores.next(fornecedores);

      if (fornecedores.length > 0) {
        this._sharedDataService.fornecedor.next(fornecedores[0]);
      }

      this.mostraFornecedor = fornecedores.length > 0;
      this.mostraComboFornecedor = fornecedores.length > 1;
    });
  }

  public toggle() {
    this.sidemenu.toggle();

    setTimeout(() => {
      this.forceResize();
    }, 300);
  }

  private forceResize() {
    var evt = window.document.createEvent('UIEvents');
    evt.initUIEvent('resize', true, false, window, 0);
    window.dispatchEvent(evt);
  }

  ngOnDestroy() {
    this.fornecedores.unsubscribe();

    this._destroy.next();
    this._destroy.unsubscribe();
  }

  changeFornecedor(event: string): void {
    let fornecedor = JSON.parse(event);
    this._sharedDataService.fornecedor.next(fornecedor);
  }

  isOver(): boolean {
    return window.matchMedia(`(max-width: 960px)`).matches;
  }

  isMac(): boolean {
    let bool = false;
    if (navigator.platform.toUpperCase().indexOf('MAC') >= 0 || navigator.platform.toUpperCase().indexOf('IPAD') >= 0) {
      bool = true;
    }
    return bool;
  }

  menuMouseOver(): void {
    if (window.matchMedia(`(min-width: 960px)`).matches && this.collapseSidebar) {
      this.sidemenu.mode = 'over';
    }
  }

  menuMouseOut(): void {
    if (window.matchMedia(`(min-width: 960px)`).matches && this.collapseSidebar) {
      this.sidemenu.mode = 'side';
    }
  }

  redirectToCotacao() {
    if (this.cotacao != null && this.cotacao != undefined) {
      let _div = this.dadosCotacao.nativeElement;

      if (!_div.classList.contains('collapsed')) {
        _div.classList.add('collapsed');
      }

      let url = this.URL_EDIT + (this.cotacao.cotacao_id as any);
      this.router.navigate([url]);
    }
  }

  showCotacaoDetails() {
    let _divCotacao = this.dadosCotacao.nativeElement;

    if (_divCotacao.classList.contains('collapsed')) {
      _divCotacao.classList.remove('collapsed');
    } else {
      _divCotacao.classList.add('collapsed');
    }

    let _divMenuUsuario = this.menuUsuario.nativeElement;
    if (!_divMenuUsuario.classList.contains('collapsed')) {
      _divMenuUsuario.classList.add('collapsed')
    }
  }

  showMenuUsuario() {
    let _divMenuUsuario = this.menuUsuario.nativeElement;

    if (_divMenuUsuario.classList.contains('collapsed')) {
      _divMenuUsuario.classList.remove('collapsed');
    } else {
      _divMenuUsuario.classList.add('collapsed');
    }


    let _divCotacao = this.dadosCotacao.nativeElement;
    if (!_divCotacao.classList.contains('collapsed')) {
      _divCotacao.classList.add('collapsed')
    }
  }

  private isClickOnClass(el: any, styleClass: Array<any>) {
    let classList = el.classList;

    classList = (classList == undefined || classList == null) ? new Array<any>() : classList;

    let hasClass = false;
    if (classList.length > 0) {
      styleClass.forEach(el => {
        if (classList.contains(el)) {
          hasClass = true;
        }
      });
    }

    if (!hasClass) {
      if (el.parentNode !== undefined && el.parentNode !== null) {
        return this.isClickOnClass(el.parentNode, styleClass);
      } else {
        return false;
      }
    } else {
      return true;
    }

  }

  @HostListener('click', ['$event'])
  onClick(e: any) {

    var clickedEl = e.target;
    this.validateClick(clickedEl);
  }

  private validateClick(clickedEl: any) {
    let classesCotacao = [
      'painel-dados-cotacao-all',
      'action-toolbar-options-usuario',
      'painel-menu-usuario-content',
      'action-toolbar-options-usuario-nome'
    ];

    let _hasClass = this.isClickOnClass(clickedEl, classesCotacao);

    if (_hasClass === false) {
      let _divCotacao = this.dadosCotacao.nativeElement;
      if (!_divCotacao.classList.contains('collapsed')) {
        _divCotacao.classList.add('collapsed')
      }

      let _divMenuUsuario = this.menuUsuario.nativeElement;
      if (!_divMenuUsuario.classList.contains('collapsed')) {
        _divMenuUsuario.classList.add('collapsed')
      }
    }
  }

  public logout() {
    localStorage.removeItem('currentUser');
    this._sharedDataService.clearAll();

    this.router.navigate(['/signin']);
  }

  public profile() {
    let _divMenuUsuario = this.menuUsuario.nativeElement;
    _divMenuUsuario.classList.add('collapsed');

    this.router.navigate(['/profile']);
  }

}
