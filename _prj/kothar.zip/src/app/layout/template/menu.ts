export class Menu {

    //static _menus: Array<any> = new Array<any>();
    //static initiated: boolean = false;
   

    public static getHierarquiaByKey(keyName: string, menus: Array<any>) {
        let _m = this.getHierarquiaMenuByKey(keyName, menus);
        let _n = "";

        let _i = 0;
        _m.forEach(el => {
            _n = _n + el.label;

            _i++;

            if (_i < _m.length) {
                _n = _n + " > ";
            }
        });

        return _n;
    }

    public static getNameByKey(keyName: string, menus: Array<any>) {
        let _m = this.getMenuByKey(keyName, menus);
        if (_m != undefined) {
            return _m.label;
        }
    }

    public static getMenuByKey(keyName: string, menus: Array<any>) {
        let _h = this.getHierarquiaMenuByKey(keyName, menus);
        if (_h != undefined && _h.length > 0) {
            return _h[_h.length - 1];
        }
    }

    public static getHierarquiaMenuByKey(keyName: string, menus: Array<any>) {
        let _a = menus;

        let _aux = new Array<any>();
        _a.forEach(el => {


            if (el.key == keyName) {
                _aux.push(el);
                return el;
            } else {
                let _r = this.findInChildren(el, keyName);
                if (_r != undefined && _r.length > 0) {
                    _r.forEach(it => {
                        _aux.push(it);
                    });
                    return _r;
                }
            }
        });

        return _aux;
    }

    private static findInChildren(parent: any, keyName: string): any {
        let _retorno: Array<any> = new Array<any>();

        if (parent.key == keyName) {
            _retorno.push(parent);
            return _retorno;
        } else {
            let _children = parent.children;
            if (_children != undefined) {
                _children.forEach(el => {
                    let _r = this.findInChildren(el, keyName);

                    if (_r != undefined && _r.length > 0) {
                        _retorno.push(parent);
                        _r.forEach(it => {
                            _retorno.push(it);
                        });

                        return _retorno;
                    }
                });
            }
        }

        return _retorno;
    }


    public static getHierarquiaMenuByUrl(urlParam: string, menus: Array<any>) {
        let _a = menus;

        let _aux = new Array<any>();
        _a.forEach(el => {
            if (urlParam.indexOf(el.url) > -1){
                _aux.push(el);
                return el;
            } else {
                let _r = this.findInChildrenByUrl(el, urlParam);
                if (_r != undefined && _r.length > 0) {
                    _r.forEach(it => {
                        _aux.push(it);
                    });
                    return _r;
                }
            }
        });

        return _aux;
    }


    private static findInChildrenByUrl(parent: any, urlParam: string): any {
        let _retorno: Array<any> = new Array<any>();

        if (parent.url == urlParam) {
            _retorno.push(parent);
            return _retorno;
        } else {
            let _children = parent.children;
            if (_children != undefined) {
                _children.forEach(el => {
                    let _r = this.findInChildrenByUrl(el, urlParam);

                    if (_r != undefined && _r.length > 0) {
                        _retorno.push(parent);
                        _r.forEach(it => {
                            _retorno.push(it);
                        });

                        return _retorno;
                    }
                });
            }
        }

        return _retorno;
    }


}


