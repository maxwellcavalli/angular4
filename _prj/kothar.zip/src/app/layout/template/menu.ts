export class Menu {
    static _menus: any = [
        { label: 'Home', url: "/dashboard", icon: 'home' },
        { label: 'Requests', url: "/modules/budget/resposta/resposta-list", icon: 'email', badge: 10, key: 'menu_resposta_cotacao' },
        { label: 'My Budgets', url: "/modules/budget/cotacao/cotacao-list", icon: 'assignment', key: 'menu_cotacao' },
        { label: 'Suppliers', url: "/modules/general/fornecedor/fornecedor-list", icon: 'domain', key: 'menu_fornecedor' },
        {
            label: 'Settings', icon: 'settings',
            children: [
                {
                    label: 'Product', children: [
                        { label: 'Category', url: '/modules/general/categoria-produto/categoria-produto-list', key: 'menu_categoria' },
                        { label: 'Product Group', url: '/modules/general/grupo-produto/grupo-produto-list', key: 'menu_grupo_produto' },
                        { label: 'Product', url: '/modules/general/produto/produto-list', key: 'menu_produto' }
                    ]
                },
                {
                    label: 'Address', children: [
                        { label: 'State', url: '/modules/general/estado/estado-list', key: 'menu_estado' },
                        { label: 'City', url: '/modules/general/cidade/cidade-list', key: 'menu_cidade' },
                        { label: 'District', url: '/modules/general/bairro/bairro-list', key: 'menu_bairro' },
                        { label: 'Postal Code', url: '/modules/general/cep/cep-list', key: 'menu_cep' }
                    ]
                },

                { label: 'Client', url: '/modules/general/cliente/cliente-list', key: 'menu_cliente' },

                {
                    label: 'Security', children: [
                        { label: 'User', url: '/modules/security/usuario/usuario-list', key: 'menu_usuario' },
                        { label: 'Integration Pendings', url: '/modules/security/pendencia-integracao/pendencia-integracao-list', key: 'menu_pendencia_integracao' }
                    ]
                }
            ]
        }
    ];


    public static getHierarquiaByKey(keyName: string) {
        let _m = this.getHierarquiaMenuByKey(keyName);
        let _n = "";

        let _i = 0;
        _m.forEach(el => {
            _n = _n + el.label;

            _i++;

            if (_i < _m.length) {
                _n = _n + " > ";
            }
        });

        return _n;
    }

    public static getNameByKey(keyName: string) {
        let _m = this.getMenuByKey(keyName);
        if (_m != undefined) {
            return _m.label;
        }
    }

    public static getMenuByKey(keyName: string) {
        let _h = this.getHierarquiaMenuByKey(keyName);
        if (_h != undefined && _h.length > 0) {
            return _h[_h.length - 1];
        }
    }

    public static getHierarquiaMenuByKey(keyName: string) {
        let _a = this._menus as Array<any>;

        let _aux = new Array<any>();
        _a.forEach(el => {


            if (el.key == keyName) {
                _aux.push(el);
                return el;
            } else {
                let _r = this.findInChildren(el, keyName);
                if (_r != undefined && _r.length > 0) {
                    _r.forEach(it => {
                        _aux.push(it);
                    });
                    return _r;
                }
            }
        });

        return _aux;
    }

    private static findInChildren(parent: any, keyName: string): any {
        let _retorno: Array<any> = new Array<any>();

        if (parent.key == keyName) {
            _retorno.push(parent);
            return _retorno;
        } else {
            let _children = parent.children;
            if (_children != undefined) {
                _children.forEach(el => {
                    let _r = this.findInChildren(el, keyName);

                    if (_r != undefined && _r.length > 0) {
                        _retorno.push(parent);
                        _r.forEach(it => {
                            _retorno.push(it);
                        });

                        return _retorno;
                    }
                });
            }
        }

        return _retorno;
    }
}


