import { Injectable } from '@angular/core';
import { Http } from '@angular/http';

import { MxBaseService } from 'mx-core';

import { Categoria } from '../shared/entity/categoria';
import { AuthenticationService } from './security/authentication.service';

@Injectable()
export class CategoriaService extends MxBaseService<Categoria> {
  
  private url: string = "/api/secure/categoria";

  protected getToken(): String {
    return this._authenticationService.getToken();
  }

  constructor(public http: Http, private _authenticationService: AuthenticationService) {
    super(http);

  }

  protected getUrl(): string {
    return this.url;
  }
}