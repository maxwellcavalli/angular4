import { Injectable } from '@angular/core';
import { Observable } from "rxjs/Rx";
import { Http } from '@angular/http';

import { MxBaseService } from 'mx-core';
import { AuthenticationService } from './security/authentication.service';
import { GrupoProduto } from '../shared/entity/grupo-produto';

@Injectable()
export class GrupoProdutoService extends MxBaseService<GrupoProduto> {
  
  private url: string = "/api/secure/grupoProduto";

  protected getToken(): String {
    return this._authenticationService.getToken();
  }

  constructor(public http: Http, private _authenticationService: AuthenticationService) {
    super(http);
  }

  protected getUrl(): string {
    return this.url;
  }

  public getGrouped() {
    this.options = this.createHeaderOptions();
    return this.http.get(this.url + "/getGrouped", this.options)
      .map(res => res.json());
  }

}
