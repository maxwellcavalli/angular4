import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { AuthenticationService } from './security/authentication.service';

import { MxBaseService } from 'mx-core';
import { Fornecedor } from '../shared/entity/fornecedor';

@Injectable()
export class FornecedorService extends MxBaseService<Fornecedor> {

  private url: string = "/api/secure/fornecedor";

  protected getToken(): String {
    return this._authenticationService.getToken();
  }

  constructor(public http: Http, private _authenticationService: AuthenticationService) {
    super(http);
  }

  protected getUrl(): string {
    return this.url;
  }

  public searchFornecedoresByCliente() {
    this.options = this.createHeaderOptions();
    return this.http.get(this.url + '/search/fornecedores', this.options)
      .map(res => res.json());
  }

  public findEstatisticasCotacaoCliente(object: Fornecedor) {
    object = this.parseObjectToSend(object);

    this.options = this.createHeaderOptions();
    let complexUrl = this.url + '/find-avaliacao-fornecedor'

    return this.http.post(complexUrl, JSON.stringify(object), this.options)
      .map(res => res.json());
  }
}

