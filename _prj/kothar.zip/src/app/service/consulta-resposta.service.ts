import { Injectable } from '@angular/core';
import { Http } from "@angular/http";
import { Observable } from "rxjs/Rx";
import { MxBaseService, MxResponseEntity } from 'mx-core';

import { AuthenticationService } from "../service/security/authentication.service";
import { Cotacao } from '../shared/entity/cotacao';


@Injectable()
export class ConsultaRespostaService extends MxBaseService<Cotacao> {

  private url: string = "/api/secure/consulta-resposta";

  protected getToken(): String {
    return this._authenticationService.getToken();
  }

  constructor(public http: Http, private _authenticationService: AuthenticationService) {
    super(http);
  }

  protected getUrl(): string {
    return this.url;
  }

  public searchComplex(object: any) {
    this.options = this.createHeaderOptions();
    let complexUrl = this.url + '/search/complex'

    return this.http.post(complexUrl, JSON.stringify(object), this.options)
      .map(res => res.json());
  }

  public getArquivo(id: Number): Observable<MxResponseEntity> {
    this.options = this.createHeaderOptions();
    return this.http.get(this.url + "/get/arquivo/" + id, this.options)
      .map(res => res.json());
  }

  public get(id: Number): Observable<MxResponseEntity> {
    this.options = this.createHeaderOptions();
    return this.http.get(this.url + "/get/resposta/" + id, this.options)
      .map(res => res.json());
  }

  public aceitarFinalizar(object: any) {
    this.options = this.createHeaderOptions();
    let complexUrl = this.url + '/aceitar-proposta'

    return this.http.post(complexUrl, JSON.stringify(object), this.options)
      .map(res => res.json());
  }

  public alterarValorSelecionado(object: any) {
    this.options = this.createHeaderOptions();
    let complexUrl = this.url + '/alterar-valor-selecionado'

    return this.http.post(complexUrl, JSON.stringify(object), this.options)
      .map(res => res.json());
  }

}
