import { Injectable } from "@angular/core";


export interface MaskOptions {
    allowNegative: boolean,
    decimal: string,
    precision: number,
    prefix: string,
    suffix: string,
    thousands: string
}


@Injectable()
export class FormatacaoNumeroService {

    defaultOptions(): MaskOptions {
        return {
            allowNegative: false,
            decimal: ',',
            precision: 2,
            prefix: '',
            suffix: '',
            thousands: '.'
        };
    }

    applyMask(value: Number): string {
        if (value === undefined) {
            return undefined;
        }

        let options = this.defaultOptions();
        let isNumber: boolean = true;
        let rawValue: string = value.toString();

        return this.applyMaskWithParameters(isNumber, rawValue, options);
    }

    applyMaskWithParameters(isNumber: boolean, rawValue: string, options: MaskOptions): string {
        let { allowNegative, decimal, precision, prefix, suffix, thousands } = options;

        rawValue = isNumber ? new Number(rawValue).toFixed(precision) : rawValue;
        let onlyNumbers = rawValue.replace(/[^0-9]/g, "");

        if (!onlyNumbers) {
            return "";
        }

        let integerPart = onlyNumbers.slice(0, onlyNumbers.length - precision).replace(/^0*/g, "").replace(/\B(?=(\d{3})+(?!\d))/g, thousands);

        if (integerPart == "") {
            integerPart = "0";
        }

        let newRawValue = integerPart;
        let decimalPart = onlyNumbers.slice(onlyNumbers.length - precision);

        if (precision > 0) {
            newRawValue += decimal + decimalPart;
        }

        let isZero = parseInt(integerPart) == 0 && (parseInt(decimalPart) == 0 || decimalPart == "");
        let operator = (rawValue.indexOf("-") > -1 && allowNegative && !isZero) ? "-" : "";
        return operator + prefix + newRawValue + suffix;
    }
}