import { Injectable } from '@angular/core';
import { Http } from "@angular/http";

import { MxBaseService } from 'mx-core';

import { AuthenticationService } from "../service/security/authentication.service";
import { Cidade } from '../shared/entity/cidade';

@Injectable()
export class CidadeService extends MxBaseService<Cidade> {

  private url: string = "/api/secure/cidade";

  protected getToken(): String {
    return this._authenticationService.getToken();
  }

  constructor(public http: Http, private _authenticationService: AuthenticationService) {
    super(http);
  }

  protected getUrl(): string {
    return this.url;
  }

  public searchComplex(object: any) {
    this.options = this.createHeaderOptions();
    let complexUrl = this.url + '/search/complex'

    return this.http.post(complexUrl, JSON.stringify(object), this.options)
      .map(res => res.json());
  }

  public searchAutocomplete(object: any) {
    this.options = this.createHeaderOptions();
    let complexUrl = this.url + '/search/autocomplete'

    return this.http.post(complexUrl, JSON.stringify(object), this.options)
      .map(res => res.json());
  }


}
