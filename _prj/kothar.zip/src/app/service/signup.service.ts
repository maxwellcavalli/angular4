import { Injectable } from '@angular/core';
import { Observable } from "rxjs/Rx";
import { Http } from '@angular/http';

import { MxBaseService, MxResponseEntity } from 'mx-core';

import { AuthenticationService } from './security/authentication.service';
import { Cliente } from '../shared/entity/cliente';

@Injectable()
export class SignUpService extends MxBaseService<Cliente> {

  private url: string = "/api/signup";

  protected getToken(): String {
    return this._authenticationService.getToken();
  }

  constructor(public http: Http, private _authenticationService: AuthenticationService) {
    super(http);
  }

  protected getUrl(): string {
    return this.url;
  }

}