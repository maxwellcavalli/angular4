import { Injectable } from '@angular/core';
import { Http } from "@angular/http";
import { Observable } from "rxjs/Rx";

import { MxBaseService, MxResponseEntity } from 'mx-core';

import { AuthenticationService } from "../service/security/authentication.service";
import { Produto } from '../shared/entity/produto';

@Injectable()
export class ProdutoService extends MxBaseService<Produto> {

  private url: string = "/api/secure/produto";

  protected getToken(): String {
    return this._authenticationService.getToken();
  }

  constructor(public http: Http, private _authenticationService: AuthenticationService) {
    super(http);
  }
  protected getUrl(): string {
    return this.url;
  }

  public getProdutoComplete(id: Number): Observable<MxResponseEntity> {
    this.options = this.createHeaderOptions();
    return this.http.get(this.url + "/get/complete/" + id, this.options)
      .map(res => res.json());
  }

  public getSimilarity(nome: String): Observable<MxResponseEntity> {
    this.options = this.createHeaderOptions();
    return this.http.get(this.url + "/get/similarity/" + nome, this.options)
      .map(res => res.json());
  }

  public getImagem(id: Number): Observable<MxResponseEntity> {
    this.options = this.createHeaderOptions();
    return this.http.get(this.url + "/get/imagem/" + id, this.options)
      .map(res => res.json());
  }

  public getThumb(id: Number): Observable<MxResponseEntity> {
    this.options = this.createHeaderOptions();
    return this.http.get(this.url + "/get/thumb/" + id, this.options)
      .map(res => res.json());
  }

}
