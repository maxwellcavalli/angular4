import { Injectable } from '@angular/core';
import { MxBaseService } from 'mx-core';
import { Http } from '@angular/http';

import { AuthenticationService } from './security/authentication.service';
import { PendenciaIntegracao } from '../shared/entity/pendencia-integracao';

@Injectable()
export class PendenciaIntegracaoService extends MxBaseService<PendenciaIntegracao> {

    private url: string = "/api/secure/pendencia-integracao";

    constructor(public http: Http, private _authenticationService: AuthenticationService) {
        super(http);
    }

    protected getToken(): String {
        return this._authenticationService.getToken();
    }

    protected getUrl(): string {
        return this.url;
    }

    public vincularProduto(object: PendenciaIntegracao) {
        object = this.parseObjectToSend(object);
        this.options = this.createHeaderOptions();
        return this.http.post(this.getUrl() + "/vincular-produto", JSON.stringify(object), this.options)
            .map(res => res.json());
    }

    public finalizarPendencia(object: PendenciaIntegracao) {
        object = this.parseObjectToSend(object);
        this.options = this.createHeaderOptions();
        return this.http.post(this.getUrl() + "/finalizar-pendencia", JSON.stringify(object), this.options)
            .map(res => res.json());
    }

}