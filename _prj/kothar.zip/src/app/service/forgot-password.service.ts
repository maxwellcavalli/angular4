import { Injectable } from '@angular/core';
import { Observable } from "rxjs/Rx";
import { Http } from '@angular/http';

import { MxBaseService, MxResponseEntity } from 'mx-core';

import { AuthenticationService } from './security/authentication.service';
import { Usuario } from '../shared/entity/usuario';

@Injectable()
export class ForgotPasswordService extends MxBaseService<Usuario> {

  private url: string = "/api/esquecisenha";

  protected getToken(): String {
    return this._authenticationService.getToken();
  }

  constructor(public http: Http, private _authenticationService: AuthenticationService) {
    super(http);
  }

  protected getUrl(): string {
    return this.url;
  }

  public enviar(object: Usuario) {
    object = this.parseObjectToSend(object);

    this.options = this.createHeaderOptions();
    let complexUrl = this.url + '/enviar'

    return this.http.post(complexUrl, JSON.stringify(object), this.options)
      .map(res => res.json());
  }

  public getByResetToken(token: String): Observable<MxResponseEntity> {
    this.options = this.createHeaderOptions();
    return this.http.get(this.url + "/get-by-reset-token/" + token, this.options)
      .map(res => res.json());
  }

  public trocarSenha(object: Usuario) {
    object = this.parseObjectToSend(object);

    this.options = this.createHeaderOptions();
    let complexUrl = this.url + '/trocar-senha'

    return this.http.post(complexUrl, JSON.stringify(object), this.options)
      .map(res => res.json());
  }

}