import { Injectable } from '@angular/core';
import { Http } from "@angular/http";
import { Observable } from "rxjs/Rx";

import { AuthenticationService } from "../service/security/authentication.service";
import { MxBaseService, MxResponseEntity } from 'mx-core';
import { Cotacao } from '../shared/entity/cotacao';


@Injectable()
export class CotacaoService extends MxBaseService<Cotacao> {

  private url: string = "/api/secure/cotacao";

  protected getToken(): String {
    return this._authenticationService.getToken();
  }

  constructor(public http: Http, private _authenticationService: AuthenticationService) {
    super(http);
  }

  protected getUrl(): string {
    return this.url;
  }

  public searchComplex(object: any) {
    this.options = this.createHeaderOptions();
    let complexUrl = this.url + '/search/complex'

    return this.http.post(complexUrl, JSON.stringify(object), this.options)
      .map(res => res.json());
  }

  public enviarCotacao(object: Cotacao) {
    object = this.parseObjectToSend(object);

    this.options = this.createHeaderOptions();
    let complexUrl = this.url + '/enviar-cotacao'

    return this.http.post(complexUrl, JSON.stringify(object), this.options)
      .map(res => res.json());
  }

  public cancelarCotacao(object: Cotacao) {
    object = this.parseObjectToSend(object);

    this.options = this.createHeaderOptions();
    let complexUrl = this.url + '/cancelar-cotacao'

    return this.http.post(complexUrl, JSON.stringify(object), this.options)
      .map(res => res.json());
  }

  public copiarCotacao(object: Cotacao) {
    object = this.parseObjectToSend(object);

    this.options = this.createHeaderOptions();
    let complexUrl = this.url + '/copiar-cotacao'

    return this.http.post(complexUrl, JSON.stringify(object), this.options)
      .map(res => res.json());
  }

  public findEstatisticasCotacaoFornecedor(object: Cotacao) {
    object = this.parseObjectToSend(object);

    this.options = this.createHeaderOptions();
    let complexUrl = this.url + '/find-estatisticas-cotacao-fornecedor'

    return this.http.post(complexUrl, JSON.stringify(object), this.options)
      .map(res => res.json());
  }

  public findMinhasCotacoesVencedorasFornecedor(object: Cotacao) {
    object = this.parseObjectToSend(object);

    this.options = this.createHeaderOptions();
    let complexUrl = this.url + '/find-minhas-cotacoes-vencedoras-fornecedor'

    return this.http.post(complexUrl, JSON.stringify(object), this.options)
      .map(res => res.json());
  }

  public findEstatisticasCotacaoCliente(object: Cotacao) {
    object = this.parseObjectToSend(object);

    this.options = this.createHeaderOptions();
    let complexUrl = this.url + '/find-estatisticas-cotacao-cliente'

    return this.http.post(complexUrl, JSON.stringify(object), this.options)
      .map(res => res.json());
  }

  public getSituacoes(): Observable<MxResponseEntity> {
    this.options = this.createHeaderOptions();
    return this.http.get(this.url + "/get/situacoes", this.options)
      .map(res => res.json());
  }

  public getArquivo(id: Number): Observable<MxResponseEntity> {
    this.options = this.createHeaderOptions();
    return this.http.get(this.url + "/get/arquivo/" + id, this.options)
      .map(res => res.json());
  }

}
