import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { AuthenticationService } from './security/authentication.service';

import { MxBaseService } from 'mx-core';
import { Estado } from '../shared/entity/estado';

@Injectable()
export class EstadoService extends MxBaseService<Estado> {

  private url: string = "/api/secure/estado";

  protected getToken(): String {
    return this._authenticationService.getToken();
  }

  constructor(public http: Http, private _authenticationService: AuthenticationService) {
    super(http);
  }

  protected getUrl(): string {
    return this.url;
  } 
}
