import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { GrupoProdutoService } from './grupo-produto.service';
import { ProdutoService } from './produto.service';
import { UsuarioService } from './security/usuario.service';
import { AuthenticationService } from "./security/authentication.service";
import { EstadoService } from "./estado.service";
import { CidadeService } from "./cidade.service";
import { BairroService } from "./bairro.service";
import { CepService } from "./cep.service";
import { FornecedorService } from "./fornecedor.service";
import { ClienteService } from "./cliente.service";
import { CategoriaService } from "./categoria.service";
import { CotacaoService } from "./cotacao.service";
import { RespostaCotacaoService } from "./resposta-cotacao.service";
import { FormatacaoNumeroService } from "./formacao-numero.service";
import { ConsultaRespostaService } from "./consulta-resposta.service";
import { MapsService } from "./map.service";
import { PendenciaIntegracaoService } from './pendencia-integracao.service';
import { AvaliacaoService } from './avaliacao.service';


@NgModule({
  imports: [
    CommonModule,
  ],
  declarations: [],
  providers: [
    AuthenticationService,
    GrupoProdutoService,
    ProdutoService,
    UsuarioService,
    EstadoService,
    CidadeService,
    BairroService,
    CepService,
    FornecedorService,
    ClienteService,
    CategoriaService,
    CotacaoService,
    RespostaCotacaoService,
    FormatacaoNumeroService,
    ConsultaRespostaService,
    MapsService,
    PendenciaIntegracaoService,
    AvaliacaoService    
  ]
})
export class ServiceModule { }
