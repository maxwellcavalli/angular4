import { Injectable } from '@angular/core';
import { Http, Headers, Response, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Router, ActivatedRoute } from "@angular/router";
import 'rxjs/add/operator/map'

import { Usuario } from '../../shared/entity/usuario';
import { BehaviorSubject } from 'rxjs';

@Injectable()
export class AuthenticationService {

    private options: RequestOptions;

    constructor(private http: Http,
        protected router: Router,
        protected route: ActivatedRoute) {
            
        let headers = new Headers({ 'Content-Type': 'application/json' });
        this.options = new RequestOptions({ headers: headers });
    }

    login(username: string, password: string) {
        return this.http.post('/api/authenticate', JSON.stringify({ username: username, passwordLogin: password }), this.options)
            .map((response: Response) => {
                // login successful if there's a jwt token in the response
                let responseEntity = response.json();
                let user = responseEntity.object;

                if (user && user.token) {
                    // store user details and jwt token in local storage to keep user logged in between page refreshes
                    localStorage.setItem('currentUser', JSON.stringify(user));
                }

                return user;
            });
    }

    getToken() {
        let currentUser = localStorage.getItem('currentUser');
        if (currentUser === null) {
            return '';
        } else {
            let usuario = JSON.parse(currentUser);
            return usuario.token;
        }
    }

    getUser(): Usuario {
        let currentUser = localStorage.getItem('currentUser');
        if (currentUser === null) {
            return null;
        } else {
            return JSON.parse(currentUser);
        }
    }

    logout() {
        // remove user from local storage to log user out
        localStorage.removeItem('currentUser');
    }

    getProfile() {
        this.options = this.createHeaderOptions();
        return this.http.get('/api/authenticate/profile', this.options)
            .map(res => res.json());
    }

    validateToken() {
        this.options = this.createHeaderOptions();
        return this.http.get('/api/authenticate/validate-token',  this.options)            
            .map(res => res.json());
    }


    private createHeaderOptions(): RequestOptions {
        let token = 'Bearer ' + this.getToken();
        let headers = new Headers(
            { 'Content-Type': 'application/json', 'authorization': token });

        return new RequestOptions({ headers: headers });
    }

    public isLogged() : BehaviorSubject<any>{
        let _url = this.router.url;
        let ret: BehaviorSubject<any> = new BehaviorSubject<any>(null);

        if (localStorage.getItem('currentUser')) {
            this.validateToken().subscribe(

                value => {
                    let valid = (value.object as boolean)
                    if (!valid) {

                        let urlReturn = _url === '' ? '/dashboard' : _url;
                        this.router.navigate(['/signin'], { queryParams: { returnUrl: urlReturn } });
                    }

                    //return new BehaviorSubject<any> (valid);
                    //return valid;
                    ret.next(valid);
                },
                response => {
                    if (response.status == 504) {
                        let urlReturn = _url === '' ? '/dashboard' : _url;
                        this.router.navigate(['/signin'], { queryParams: { returnUrl: urlReturn } });
                        // return new BehaviorSubject<any> (false);
                        //return false;

                        ret.next(false);
                    }
                }
            );

        } else {
            //console.log('not logged');

            // not logged in so redirect to login page with the return url
            let urlReturn = _url === '' ? '/dashboard' : _url;
            this.router.navigate(['/signin'], { queryParams: { returnUrl: urlReturn } });


            ret.next(false);
            // return new BehaviorSubject<any> (false);
            //return false;
        }
        
        return ret;
    }



}
