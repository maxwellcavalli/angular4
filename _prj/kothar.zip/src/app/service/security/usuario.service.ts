import { Injectable } from '@angular/core';
import { Observable } from "rxjs/Rx";
import { Http } from '@angular/http';

import { MxBaseService, MxResponseEntity } from 'mx-core';
import { AuthenticationService } from './authentication.service';
import { Usuario } from '../../shared/entity/usuario';

@Injectable()
export class UsuarioService extends MxBaseService<Usuario> {

  private url: string = "/api/secure/usuario";

  protected getToken(): String {
    return this._authenticationService.getToken();
  }

  constructor(public http: Http, private _authenticationService: AuthenticationService) {
    super(http);
  }

  protected getUrl(): string {
    return this.url;
  }

  public getSituacoes(): Observable<MxResponseEntity> {
    this.options = this.createHeaderOptions();
    return this.http.get(this.url + "/get/situacoes", this.options)
      .map(res => res.json());
  }

}
