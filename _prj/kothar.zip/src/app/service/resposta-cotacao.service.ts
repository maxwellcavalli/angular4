import { Injectable } from '@angular/core';
import { Http } from "@angular/http";
import { Observable } from "rxjs/Rx";

import { MxBaseService, MxResponseEntity } from 'mx-core';

import { AuthenticationService } from "../service/security/authentication.service";
import { Cotacao } from '../shared/entity/cotacao';
import { Fornecedor } from '../shared/entity/fornecedor';

export class CotacaoResposta {
  id: number;
  fornecedor: Fornecedor;
}

@Injectable()
export class RespostaCotacaoService extends MxBaseService<Cotacao> {

  private url: string = "/api/secure/resposta-cotacao";

  protected getToken(): String {
    return this._authenticationService.getToken();
  }

  constructor(public http: Http, private _authenticationService: AuthenticationService) {
    super(http);
  }

  protected getUrl(): string {
    return this.url;
  }

  public searchComplexResposta(object: any) {
    this.options = this.createHeaderOptions();
    let complexUrl = this.url + '/search/complex-resposta'

    return this.http.post(complexUrl, JSON.stringify(object), this.options)
      .map(res => res.json());
  }

  public getArquivo(id: Number): Observable<MxResponseEntity> {
    this.options = this.createHeaderOptions();
    return this.http.get(this.url + "/get/arquivo/" + id, this.options)
      .map(res => res.json());
  }

  public getCotacaoResposta(object: CotacaoResposta): Observable<MxResponseEntity> {
    this.options = this.createHeaderOptions();
    let _u = this.url + "/load-cotacao-resposta/";
    return this.http.post(_u, JSON.stringify(object), this.options)
      .map(res => res.json());
  }

  public getSituacoesResposta(): Observable<MxResponseEntity> {
    this.options = this.createHeaderOptions();
    return this.http.get(this.url + "/get/situacoes-resposta", this.options)
      .map(res => res.json());
  }

  public getTiposPagamento(): Observable<MxResponseEntity> {
    this.options = this.createHeaderOptions();
    return this.http.get(this.url + "/get/tipos-pagamento", this.options)
      .map(res => res.json());
  }

  public getTipoJurosPagamento(): Observable<MxResponseEntity> {
    this.options = this.createHeaderOptions();
    return this.http.get(this.url + "/get/tipos-juros-pagamento", this.options)
      .map(res => res.json());
  }

  public archiveResposta(object: Cotacao) {
    object = this.parseObjectToSend(object);

    this.options = this.createHeaderOptions();
    let complexUrl = this.url + '/archive-resposta'

    return this.http.post(complexUrl, JSON.stringify(object), this.options)
      .map(res => res.json());
  }

  public enviarResposta(object: Cotacao) {
    object = this.parseObjectToSend(object);

    this.options = this.createHeaderOptions();
    let complexUrl = this.url + '/enviar-resposta'

    return this.http.post(complexUrl, JSON.stringify(object), this.options)
      .map(res => res.json());
  }

   public recusarCotacao(object: Cotacao) {
    object = this.parseObjectToSend(object);

    this.options = this.createHeaderOptions();
    let complexUrl = this.url + '/recusar-cotacao'

    return this.http.post(complexUrl, JSON.stringify(object), this.options)
      .map(res => res.json());
  }

}
