import { Injectable } from '@angular/core';
import { Http } from "@angular/http";

import { MxBaseService, MxResponseEntity } from 'mx-core';

import { AuthenticationService } from "../service/security/authentication.service";
import { Observable } from 'rxjs';

@Injectable()
export class AcessosService extends MxBaseService<any> {

  private url: string = "/api/secure/acessos";

  protected getToken(): String {
    return this._authenticationService.getToken();
  }

  constructor(public http: Http, 
    private _authenticationService: AuthenticationService) {
    super(http);
  }

  protected getUrl(): string {
    return this.url;
  }

  public getMenus(): Observable<MxResponseEntity> {
    this.options = this.createHeaderOptions();
    return this.http.get(this.url + "/menus", this.options)
      .map(res => res.json());
  }


 
}