import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { HttpModule } from '@angular/http';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';

import { AppComponent } from './app.component';
import { TemplateComponent } from './layout/template/template.component';
import { PageNotFoundComponent } from './layout/page-not-found/page-not-found.component';
import { TemplateModule } from './layout/template/template.module';
import { SigninComponent } from './modules/security/signin/signin.component';
import { ForgotPasswordComponent } from './modules/security/forgot-password/forgot-password.component';
import { SignupComponent } from './modules/security/signup/signup.component';

import {
  MatFormFieldModule, MatButtonModule, MatInputModule, MatCheckboxModule,
  MatCardModule,
} from '@angular/material';


import { MxRatingModule  } from 'mx-components';

import { FlexLayoutModule } from '@angular/flex-layout';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CUSTOM_DATE_FORMATS, CustomDateAdapter } from 'mx-components';
import { AgmCoreModule } from '@agm/core';


import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { NgProgressModule, NgProgressInterceptor } from 'ngx-progressbar';

import { BrowserXhr } from '@angular/http';
import { NgProgressBrowserXhr } from 'ngx-progressbar';



import { DashboardComponent } from './layout/dashboard/dashboard.component';
import { AuthGuard } from './shared/guard/auth-guard';
import { SharedDataService } from './shared/data/shared-data.service';
import { SharedModule } from './shared/shared.module';
import { ResetPasswordComponent } from './modules/security/reset-password/reset-password.component';



const appRoutes: Routes = [
  {
    path: '', component: TemplateComponent,
    canActivate: [AuthGuard],
    children: [
      {
        path: 'dashboard',
        component: DashboardComponent,
        canActivate: [AuthGuard]
      },
      {
        path: 'modules/general',
        loadChildren: './modules/general/general.module#GeneralModule',
        canActivate: [AuthGuard]
      },
      {
        path: 'modules/security',
        loadChildren: './modules/security/security.module#SecurityModule',
        canActivate: [AuthGuard]
      },
      {
        path: 'modules/budget',
        loadChildren: './modules/budget/budget.module#BudgetModule',
        canActivate: [AuthGuard]
      },
      {
        path: 'modules/reports',
        loadChildren: './modules/reports/reports.module#ReportsModule',
        canActivate: [AuthGuard]
      },
      {
        path: 'profile',
        loadChildren: './modules/security/profile/profile.module#ProfileModule',
        canActivate: [AuthGuard]
      },
    ]
  },

  { path: 'signup', component: SignupComponent },
  { path: 'signin', component: SigninComponent },
  { path: 'forgot-password', component: ForgotPasswordComponent },
  { path: 'reset/:uid', component: ResetPasswordComponent },
  { path: 'not-found', component: PageNotFoundComponent },

  { path: '**', component: PageNotFoundComponent }
];

export function createTranslateLoader(http: HttpClient) {
  return new TranslateHttpLoader(http, './assets/i18n/', '.json');
}


@NgModule({
  declarations: [
    AppComponent,
    SigninComponent,
    SignupComponent,
    ForgotPasswordComponent,
    ResetPasswordComponent,
    PageNotFoundComponent,
    DashboardComponent
  ],
  imports: [
    BrowserModule,
    TemplateModule,
    BrowserAnimationsModule,
    HttpClientModule,
    HttpModule,
    SharedModule,
    MxRatingModule,

    FlexLayoutModule,
    FormsModule, ReactiveFormsModule,

    MatFormFieldModule, MatButtonModule, MatInputModule, MatCheckboxModule,

    RouterModule.forRoot(
      appRoutes,
      { enableTracing: false } // <-- debugging purposes only
    ),

    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: (createTranslateLoader),
        deps: [HttpClient]
      }
    }),

    NgProgressModule,

    HttpModule,
    HttpClientModule,

    AgmCoreModule.forRoot({
      apiKey: 'AIzaSyD6CQP-cXPtNFgJxcaovrhfGr6uHtGz6sQ'
    }),
  ],
  providers: [
    AuthGuard,
    { provide: BrowserXhr, useClass: NgProgressBrowserXhr },
    SharedDataService

  ],
  bootstrap: [AppComponent]
})
export class AppModule { }



