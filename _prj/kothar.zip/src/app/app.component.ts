import { Component } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { MatPaginatorIntl } from '@angular/material';
import { Menu } from './layout/template/menu';
import { SharedDataService } from './shared/data/shared-data.service';
import { AuthenticationService } from './service/security/authentication.service';
import { AcessosService } from './service/acessos.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'app';

  constructor(translate: TranslateService,
    private _sharedDataService: SharedDataService,
    private _authenticationService: AuthenticationService,
    private _acessosService: AcessosService) {
    // this language will be used as a fallback when a translation isn't found in the current language
    translate.setDefaultLang('en');

    // the lang to use, if the lang isn't available, it will use the current loader to get them
    translate.use('en');
  }
}
