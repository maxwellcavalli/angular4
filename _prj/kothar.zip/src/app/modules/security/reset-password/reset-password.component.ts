import { Component, OnInit } from '@angular/core';
import { MxBaseController } from 'mx-core';
import { Usuario } from '../../../shared/entity/usuario';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { UsuarioService } from '../../../service/security/usuario.service';
import { TranslateService } from '@ngx-translate/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ForgotPasswordService } from '../../../service/forgot-password.service';

@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.css']
})
export class ResetPasswordComponent extends MxBaseController implements OnInit {

  usuario: Usuario = new Usuario();
  form: FormGroup;

  constructor(
    private _forgotPasswordService: ForgotPasswordService,
    public translate: TranslateService,
    public router: Router,
    public route: ActivatedRoute,
    private formBuilder: FormBuilder) {

    super(translate);
    this.createForm();
  }

  private createForm() {
    this.form = this.formBuilder.group({
      nome: [{ value: '', disabled: true }, []],
      username: [{ value: '', disabled: true }, []],
      password: ['', [
        Validators.required,
        Validators.minLength(5)
      ]]
    });
  }

  ngOnInit() {
    var id = this.route.params.subscribe(params => {
      var id = params['uid'];

      if (!id)
        return;

      this._forgotPasswordService.getByResetToken(id).subscribe(
        ret => {
          let _u = ret.object as Usuario;
          this.usuario = _u;
        },
        response => {
          this.form.disable({onlySelf:true});
          this.form.updateValueAndValidity();
          
          this.afterResponse(response);
        }
      )
    });
  }

  ngOnDestroy() { }

  public salvar(): void {
    this._forgotPasswordService.trocarSenha(this.usuario).subscribe(
      data => this.afterSalvar(data),
      response => this.afterResponse(response))
  }

  public afterSalvar(data) {

    this.defaultUpdateMessage();
    this.router.navigate(['/signin']);
  }
}
