import { Component, OnInit } from '@angular/core';
import { MxBaseController } from 'mx-core';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import { Router, ActivatedRoute } from '@angular/router';

import { SignUpService } from '../../../service/signup.service';
import { Cliente } from '../../../shared/entity/cliente';
import { Usuario } from '../../../shared/entity/usuario';
import { ForgotPasswordService } from '../../../service/forgot-password.service';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})
export class ForgotPasswordComponent extends MxBaseController implements OnInit {
  
    usuario: Usuario = new Usuario();
    form: FormGroup;
  
    constructor(public _service: ForgotPasswordService,
      public translate: TranslateService,
      public router: Router,
      public route: ActivatedRoute,
      private formBuilder: FormBuilder) {
  
      super(translate);
      this.createForm();
    }
  
    private createForm() {
      this.form = this.formBuilder.group({
        email: ['', [
          Validators.required,
          Validators.minLength(10)
        ]]
      },
      );
    }
  
    ngOnInit() {
      
    }
  
    ngOnDestroy() {
    }
  
    public enviar(): void {
      this._service.enviar(this.usuario).subscribe(
        data => this.afterEnviar(data),
        response => this.afterResponse(response))
    }
  
    public afterEnviar(data) {
      alert(this.translate.instant('GEN.FORGOT.PASSWORD.MESSAGE.LINK'));
  
      this.router.navigate(['/signin']);
    }
  }
  