import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { MxBaseController } from 'mx-core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import { Router, ActivatedRoute } from '@angular/router';

import { Cliente } from '../../../shared/entity/cliente';
import { SignUpService } from '../../../service/signup.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent extends MxBaseController implements OnInit {

  title: String = '';

  cliente: Cliente = new Cliente();
  form: FormGroup;

  constructor(public _service: SignUpService,
    public translate: TranslateService,
    public router: Router,
    public route: ActivatedRoute,
    private formBuilder: FormBuilder) {

    super(translate);
    this.createForm();
  }

  private createForm() {
    this.form = this.formBuilder.group({
      nome: ['', [
        Validators.required,
        Validators.minLength(3)
      ]],
      cpf: ['', [
        Validators.required
      ]],
      username: ['', [
        Validators.required,
        Validators.minLength(5) 
      ]],
      password: ['', [
        Validators.required,
        Validators.minLength(5)
      ]],
      telefone: ['', []],
      email: ['', [
        Validators.required,
        Validators.minLength(10)
      ]]
    },
    );
  }

  ngOnInit() {
    this.title = this.translate.instant('GEN.SIGNUP');
  }

  ngOnDestroy() {
  }

  public afterGet(data: any): void {
    this.cliente = data.object;

    this.form.get('username').disable({ onlySelf: true });
    this.form.get('password').setValidators(null);
    this.form.get('password').updateValueAndValidity();
  }

  public save(): void {
    this._service.insert(this.cliente).subscribe(
      data => this.afterSave(data),
      response => this.afterResponse(response))
  }

  public afterSave(data) {
    this.defaultSaveMessage();

    this.router.navigate(['/signin']);
  }
}
