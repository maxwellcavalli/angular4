import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';

import { AuthenticationService } from '../../../service/security/authentication.service';
import { SharedDataService } from '../../../shared/data/shared-data.service';
import { AcessosService } from '../../../service/acessos.service';
import { Menu } from '../../../layout/template/menu';

@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.css']
})
export class SigninComponent implements OnInit {

  public form: FormGroup;
  uname: string = '';
  password: string = '';

  constructor(private fb: FormBuilder,
    private router: Router,
    public translate: TranslateService,
    private _authService: AuthenticationService,
    private route: ActivatedRoute,
    private _sharedDataService: SharedDataService,
    private _acessosService: AcessosService) {

    this.initTranslate();
  }

  ngOnInit() {
    this.form = this.fb.group({
      uname: [null, Validators.compose([Validators.required])],
      password: [null, Validators.compose([Validators.required])]
    });

    this._sharedDataService.clearAll();
  }

  onSubmit() {
    this._authService.login(this.uname, this.password)
      .subscribe(
      data => this.afterLogin(),
      response => this.afterResponse(response));
  }

  private afterLogin() {
    let returnUrl = this.route.snapshot.queryParams["returnUrl"];

    if (returnUrl === null || returnUrl == undefined || returnUrl == '/') {
      returnUrl = '/dashboard';
    }

    this.router.navigate([returnUrl]);
  }

  protected afterResponse(response: any) {
    if (response.status == 504) {
      alert(this.translate.instant("GEN.CONNECTION.ERROR"))
    } else if (response.status == 417) {
      let object: any;
      object = JSON.parse(response._body);
      alert(object.errorMessage);
    }
  }

  private initTranslate(): void {
    this.translate.addLangs(['en', 'fr', 'pt-br']);
    this.translate.setDefaultLang('en');

    const browserLang: string = this.translate.getBrowserLang();
    this.translate.use(browserLang.match(/en|fr/) ? browserLang : 'en');
  }

}
