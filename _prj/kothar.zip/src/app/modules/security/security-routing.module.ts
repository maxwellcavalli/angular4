import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    children: [
      { path: 'usuario', loadChildren: './usuario/usuario.module#UsuarioModule'},
      { path: 'pendencia-integracao', loadChildren: './pendencia-integracao/pendencia-integracao.module#PendenciaIntegracaoModule'},
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SecurityRoutingModule { }
