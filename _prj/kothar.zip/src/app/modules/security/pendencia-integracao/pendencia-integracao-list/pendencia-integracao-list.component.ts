import { Component, OnInit, ViewChild } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { MxDataTableComponent } from 'mx-components';
import { FormGroup, FormBuilder } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import { Router, ActivatedRoute } from '@angular/router';


import { LoggedCrudController } from '../../../../shared/guard/logged-crud-controller';
import { PendenciaIntegracao } from '../../../../shared/entity/pendencia-integracao';
import { PendenciasIntegracaoFilter } from '../../../../shared/helper/pendencia-integracao-filter';
import { PendenciaIntegracaoService } from '../../../../service/pendencia-integracao.service';
import { AuthenticationService } from '../../../../service/security/authentication.service';
import { Menu } from '../../../../layout/template/menu';
import { SharedDataService } from '../../../../shared/data/shared-data.service';

@Component({
  selector: 'app-pendencia-integracao-list',
  templateUrl: './pendencia-integracao-list.component.html',
  styleUrls: ['./pendencia-integracao-list.component.css']
})
export class PendenciaIntegracaoListComponent extends LoggedCrudController<PendenciaIntegracao> {

  URL_EDIT: String = "/modules/security/pendencia-integracao/pendencia-integracao-form/";

  FILTER_KEY: string = "pendencia_integracao_filter"

  title: String = '';
  
  rows: BehaviorSubject<any> = new BehaviorSubject<any>(null);
  cols: any;

  @ViewChild('table') _table: MxDataTableComponent;

  form: FormGroup;

  pendenciaIntegracaoFilter = new PendenciasIntegracaoFilter()

  constructor(public _service: PendenciaIntegracaoService,
    public translate: TranslateService,
    protected _authenticationService: AuthenticationService,
    public router: Router,
    public route: ActivatedRoute,
    formBuilder: FormBuilder,
    private _sharedDataService: SharedDataService) {

    super(_service, translate, _authenticationService, router, route, false);
    super.reloadFilterL(null);

    this.form = formBuilder.group({
      periodo_cadastro_inicio: [null, []],
      periodo_cadastro_fim: [null, []]
    });

    this.createDefaultSearchListener();

    this.title = Menu.getHierarquiaByKey('menu_pendencia_integracao', this._sharedDataService.menus.value);
  }

  onUpdateFilterValue(value: any): void {
    this.pendenciaIntegracaoFilter = value;
  }

  onGetFilterKey(): string {
    return this.FILTER_KEY;
  };

  onPopulateTable(dados: Array<any>) {
    this.rows.next(dados);
  }

  onGetFilterValue(): any {
    return this.pendenciaIntegracaoFilter;
  }

  ngOnInit() {
    this._authenticationService.isLogged().subscribe(el => {
      if (el === true) {
        super.ngOnInit();

        this.cols = [
          { prop: 'data_criacao', title: this.translate.instant('PENDENCIA.INTEGRACAO.DATA.CADASTRO'), sortable: true, selectable: true, cellTemplate: this._table.cellTplDate, maxWidth: 150 },
          { prop: 'tipo_pendencia_str', title: this.translate.instant('PENDENCIA.INTEGRACAO.MENSAGEM'), sortable: false, selectable: true }
        ]
      }
    });
  }

  public reset(event) {
    this.oldValue = null;

    this.pendenciaIntegracaoFilter.periodoCadastro.inicio = null;
    this.pendenciaIntegracaoFilter.periodoCadastro.fim = null;
    this.searchEvent(event);
  }

  public searchEvent(event: any) {
    this._authenticationService.isLogged().subscribe(el => {
      if (el === true) {
        super.searchEvent(event);
      }
    });
  }

  public edit(event) {
    let object = event.row;
    let url = this.URL_EDIT + object.pendencia_integracao_id;
    this.router.navigate([url]);
  }
}
