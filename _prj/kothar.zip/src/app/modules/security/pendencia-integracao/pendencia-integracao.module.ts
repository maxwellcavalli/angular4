import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PendenciaIntegracaoListComponent } from './pendencia-integracao-list/pendencia-integracao-list.component';
import { PendenciaIntegracaoFormComponent } from './pendencia-integracao-form/pendencia-integracao-form.component';
import { Routes, RouterModule } from '@angular/router';
import { SharedModule } from '../../../shared/shared.module';

const routes: Routes = [
  {
    path: '',
    children: [
      { path: 'pendencia-integracao-list', component: PendenciaIntegracaoListComponent },
      { path: 'pendencia-integracao-form/new', component: PendenciaIntegracaoFormComponent },
      { path: 'pendencia-integracao-form/:id', component: PendenciaIntegracaoFormComponent }
    ]
  }
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    SharedModule
  ],
  declarations: [PendenciaIntegracaoListComponent, PendenciaIntegracaoFormComponent]
})
export class PendenciaIntegracaoModule { }
