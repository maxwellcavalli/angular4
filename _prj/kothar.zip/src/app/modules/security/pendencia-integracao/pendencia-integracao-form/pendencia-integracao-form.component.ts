import { Component, OnInit, ViewChild } from '@angular/core';
import { MxDialogComponent } from 'mx-components';
import { FormGroup, FormBuilder } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import { Router, ActivatedRoute } from '@angular/router';
import { MxResponseEntity } from 'mx-core';


import { LoggedCrudController } from '../../../../shared/guard/logged-crud-controller';
import { PendenciaIntegracao } from '../../../../shared/entity/pendencia-integracao';
import { PendenciaIntegracaoService } from '../../../../service/pendencia-integracao.service';
import { AuthenticationService } from '../../../../service/security/authentication.service';
import { ProdutoService } from '../../../../service/produto.service';
import { GrupoProdutoService } from '../../../../service/grupo-produto.service';
import { Menu } from '../../../../layout/template/menu';
import { Produto } from '../../../../shared/entity/produto';

@Component({
  selector: 'app-pendencia-integracao-form',
  templateUrl: './pendencia-integracao-form.component.html',
  styleUrls: ['./pendencia-integracao-form.component.css']
})
export class PendenciaIntegracaoFormComponent extends LoggedCrudController<PendenciaIntegracao> implements OnInit {
  
  URL_EDIT: String = "/modules/security/pendencia-integracao/pendencia-integracao-form/";
  URL_LIST: String = "/modules/security/pendencia-integracao/pendencia-integracao-list/";
  URL_PRODUTO: String = "/modules/general/categoria-produto/categoria-produto-form/";

  @ViewChild('dialogVincular') dialogVincular: MxDialogComponent;

  pendenciaIntegracao: PendenciaIntegracao = new PendenciaIntegracao();

  detalhes: any;
  similares: any;

  form: FormGroup;

  permiteAlteracoes: boolean = true;
  mostrarSimilaridades: boolean = false;
  mostrarVerificarFotos: boolean = false;

  title: String = '';

  constructor(public _service: PendenciaIntegracaoService,
    public translate: TranslateService,
    protected _authenticationService: AuthenticationService,
    public router: Router,
    public route: ActivatedRoute,
    formBuilder: FormBuilder,
    private _produtoService: ProdutoService,
    private _grupoProdutoService: GrupoProdutoService) {

    super(_service, translate, _authenticationService, router, route, false);

    this.form = formBuilder.group({
      data_cadastro: [{ value: null, disabled: true }, []],
      mensagem: [{ value: null, disabled: true }, []],
      fornecedor: [{ value: null, disabled: true }, []],
      cnpj: [{ value: null, disabled: true }, []],
      produto: [{ value: null, disabled: true }, []],
    });

    this.title = Menu.getHierarquiaByKey('menu_pendencia_integracao');
  }

  ngOnInit() {
    this._authenticationService.isLogged().subscribe(el => {
      if (el === true) {
        super.ngOnInit();
      }
    });
  }

  public afterGet(data: any) {
    this.pendenciaIntegracao = data.object;
    this.detalhes = JSON.parse(this.pendenciaIntegracao.objectStr as string);
    this.permiteAlteracoes = !this.pendenciaIntegracao.finalizado;

    if (this.pendenciaIntegracao.tipo_pendencia == 'NOVO_PRODUTO') {
      this.mostrarSimilaridades = true;

      let produto: Produto = this.detalhes.produto;
      this._produtoService.getSimilarity(produto.produto_nome).subscribe(el => {
        this.similares = el.object;
      });
    } else if (this.pendenciaIntegracao.tipo_pendencia == 'ADICIONAR_FOTOS') {
      this.mostrarVerificarFotos = true;
    }
  }

  public save() {
    this._authenticationService.isLogged().subscribe(el => {
      if (el === true) {
        super.saveOrUpdate(this.pendenciaIntegracao.pendencia_integracao_id, this.pendenciaIntegracao);
      }
    });
  }

  public afterSave(responseEntity: MxResponseEntity) {
    super.afterSave(responseEntity);
    let _o = (responseEntity.object as any);

    let url = this.URL_EDIT + _o.categoria_id;
    this.router.navigate([url]);
  }

  public gerarNovoProduto() {
    this._authenticationService.isLogged().subscribe(el => {
      if (el === true) {
        if (confirm(this.translate.instant("GEN.CONFIRM.MESSAGE"))) {
          let produto: Produto = this.detalhes.produto;

          this._service.insert(this.pendenciaIntegracao).subscribe(ret => {
            let _pi = ret.object as PendenciaIntegracao;

            let det = JSON.parse(_pi.objectStr as string);
            let prod = det.produto;

            let url = this.URL_PRODUTO + prod.produto_id;
            let urlReturn = this.router.url;

            this.router.navigate([url], { queryParams: { returnUrl: urlReturn } });
          });
        }
      }
    });
  }

  public showDialogVincularProduto() {
    this.dialogVincular.openDialog();
  }

  public selecionarProduto(index: any) {
    let arr: Array<any> = this.similares;
    let sel = arr[index].selecionado;

    arr.forEach(el => {
      el.selecionado = false;
    });

    arr[index].selecionado = !sel;
  }

  public vincularProduto() {
    let arr: Array<any> = this.similares;
    let count = arr.filter(el => el.selecionado == true).length;
    if (count == 0) {
      alert(this.translate.instant('PENDENCIA.INTEGRACAO.MENSAGEM.VINCULACAO'));
    } else {
      this._authenticationService.isLogged().subscribe(el => {
        if (el === true) {

          let _det = JSON.parse(this.pendenciaIntegracao.objectStr as string);
          let _sim = arr.filter(el => el.selecionado == true)[0];
          _det.produto = _sim.data;

          this.pendenciaIntegracao.objectStr = JSON.stringify(_det);

          this._service.vincularProduto(this.pendenciaIntegracao).subscribe(
            el => {
              this.dialogVincular.closeDialog();
              this.afterGet(el);
            },
            response => this.afterResponse(response));
        }
      });
    }
  }

  public verificarFotos() {
    this._authenticationService.isLogged().subscribe(el => {
      if (el === true) {
        let _prod = this.detalhes.produto;
        let url = this.URL_PRODUTO + _prod.produto_id;
        let urlReturn = this.router.url;

        this._service.finalizarPendencia(this.pendenciaIntegracao).subscribe(
          el => {
            this.router.navigate([url], { queryParams: { returnUrl: urlReturn } });
            this.afterGet(el);
          },
          response => this.afterResponse(response));
      }
    });
  }
}