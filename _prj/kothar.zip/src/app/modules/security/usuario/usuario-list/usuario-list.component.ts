import { Component, OnInit, ViewChild } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { TranslateService } from '@ngx-translate/core';
import { MxDataTableComponent } from 'mx-components';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormBuilder } from '@angular/forms';


import { LoggedCrudController } from '../../../../shared/guard/logged-crud-controller';
import { Usuario } from '../../../../shared/entity/usuario';
import { UsuarioService } from '../../../../service/security/usuario.service';
import { AuthenticationService } from '../../../../service/security/authentication.service';
import { Menu } from '../../../../layout/template/menu';

@Component({
  selector: 'app-usuario-list',
  templateUrl: './usuario-list.component.html',
  styleUrls: ['./usuario-list.component.css']
})
export class UsuarioListComponent extends LoggedCrudController<Usuario> {
  
    URL_LIST: String = "/modules/security/usuario/usuario-list";
    URL_EDIT: String = "/modules/security/usuario/usuario-form/";
  
    FILTER_KEY: string = "categoria_filter"
  
    filtroNome: String = '';
    form: FormGroup;
    title: String = '';
  
    rows: BehaviorSubject<any> = new BehaviorSubject<any>(null);
    cols: any;
  
    @ViewChild('table') _table: MxDataTableComponent;
  
    constructor(public _service: UsuarioService,
      public translate: TranslateService,
      protected _authenticationService: AuthenticationService,
      public router: Router,
      public route: ActivatedRoute,
      formBuilder: FormBuilder) {
  
      super(_service, translate, _authenticationService, router, route, false);
      super.reloadFilterL(null);
  
      this.form = formBuilder.group({
        nome: ['', []],
      });
  
      this.createDefaultSearchListener();
  
      this.title = Menu.getHierarquiaByKey('menu_usuario');
    }
  
    onUpdateFilterValue(value: any): void {
      this.filtroNome = value;
    }
  
    onGetFilterKey(): string {
      return this.FILTER_KEY;
    };
  
    onPopulateTable(dados: Array<any>) {
      this.rows.next(dados);
    }
  
    onGetFilterValue(): any {
      if (this.filtroNome) {
        return this.filtroNome;
      } else {
        return super.onGetFilterValue();
      }
    }
  
    ngOnInit() {
      this._authenticationService.isLogged().subscribe(el => {
        if (el === true) {
          super.ngOnInit();
  
          this.cols = [
            { prop: 'usuario_nome', title: this.translate.instant('GEN.NAME'), sortable: true, selectable: true },
            { prop: 'username', title: this.translate.instant('USER.USER.NAME'), sortable: true, selectable: true },
            { prop: 'usuario_situacao_str', title: this.translate.instant('USER.STATUS'), sortable: true, selectable: true, maxWidth: 120 },
            { prop: 'usuario_id', title: this.translate.instant('GEN.ACTION'), maxWidth: 30, sortable: false, cellTemplate: this._table.cellDeleteButton }
          ];
        }
      });
    }
  
    ngOnDestroy() {
      this.rows.unsubscribe();
    }
  
    public reset(event) {
      this.oldValue = null;
      this.filtroNome = '';
      this.searchEvent(event);
    }
  
    public searchEvent(event: any) {
      this._authenticationService.isLogged().subscribe(el => {
        if (el === true) {
          super.searchEvent(event);
        }
      });
    }
  
    public edit(event) {
      let object = event.row;
      let url = this.URL_EDIT + object.usuario_id;
      this.router.navigate([url]);
    }
  
    public add(event) {
      this._authenticationService.isLogged().subscribe(el => {
        if (el === true) {
          let url = this.URL_EDIT + "/new";
          this.router.navigate([url]);
  
        }
      });
    }
  }
  