import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UsuarioFormComponent } from './usuario-form/usuario-form.component';
import { UsuarioListComponent } from './usuario-list/usuario-list.component';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../../../shared/shared.module';

const routes: Routes = [
  {
    path: '',
    children: [
      { path: 'usuario-list', component: UsuarioListComponent },
      { path: 'usuario-form/new', component: UsuarioFormComponent },
      { path: 'usuario-form/:id', component: UsuarioFormComponent }
    ]
  }
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    SharedModule
  ],
  declarations: [UsuarioFormComponent, UsuarioListComponent]
})
export class UsuarioModule { }
