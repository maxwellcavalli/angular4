import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import { Router, ActivatedRoute } from '@angular/router';
import { MxResponseEntity } from 'mx-core';


import { LoggedCrudController } from '../../../../shared/guard/logged-crud-controller';
import { Usuario } from '../../../../shared/entity/usuario';
import { UsuarioService } from '../../../../service/security/usuario.service';
import { AuthenticationService } from '../../../../service/security/authentication.service';
import { Menu } from '../../../../layout/template/menu';
import { SharedDataService } from '../../../../shared/data/shared-data.service';

@Component({
  selector: 'app-usuario-form',
  templateUrl: './usuario-form.component.html',
  styleUrls: ['./usuario-form.component.css']
})
export class UsuarioFormComponent extends LoggedCrudController<Usuario> implements OnInit {

  usuario: Usuario = new Usuario();
  form: FormGroup;
  situacoes: Array<any>;

  URL_LIST: String = "/modules/security/usuario/usuario-list";
  URL_EDIT: String = "/modules/security/usuario/usuario-form/";

  title: String = '';

  constructor(public _service: UsuarioService,
    public translate: TranslateService,
    protected _authenticationService: AuthenticationService,
    public router: Router,
    public route: ActivatedRoute,
    formBuilder: FormBuilder,
    private _sharedDataService: SharedDataService) {

    super(_service, translate, _authenticationService, router, route, false);
    this.createServerObject = true;

    this.form = formBuilder.group({
      nome: ['', [
        Validators.required,
        Validators.minLength(3)
      ]],
      username: ['', [
        Validators.required,
        Validators.minLength(5)
      ]],
      password: ['', [
        Validators.required,
        Validators.minLength(5)
      ]],
      email: ['', [
        Validators.required,
        Validators.minLength(3)
      ]],
      situacao: ['', []],
      admin: ['', []]
    });

    _service.getSituacoes().subscribe(data => {
      let ret: any = data.object;
      this.situacoes = ret;
    });

    this.title = Menu.getHierarquiaByKey('menu_usuario', this._sharedDataService.menus.value);
  }

  ngOnInit() {
    this._authenticationService.isLogged().subscribe(el => {
      if (el === true) {
        super.ngOnInit();
      }
    });
  }

  public afterGet(data: any) {
    this.usuario = data.object;

    if (typeof this.usuario.usuario_situacao === 'object') {
      this.usuario.usuario_situacao = this.getEnumValue(this.usuario.usuario_situacao);
    }

    this.form.get('username').disable({ onlySelf: this.editing });
    if (this.editing) {
      this.form.get('password').setValidators(null);
      this.form.get('password').updateValueAndValidity();
    }
  }

  public save() {
    this._authenticationService.isLogged().subscribe(el => {
      if (el === true) {
        super.saveOrUpdate(this.usuario.usuario_id, this.usuario);
      }
    });
  }

  public afterSave(responseEntity: MxResponseEntity) {
    super.afterSave(responseEntity);
    let _o = (responseEntity.object as any);

    this.afterGet(responseEntity);

    let url = this.URL_EDIT + _o.usuario_id;
    this.router.navigate([url]);
  }

  public afterUpdate(responseEntity: MxResponseEntity) {
    super.afterUpdate(responseEntity);
    this.afterGet(responseEntity);
  }

}
