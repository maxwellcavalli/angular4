import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ReportsRoutingModule } from './reports-routing.module';
import { MelhoresClientesFornecedorComponent } from './melhores-clientes-fornecedor/melhores-clientes-fornecedor.component';
import { SharedModule } from '../../shared/shared.module';
import { EstatisticaCotacaoClienteComponent } from './estatistica-cotacao-cliente/estatistica-cotacao-cliente.component';

@NgModule({
  imports: [
    CommonModule,
    ReportsRoutingModule,
    SharedModule
  ],
  declarations: [MelhoresClientesFornecedorComponent, EstatisticaCotacaoClienteComponent]
})
export class ReportsModule { }
