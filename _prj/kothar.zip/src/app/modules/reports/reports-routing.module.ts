import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MelhoresClientesFornecedorComponent } from './melhores-clientes-fornecedor/melhores-clientes-fornecedor.component';

const routes: Routes = [
  {
    path: '',
    children: [
      { path: 'melhores-clientes-fornecedor', component: MelhoresClientesFornecedorComponent }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ReportsRoutingModule { }
