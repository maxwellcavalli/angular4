import { Component, OnInit } from '@angular/core';
import { MxBaseController } from 'mx-core';

@Component({
  selector: 'app-estatistica-cotacao-cliente',
  templateUrl: './estatistica-cotacao-cliente.component.html',
  styleUrls: ['./estatistica-cotacao-cliente.component.css']
})
export class EstatisticaCotacaoClienteComponent extends MxBaseController {
  
   /*@ViewChild('cellTplValue') cellTplValue: TemplateRef<any>;
  
    title: String = '';
    rows: BehaviorSubject<any> = new BehaviorSubject<any>(null);
    cols: any;
  
    _destroy: Subject<any> = new Subject<any>();
  
    @ViewChild('table') _table: MxDataTableComponent;
  
    constructor(public _service: FornecedorService,
      public translate: TranslateService,
      protected _authenticationService: AuthenticationService,
      private _sharedDataService: SharedDataService) {
  
      super(translate);
      this.title = Menu.getHierarquiaByKey('menu_melhores_clientes_fornecedor', this._sharedDataService.menus.value);
    }
  
    onPopulateTable(dados: Array<any>) {
      this.rows.next(dados);
    }
  
    ngOnInit() {
      this._authenticationService.isLogged().subscribe(el => {
        if (el === true) {
          this.cols = [
            { prop: 'nome', title: this.translate.instant('GEN.NAME'), sortable: false, selectable: false },
            { prop: 'valor', title: this.translate.instant('GEN.TOTAL'), sortable: false, selectable: false, maxWidth: 200, cellTemplate: this.cellTplValue },
          ]
        }
  
        this.init()
      });
    }
  
    ngOnDestroy() {
      this.rows.unsubscribe();
  
      this._destroy.next();
      this._destroy.unsubscribe();
    }
  
    private init() {
      let _for = this._sharedDataService.fornecedor.value;
      if (_for != undefined && _for != null) {
        this.searchDados(_for);
      } else {
        this._sharedDataService.fornecedor
          .takeUntil(this._destroy)
          .subscribe(
          ret => this.searchDados(ret),
          response => this.afterResponse(response)
          );
      }
    }
  
    private searchDados(fornecedor: Fornecedor) {
      this._service.findMelhoresClientesFornecedor(fornecedor).subscribe(
        ret => {
          let _l = ret.object as Array<any>;
          //this.createGraphic(_l);
  
          this.rows.next(_l);
        },
        response => this.afterResponse(response)
      );
    }
  
    // private createGraphic(data: any) {
    //   let _n = this.translate.instant('GEN.NAME');
    //   let _t = this.translate.instant('GEN.TOTAL')
    //   let _titulo = this.translate.instant('MELHORES.CLIENTES.TITULO');
    //   let _sub_titulo = this.translate.instant('MELHORES.CLIENTES.SUB.TITULO');
    //   let _cliente = this.translate.instant('MELHORES.CLIENTES.CLIENTE');
    //   let _total = this.translate.instant('MELHORES.CLIENTES.VALOR.TOTAL');
  
    //   google.charts.load('current', { 'packages': ['bar'] });
    //   google.charts.setOnLoadCallback(drawChart);
    //   function drawChart() {
  
    //     let _arr = new Array<any>();
    //     _arr.reverse()
  
    //     let _d = data.reverse();
  
    //     _arr.push([_n, _t]);
    //     _d.forEach(el => {
    //       let _o = [el.nome, el.valor];
    //       _arr.push(_o)
    //     });
  
  
    //     var dataGraph = google.visualization.arrayToDataTable(_arr);
  
    //     var options = {
    //       chart: {
    //         title: _titulo,
    //         subtitle: _sub_titulo,
  
    //       },
    //       hAxis: {
    //         title: _total,
    //         minValue: 0,
    //       },
    //       vAxis: {
    //         title: _cliente
    //       },
    //       bars: 'horizontal',
    //       axes: {
    //         y: {
    //           0: { side: 'right' }
    //         }
    //       }
    //     };
  
    //     var chart = new google.charts.Bar(document.getElementById('chart'));
    //     chart.draw(dataGraph, google.charts.Bar.convertOptions(options));
  
    //   }
    // }
  
  */
  }
  