import { Component, OnInit, ViewChild } from '@angular/core';
import { LoggedCrudController } from '../../../../shared/guard/logged-crud-controller';
import { Cotacao } from '../../../../shared/entity/cotacao';
import { CotacaoRespostaFilter } from '../../../../shared/helper/cotacao-resposta-filter';
import { FormGroup, FormBuilder } from '@angular/forms';
import { Fornecedor } from '../../../../shared/entity/fornecedor';
import { BehaviorSubject, Subject } from 'rxjs';
import { MxDataTableComponent } from 'mx-components';
import { RespostaCotacaoService } from '../../../../service/resposta-cotacao.service';
import { TranslateService } from '@ngx-translate/core';
import { AuthenticationService } from '../../../../service/security/authentication.service';
import { Router, ActivatedRoute } from '@angular/router';
import { SharedDataService } from '../../../../shared/data/shared-data.service';
import { MxPageFilter } from 'mx-core';
import { Menu } from '../../../../layout/template/menu';

@Component({
  selector: 'app-resposta-list',
  templateUrl: './resposta-list.component.html',
  styleUrls: ['./resposta-list.component.css']
})
export class RespostaListComponent extends LoggedCrudController<Cotacao> {

  URL_LIST: String = "/modules/budget/resposta/resposta-list";
  URL_EDIT: String = "/modules/budget/resposta/resposta-form/";

  FILTER_KEY: string = "resposta_cotacao_filter"

  cotacaoFilter: CotacaoRespostaFilter = new CotacaoRespostaFilter();

  situacoes: Array<any>;
  form: FormGroup;

  fornecedor: Fornecedor;
  hasListenerCreated = false;

  title: String = '';

  rows: BehaviorSubject<any> = new BehaviorSubject<any>(null);
  cols: any;

  @ViewChild('table') _table: MxDataTableComponent;

  private _destroy: Subject<Fornecedor> = new Subject();

  ngOnInit() {
    this.hasListenerCreated = false;
    //super.ngOnInit();

    this._authenticationService.isLogged().subscribe(el => {
      if (el === true) {
        this.init();
      }
    });

    this.cols = [
      { prop: 'cotacao_id', title: this.translate.instant('GEN.ID'), maxWidth: 50, sortable: true, selectable: true },
      { prop: 'cotacao_nome', title: this.translate.instant('GEN.NAME'), sortable: true, selectable: true },
      { prop: 'dataCadastro', title: this.translate.instant('COTACAO.DATA.CADASTRO'), sortable: true, selectable: true, maxWidth: 150, cellTemplate: this._table.cellTplDate, hideOnMobile: true },
      { prop: 'dataLimiteRetorno', title: this.translate.instant('COTACAO.DATA.LIMITE'), sortable: true, selectable: true, maxWidth: 150, cellTemplate: this._table.cellTplDate, hideOnMobile: true },
      { prop: 'dataEnvio', title: this.translate.instant('COTACAO.DATA.ENVIO'), sortable: true, selectable: true, maxWidth: 150, cellTemplate: this._table.cellTplDate, hideOnMobile: true },
      { prop: 'cotacao_situacao_resposta_fornecedor', title: this.translate.instant('COTACAO.SITUACAO'), sortable: false, selectable: true, maxWidth: 120, hideOnMobile: true }
    ];
  }

  ngOnDestroy() {
    this.rows.unsubscribe();

    this._destroy.next();
    this._destroy.unsubscribe();
  }

  protected createDefaultSearchListener() {
    this.pageFilterN.subscribe(_filter => {
      this.isFilterUpdatedP();

      _filter.filterValue = this.onGetFilterValue();

      this.onSaveFilter();

      this._service.searchComplexResposta(_filter).subscribe(
        _ret => {
          this.afterSearch(_ret);
          let _dados = (_ret.object as any).content;

          this.onPopulateTable(_dados as Array<any>)
        },
        response => {
          this.afterResponse(response);
        });
    });
  }

  constructor(
    public _service: RespostaCotacaoService,
    public translate: TranslateService,
    protected _authenticationService: AuthenticationService,
    public router: Router,
    public route: ActivatedRoute,
    private formBuilder: FormBuilder,
    private _sharedDataService: SharedDataService) {

    super(_service, translate, _authenticationService, router, route, false);
    this.createForm();
  }

  private createForm() {
    this.form = this.formBuilder.group({
      nome: ['', []],
      periodo_cadastro_inicio: [null, []],
      periodo_cadastro_fim: [null, []],
      periodo_limite_inicio: [null, []],
      periodo_limite_fim: [null, []],
      periodo_envio_inicio: [null, []],
      periodo_envio_fim: [null, []],
      situacao: ['', []]
    });
  }

  private init() {
    this.fornecedor = this._sharedDataService.fornecedor.value;
    this.cotacaoFilter.fornecedor = this.fornecedor;

    if (this.fornecedor != null) {
      super.reloadFilterL(null);
      this.createDefaultSearchListener();
    } else {
      this._sharedDataService.fornecedor
        .takeUntil(this._destroy)
        .subscribe(_d => {

          if (_d) {
            if (this.hasListenerCreated === false) {
              this.fornecedor = _d;
              this.cotacaoFilter.fornecedor = this.fornecedor;

              super.reloadFilterL(null);
              this.createDefaultSearchListener();

              this.hasListenerCreated = true;
            } else {
              this.cotacaoFilter.fornecedor = _d;
              let _f: MxPageFilter = this.pageFilterN.value;
              _f.filterValue = this.onGetFilterValue();

              this.pageFilterN.next(_f);
            }
          }
        });
    }

    this._service.getSituacoesResposta().subscribe(data => {
      this.situacoes = data.object as Array<any>;
    });

    this.title = Menu.getHierarquiaByKey('menu_resposta_cotacao');
  }

  onUpdateFilterValue(value: any): void {
    this.cotacaoFilter.fornecedor = this.fornecedor;
    this.cotacaoFilter.nome = value.nome;
    this.cotacaoFilter.situacaoCotacao = value.situacaoCotacao;
    this.cotacaoFilter.periodoCadastro.inicio = value.periodoCadastro.inicio;
    this.cotacaoFilter.periodoCadastro.fim = value.periodoCadastro.fim;
    this.cotacaoFilter.periodoEnvio.inicio = value.periodoEnvio.inicio;
    this.cotacaoFilter.periodoEnvio.fim = value.periodoEnvio.fim;
    this.cotacaoFilter.periodoRetorno.inicio = value.periodoRetorno.inicio;
    this.cotacaoFilter.situacaoRespostaFornecedor = value.situacaoRespostaFornecedor;
  }

  onGetFilterKey(): string {
    return this.FILTER_KEY;
  };

  onPopulateTable(dados: Array<any>) {
    this.rows.next(dados);
  }

  onGetFilterValue(): any {
    return this.cotacaoFilter;
  }

  public reset(event) {
    this.oldValue = null;
    this.cotacaoFilter.nome = '';
    this.cotacaoFilter.situacaoCotacao = null;
    this.cotacaoFilter.periodoCadastro.inicio = null;
    this.cotacaoFilter.periodoCadastro.fim = null;
    this.cotacaoFilter.periodoEnvio.inicio = null;
    this.cotacaoFilter.periodoEnvio.fim = null;
    this.cotacaoFilter.periodoRetorno.inicio = null;
    this.cotacaoFilter.situacaoRespostaFornecedor = null;

    this.searchEvent(event);
  }

  public edit(event) {
    let object = event.row;
    let url = this.URL_EDIT + object.cotacao_id;
    this.router.navigate([url]);
  }

  public searchEvent(event: any) {
    this._authenticationService.isLogged().subscribe(el => {
      if (el === true) {
        super.searchEvent(event)
      }
    });
  }
}
