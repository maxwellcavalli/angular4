import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';

import { SharedModule } from '../../../shared/shared.module';
import { RespostaListComponent } from './resposta-list/resposta-list.component';
import { RespostaFormComponent } from './resposta-form/resposta-form.component';

const routes: Routes = [
  {
    path: '',
    children: [
      { path: 'resposta-list', component: RespostaListComponent },
      { path: 'resposta-form/new', component: RespostaFormComponent },
      { path: 'resposta-form/:id', component: RespostaFormComponent }
    ]
  }
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    SharedModule
  ],
  declarations: [RespostaListComponent, RespostaFormComponent]
})
export class RespostaModule { }
