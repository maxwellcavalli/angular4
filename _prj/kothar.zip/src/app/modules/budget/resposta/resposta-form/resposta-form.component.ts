import { Component, OnInit, ViewChild, ChangeDetectorRef } from '@angular/core';
import { MxBaseController } from 'mx-core';
import { MxDialogComponent } from 'mx-components';
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';
import { BehaviorSubject, Subject } from 'rxjs';
import { TranslateService } from '@ngx-translate/core';
import { Router, ActivatedRoute } from '@angular/router';


import { Cotacao } from '../../../../shared/entity/cotacao';
import { Fornecedor } from '../../../../shared/entity/fornecedor';
import { CotacaoItemFornecedor } from '../../../../shared/entity/cotacao-item-fornecedor';
import { RespostaCotacaoService, CotacaoResposta } from '../../../../service/resposta-cotacao.service';
import { SharedDataService } from '../../../../shared/data/shared-data.service';
import { ClienteService } from '../../../../service/cliente.service';
import { FormatacaoNumeroService } from '../../../../service/formacao-numero.service';
import { CotacaoItemFornecedorValor } from '../../../../shared/entity/cotacao-item-fornecedor-valor';
import { CotacaoItemArquivo } from '../../../../shared/entity/cotacao-item-arquivo';

//import moment from 'moment/src/moment';
import * as moment from 'moment';
import { Menu } from '../../../../layout/template/menu';
import { AuthenticationService } from '../../../../service/security/authentication.service';
import { DetalhesProdutoComponent } from '../../../../shared/components/detalhes-produto/detalhes-produto.component';


@Component({
  selector: 'app-resposta-form',
  templateUrl: './resposta-form.component.html',
  styleUrls: ['./resposta-form.component.css']
})
export class RespostaFormComponent extends MxBaseController implements OnInit {

  @ViewChild('dialogArquivos') dialogArquivos: MxDialogComponent;
  @ViewChild('dialogPrecos') dialogPrecos: MxDialogComponent;
  @ViewChild('dialogEndereco') dialogEndereco: MxDialogComponent;
  @ViewChild('dialogSend') dialogSend: MxDialogComponent;

  @ViewChild('detalhesProduto') detalhesProduto: DetalhesProdutoComponent;

  URL_LIST: String = "/modules/budget/resposta/resposta-list";
  URL_EDIT: String = "/modules/budget/resposta/resposta-form/";

  cotacao: Cotacao = new Cotacao();
  fornecedor: Fornecedor;
  cotacaoItemFornecedor: CotacaoItemFornecedor;

  possui_pendencias: boolean;

  tiposPagamento: Array<any>;
  tiposJurosPagamento: Array<any>;

  form: FormGroup;
  form_send: FormGroup;

  habilita_alteracoes: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(true);
  habilita_recusar: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(true);

  showDirections = false;

  title: String = '';

  showMap: boolean = false;


  private _destroy: Subject<Fornecedor> = new Subject<Fornecedor>();

  origin: any = {
    latitude: 0,
    longitude: 0
  };

  destination: any = {
    latitude: 0,
    longitude: 0
  };

  get habilitarAcoes(): boolean {
    return this.cotacao.cotacao_permite_resposta;
  }

  get itens(): Array<CotacaoItemFornecedor> {
    return this.cotacao.cotacao_fornecedor_item;
  }

  get formItens(): FormArray {
    return this.form.controls['itens'] as FormArray;
  }

  constructor(public _service: RespostaCotacaoService,
    public translate: TranslateService,
    public router: Router,
    public route: ActivatedRoute,
    private formBuilder: FormBuilder,
    private _sharedDataService: SharedDataService,
    private _ref: ChangeDetectorRef,
    private _clienteService: ClienteService,
    private _formatacaoNumeroService: FormatacaoNumeroService,
    private _authenticationService: AuthenticationService) {

    super(translate);

    this.createForm();
  }

  public ngOnInit() {
    this._authenticationService.isLogged().subscribe(el => {
      if (el === true) {
        this.init();
      }
    });

  }

  private createForm() {
    this.form = this.formBuilder.group({
      numero: [{ value: '', disabled: true }, []],
      nome: [{ value: '', disabled: true }, []],
      data_cadastro: [{ value: null, disabled: true }, []],
      data_limite: [{ value: null, disabled: true }, []],
      data_envio: [{ value: null, disabled: true }, []],
      hora: [{ value: null, disabled: true }, []],
      itens: new FormArray([]),
      situacao: [{ value: '', disabled: true }, []],

      prazo_entrega: [{ value: '', disabled: false }, [
        Validators.required
      ]],

      condicoes_pagamento: [{ value: '', disabled: false }, [
        Validators.required
      ]],

      quantidade_pagamentos: [{ value: '', disabled: false }, []],
      tipo_juros: [{ value: '', disabled: false }, []],
      valor_juros: [{ value: '', disabled: false }, [
      ]]
    });

    this.form_send = this.formBuilder.group({
      data_validade: [null, [
        Validators.required
      ]],
    });
  }

  private init() {
    var id = this.route.params.subscribe(params => {
      var id = params['id'];

      if (!id)
        return;

      this.getDomain(id);
    });

    this._service.getTiposPagamento().subscribe(data => {
      this.tiposPagamento = data.object as Array<any>;
    });

    this._service.getTipoJurosPagamento().subscribe(data => {
      this.tiposJurosPagamento = data.object as Array<any>;
    });


    this.title = Menu.getHierarquiaByKey('menu_resposta_cotacao', this._sharedDataService.menus.value) + ' > ' +
      this.translate.instant('COTACAO.RESPOSTA.TITLE');

  }

  ngOnDestroy() {
    this.habilita_alteracoes.unsubscribe();
    this.habilita_recusar.unsubscribe();

    this._destroy.next();
    this._destroy.unsubscribe();
  }

  public changeTipoPagamento() {
    this.form.controls['quantidade_pagamentos'].setValidators(null);
    this.form.controls['tipo_juros'].setValidators(null);

    if (this.cotacao.cotacao_fornecedor.tipo_pagamento === 'APRAZO') {
      this.form.controls['quantidade_pagamentos'].setValidators(Validators.required);
      this.form.controls['tipo_juros'].setValidators(Validators.required);
    }

    this.form.controls['tipo_juros'].updateValueAndValidity();
    this.form.controls['quantidade_pagamentos'].updateValueAndValidity();
  }

  public changeTipoJurosPagamento() {
    this.form.controls['valor_juros'].setValidators(null);
    if (this.cotacao.cotacao_fornecedor.tipo_pagamento === 'APRAZO') {
      if (this.cotacao.cotacao_fornecedor.tipo_juros_pagamento === 'COMJUROS') {
        this.form.controls['valor_juros'].setValidators(Validators.required);
      }
    }

    this.form.controls['valor_juros'].updateValueAndValidity();
  }

  ignorarItem(index: number): void {
    this.itens[index].ignorar_item = true;
    this.formItens.controls[index].disable({ onlySelf: true });

    this.form.markAsDirty({ onlySelf: true });
  }

  ativarItem(index: number): void {
    this.itens[index].ignorar_item = false;
    this.formItens.controls[index].enable({ onlySelf: true });

    this.form.markAsDirty({ onlySelf: true });
  }

  private getDomain(id): void {
    if (this._sharedDataService.fornecedor.value !== null && this._sharedDataService.fornecedor.value !== undefined) {

      let _p = new CotacaoResposta();
      _p.id = id;
      _p.fornecedor = this._sharedDataService.fornecedor.value;

      this.fornecedor = _p.fornecedor;

      this._service.getCotacaoResposta(_p).subscribe(
        ret => this.afterGet(ret),
        response => this.afterResponse(response)
      );
    } else {
      this._sharedDataService.fornecedor
        .takeUntil(this._destroy)
        .subscribe(fornecedor => {
          if (fornecedor !== null && fornecedor !== undefined) {
            let _p = new CotacaoResposta();
            _p.id = id;
            _p.fornecedor = this._sharedDataService.fornecedor.value;

            this.fornecedor = _p.fornecedor;

            this._service.getCotacaoResposta(_p).subscribe(
              ret => this.afterGet(ret),
              response => this.afterResponse(response)
            );
          }
        });
    }
  }

  private validateComponentState() {
    let disabled = !this.habilitarAcoes;

    if (disabled) {
      (this.form.controls['itens'] as FormArray).controls.forEach(_d => {
        _d.disable({ onlySelf: true });
      });

      this.form.controls['condicoes_pagamento'].disable({ onlySelf: true });
      this.form.controls['prazo_entrega'].disable({ onlySelf: true });
      this.form.controls['condicoes_pagamento'].disable({ onlySelf: true });
      this.form.controls['quantidade_pagamentos'].disable({ onlySelf: true });
      this.form.controls['tipo_juros'].disable({ onlySelf: true });
      this.form.controls['valor_juros'].disable({ onlySelf: true });

    }
  }

  retornaQuantidadeValoresInformados(cotacaoItemFornecedor: CotacaoItemFornecedor) {
    if (cotacaoItemFornecedor.valores) {
      return cotacaoItemFornecedor.valores.length
    } else {
      return 0;
    }
  }

  calculaValorTotalItem(cotacaoItemFornecedor: CotacaoItemFornecedor): string {
    let _unit = (cotacaoItemFornecedor.valor_unitario as number);
    let _qtd = (cotacaoItemFornecedor.cotacao_item.quantidade as number);

    let _calc = _unit * _qtd;
    let _formated = this._formatacaoNumeroService.applyMask(_calc);

    return _formated;
  }

  recusarCotacao() {
    this._authenticationService.isLogged().subscribe(el => {
      if (el === true) {
        if (confirm(this.translate.instant("GEN.CONFIRM.MESSAGE"))) {
          //this.cotacao.cotacao_fornecedor = this._sharedControls.fornecedor.value;
          this._service.recusarCotacao(this.cotacao).subscribe(
            responseHelper => {
              alert(this.translate.instant('COTACAO.MENSAGEM.RECUSADA'));

              this.afterGet(responseHelper)
            },
            response => this.afterResponse(response)
          );
        }
      }
    });
  }

  private createFormArray() {
    this.cotacao.cotacao_fornecedor_item.forEach((item: CotacaoItemFornecedor) => {
      this.formItens.push(this.createCustomGroup(item));
    });
  }

  private createCustomGroup(item: CotacaoItemFornecedor) {
    let _ignore = item.ignorar_item;

    return this.formBuilder.group({
      valor_unitario: [{ value: '', disabled: _ignore }, []]
    })
  }

  public afterGet(data: any) {
    let _cot = data.object;

    let _limite = _cot.dataLimiteRetorno;
    if (_limite) {
      let _m = moment(_limite);

      _cot.cotacao_hora = _m.format('HH:mm');
      _cot.dataLimiteRetorno = _m.toDate();
    } else {
      _cot.cotacao_hora = '';
    }

    this.cotacao = _cot;

    this.deleteItemControls();
    this.createFormArray();
    this.validateComponentState();

    if (this.cotacao.cotacao_endereco !== undefined) {
      let _cep = this.cotacao.cotacao_endereco.cotacao_endereco_cep;
      _cep.endereco_complemento = this.cotacao.cotacao_endereco.cotacao_endereco_complemento;
      this.cotacao.cotacao_endereco.cotacao_endereco_cep = _cep;
    }

    if (this.cotacao.cotacao_fornecedor.tipo_pagamento === undefined || this.cotacao.cotacao_fornecedor.tipo_pagamento === null) {
      this.cotacao.cotacao_fornecedor.tipo_pagamento = 'AVISTA';
    }

    this.habilita_alteracoes.next(this.cotacao.cotacao_permite_resposta);
    this.habilita_recusar.next(this.cotacao.cotacao_permite_recusar);

    this.validatePendencias();

    this.changeTipoPagamento();
    this.changeTipoJurosPagamento();

    // if (this.cotacao.cotacao_fornecedor.data_validade == null){
    //   this.cotacao.cotacao_fornecedor.data_validade = undefined;
    // }

    this._ref.detectChanges();
  }

  public openDialogSend() {
    this._authenticationService.isLogged().subscribe(el => {
      if (el === true) {
        this._ref.detectChanges();
        this.dialogSend.openDialog();
      }
    });
  }

  private validatePendencias() {
    let _qtdPendencias = 0;
    this.cotacao.cotacao_fornecedor_item.forEach(el => {

      if (el.ignorar_item !== true) {
        if (el.cotacao_item.cotacao_item_produto.generico === true) {
          el.valores.forEach(values => {
            if (values.marca_modelo === '' || (values.valor_unitario === undefined || values.valor_unitario <= 0)) {
              _qtdPendencias++;
            }
          });

          if (el.valores.length === 0) {
            _qtdPendencias++;
          }
        } else {
          if (el.valor_unitario === undefined || el.valor_unitario <= 0) {
            _qtdPendencias++;
          }
        }
      }
    });

    this.possui_pendencias = _qtdPendencias > 0;
  }

  private deleteItemControls() {
    while ((this.form.controls['itens'] as FormArray).length > 0) {
      (this.form.controls['itens'] as FormArray).removeAt(0);
    }
  }

  public save() {
    this._authenticationService.isLogged().subscribe(el => {
      if (el === true) {
        this._service.archiveResposta(this.cotacao).subscribe(
          data => this.afterUpdate(data),
          response => this.afterResponse(response)
        );
      }
    });
  }

  public send() {
    this.dialogSend.closeDialog();
    this._authenticationService.isLogged().subscribe(el => {
      if (el === true) {
        if (confirm(this.translate.instant("GEN.CONFIRM.MESSAGE"))) {
          this._service.enviarResposta(this.cotacao).subscribe(
            data => {
              this.afterUpdate(data)
              
            },
            response => this.afterResponse(response)
          );
        }

      }
    });
  }

  protected afterUpdate(data) {
    super.defaultUpdateMessage();
    this.afterGet(data);

    this.form.markAsPristine({ onlySelf: true });
  }

  public openDialogDetalhes(index) {
    this.cotacaoItemFornecedor = this.itens[index];

    let produto = this.cotacaoItemFornecedor.cotacao_item.cotacao_item_produto;

    this.detalhesProduto.openDialog(produto);


    
  }

  public openDialog(index) {
    this.cotacaoItemFornecedor = this.itens[index];
    if (this.cotacaoItemFornecedor.cotacao_item.cotacao_item_arquivos.length == 0) {
      alert(this.translate.instant('GEN.NO.FILES'));
    } else {
      this.dialogArquivos.title = this.cotacaoItemFornecedor.cotacao_item.cotacao_item_produto.produto_nome;
      this.dialogArquivos.openDialog();
    }
  }

  public openDialogPrecos(index) {
    this.cotacaoItemFornecedor = this.itens[index];

    let _item = this.cotacao.cotacao_fornecedor_item[index];

    if (_item.valores === undefined) {
      _item.valores = new Array<CotacaoItemFornecedorValor>();
    }

    if (_item.valores.length == 0) {
      _item.valores.push(new CotacaoItemFornecedorValor());
    }

    this.cotacao.cotacao_fornecedor_item[index] = _item;
    this.dialogPrecos.title = this.cotacaoItemFornecedor.cotacao_item.cotacao_item_produto.produto_nome;
    this.dialogPrecos.openDialog();
  }

  onChangeValorGeneric(event) {
    this.form.markAsDirty({ onlySelf: true });
  }

  adicionarMaisValores() {
    this.cotacaoItemFornecedor.valores.push(new CotacaoItemFornecedorValor());
    let index = this.itens.indexOf(this.cotacaoItemFornecedor);
    this.cotacao.cotacao_fornecedor_item[index] = this.cotacaoItemFornecedor;
  }

  deleteValor(index) {
    this.cotacaoItemFornecedor.valores.splice(index, 1);

    let indexItemForn = this.itens.indexOf(this.cotacaoItemFornecedor);
    this.cotacao.cotacao_fornecedor_item[indexItemForn] = this.cotacaoItemFornecedor;
  }

  downloadArquivo(cotacaoItemArquivo: CotacaoItemArquivo) {
    let cotacaoItem = this.cotacaoItemFornecedor.cotacao_item;

    let index = cotacaoItem.cotacao_item_arquivos.indexOf(cotacaoItemArquivo);
    cotacaoItemArquivo = cotacaoItem.cotacao_item_arquivos[index];

    if (cotacaoItemArquivo.imagem64 === undefined || cotacaoItemArquivo.imagem64 === '') {
      this._service.getArquivo(cotacaoItemArquivo.cotacao_item_arquivo_id).subscribe(data => {
        let obj = data.object;
        cotacaoItemArquivo = (obj as any);

        cotacaoItem.cotacao_item_arquivos[index] = cotacaoItemArquivo;

        let indexitemForn = this.itens.indexOf(this.cotacaoItemFornecedor);
        this.cotacao.cotacao_fornecedor_item[indexitemForn].cotacao_item = cotacaoItem;

        let base64: string = (cotacaoItemArquivo.imagem64 as string);
        let name: string = (cotacaoItemArquivo.cotacao_item_arquivo_nome as string);

        base64 = 'data:application/octet-stream;base64,' + base64;
        super.download(base64, name);
      });
    } else {
      let base64: string = (cotacaoItemArquivo.imagem64 as string);
      let name: string = (cotacaoItemArquivo.cotacao_item_arquivo_nome as string);

      base64 = 'data:application/octet-stream;base64,' + base64;
      super.download(base64, name);
    }
  }

  public openDialogEndereco() {
    if (this.cotacao.cotacao_endereco.cotacao_endereco_complemento) {
      this.origin.latitude = this.cotacao.cotacao_endereco.cotacao_endereco_complemento.latitude
      this.origin.longitude = this.cotacao.cotacao_endereco.cotacao_endereco_complemento.longitude;
    }

    if (this.fornecedor.fornecedor_endereco) {
      this.destination.latitude = this.fornecedor.fornecedor_endereco.latitude
      this.destination.longitude = this.fornecedor.fornecedor_endereco.longitude;
    }

    this.showDirections = true;
    this.showMap = true;

    this.dialogEndereco.openDialog();
  }

  public closeDialogEndereco() {
    this.showDirections = false;
    this.showMap = false;
    this.dialogEndereco.closeDialog();

  }


}


