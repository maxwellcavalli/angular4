import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    children: [
      { path: 'cotacao', loadChildren: './cotacao/cotacao.module#CotacaoModule'},
      { path: 'resposta', loadChildren: './resposta/resposta.module#RespostaModule'}
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class BudgetRoutingModule { }
