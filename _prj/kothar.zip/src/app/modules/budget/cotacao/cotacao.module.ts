import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';

import { CotacaoListComponent } from './cotacao-list/cotacao-list.component';
import { CotacaoFormComponent } from './cotacao-form/cotacao-form.component';
import { SharedModule } from '../../../shared/shared.module';
import { PainelCepModule } from '../../../shared/components/painel-cep/painel-cep.module';
import { CotacaoConsultaComponent } from './cotacao-consulta/cotacao-consulta.component';
import { CotacaoProdutosComponent } from './cotacao-produtos/cotacao-produtos.component';

const routes: Routes = [
  {
    path: '',
    children: [
      { path: 'cotacao-list', component: CotacaoListComponent },
      { path: 'cotacao-form/new', component: CotacaoFormComponent },
      { path: 'cotacao-form/:id', component: CotacaoFormComponent },
      { path: 'cotacao-consulta/:id', component: CotacaoConsultaComponent },
      { path: 'cotacao-produtos', component: CotacaoProdutosComponent }
    ]
  }
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    SharedModule,
    PainelCepModule
  ],
  declarations: [CotacaoListComponent, CotacaoFormComponent, CotacaoConsultaComponent, CotacaoProdutosComponent]
})
export class CotacaoModule { }
