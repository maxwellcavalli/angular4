import { Component, OnInit, ViewChild, TemplateRef, ChangeDetectorRef } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { BehaviorSubject } from 'rxjs';
import { MxDataTableComponent, MxDialogComponent } from 'mx-components';
import { TranslateService } from '@ngx-translate/core';
import { ActivatedRoute, Router } from '@angular/router';

import { LoggedCrudController } from '../../../../shared/guard/logged-crud-controller';
import { Cotacao } from '../../../../shared/entity/cotacao';
import { CotacaoFilter } from '../../../../shared/helper/cotacao-filter';
import { CotacaoService } from '../../../../service/cotacao.service';
import { AuthenticationService } from '../../../../service/security/authentication.service';
import { ClienteEndereco } from '../../../../shared/entity/cliente-endereco';
import { Cliente } from '../../../../shared/entity/cliente';
import { ClienteService } from '../../../../service/cliente.service';

//import moment from 'moment/src/moment';
import * as moment from 'moment';
import { SharedDataService } from '../../../../shared/data/shared-data.service';
import { CotacaoEndereco } from '../../../../shared/entity/cotacao-endereco';
import { Menu } from '../../../../layout/template/menu';

@Component({
  selector: 'app-cotacao-list',
  templateUrl: './cotacao-list.component.html',
  styleUrls: ['./cotacao-list.component.css']
})
export class CotacaoListComponent extends LoggedCrudController<Cotacao> {

  @ViewChild('dialogEndereco') dialogEndereco: MxDialogComponent;
  @ViewChild('dialogNovaCotacao') dialogNovaCotacao: MxDialogComponent;

  @ViewChild('cellCheckboxButton') cellCheckboxButton: TemplateRef<any>;

  URL_LIST: String = "/modules/budget/cotacao/cotacao-list";
  URL_EDIT: String = "/modules/budget/cotacao/cotacao-form/";
  URL_CONSULTA: String = "/modules/budget/cotacao/cotacao-consulta/";
  URL_PRODUTO: String = "/modules/budget/cotacao/cotacao-produtos/";
  FILTER_KEY: string = "cotacao_filter"

  cotacaoFilter: CotacaoFilter = new CotacaoFilter();

  title: String = '';
  situacoes: Array<any>;
  form: FormGroup;

  formCreate: FormGroup;

  rows: BehaviorSubject<any> = new BehaviorSubject<any>(null);
  cols: any;

  @ViewChild('table') _table: MxDataTableComponent;

  /*endereco */
  clienteEndereco: ClienteEndereco = new ClienteEndereco();
  enderecos: BehaviorSubject<Array<ClienteEndereco>> = new BehaviorSubject<Array<ClienteEndereco>>(null);
  colsEndereco: any;
  cliente: Cliente;
  hasEnderecoSelecionado: boolean = false;
  formEndereco: FormGroup;

  /*nova cotacao */
  cotacao = new Cotacao();

  ngOnInit() {
    this._authenticationService.isLogged().subscribe(el => {
      if (el === true) {
        this.init();
      }
    });
  }

  private init() {
    this.cols = [
      { prop: 'cotacao_id', title: this.translate.instant('GEN.ID'), maxWidth: 50, sortable: true, selectable: true },
      { prop: 'cotacao_nome', title: this.translate.instant('GEN.NAME'), sortable: true, selectable: true },
      { prop: 'dataCadastro', title: this.translate.instant('COTACAO.DATA.CADASTRO'), sortable: true, selectable: true, maxWidth: 150, cellTemplate: this._table.cellTplDate, hideOnMobile: true },
      { prop: 'dataLimiteRetorno', title: this.translate.instant('COTACAO.DATA.LIMITE'), sortable: true, selectable: true, maxWidth: 150, cellTemplate: this._table.cellTplDate, hideOnMobile: true },
      { prop: 'dataEnvio', title: this.translate.instant('COTACAO.DATA.ENVIO'), sortable: true, selectable: true, maxWidth: 150, cellTemplate: this._table.cellTplDate, hideOnMobile: true },
      { prop: 'cotacao_situacao_str', title: this.translate.instant('COTACAO.SITUACAO'), sortable: false, selectable: true, maxWidth: 120, hideOnMobile: true },
      { prop: 'cotacao_quantidade_respostas', title: this.translate.instant('COTACAO.QUANTIDADE.RESPOSTAS'), sortable: false, selectable: true, maxWidth: 80, hideOnMobile: true },
      { prop: 'cotacao_id', title: this.translate.instant('GEN.ACTION'), maxWidth: 30, sortable: false, cellTemplate: this._table.cellDeleteButton }
    ];

    this.createTableEndereco();

    this._service.getSituacoes().subscribe(data => {
      this.situacoes = data.object as Array<any>;
    });

    this.listenEndereco();
  }


  ngOnDestroy() {
    this.rows.unsubscribe();
    this.enderecos.unsubscribe();
  }

  protected createDefaultSearchListener() {
    this.pageFilterN.subscribe(_filter => {
      this.isFilterUpdatedP();

      _filter.filterValue = this.onGetFilterValue();
      this.onSaveFilter();

      this._service.searchComplex(_filter).subscribe(
        _ret => {
          this.afterSearch(_ret);
          let _dados = (_ret.object as any).content;

          this.onPopulateTable(_dados as Array<any>)
        },
        response => {
          this.afterResponse(response);
        });
    });
  }

  constructor(
    public _service: CotacaoService,
    public translate: TranslateService,
    protected _authenticationService: AuthenticationService,
    public router: Router,
    public route: ActivatedRoute,
    private formBuilder: FormBuilder,
    private _clienteService: ClienteService,
    private _ref: ChangeDetectorRef,
    private _sharedDataService: SharedDataService) {

    super(_service, translate, _authenticationService, router, route, false);

    super.reloadFilterL(null);
    this.createDefaultSearchListener();

    this.form = formBuilder.group({
      nome: ['', []],
      periodo_cadastro_inicio: [null, []],
      periodo_cadastro_fim: [null, []],
      periodo_limite_inicio: [null, []],
      periodo_limite_fim: [null, []],
      periodo_envio_inicio: [null, []],
      periodo_envio_fim: [null, []],
      situacao: ['', []]
    });

    this.createForm();
    this.createFormEndereco();


    this.title = Menu.getHierarquiaByKey('menu_cotacao');
  }

  private createForm() {
    this.formCreate = this.formBuilder.group({
      nome: ['', [
        Validators.required,
        Validators.minLength(3)
      ]],
      data_limite: [null, [
        Validators.required
      ]],
      hora: [null, [
        Validators.required
      ]]
    });
  }

  private listenEndereco() {
    this.enderecos.subscribe(dados => {
      if (dados) {
        this.hasEnderecoSelecionado = dados.filter(_el => _el.cliente_endereco_selecionado == true).length > 0;
      }
    });
  }

  onUpdateFilterValue(value: any): void {
    this.cotacaoFilter.nome = value.nome;
    this.cotacaoFilter.situacaoCotacao = value.situacaoCotacao;
    this.cotacaoFilter.periodoCadastro.inicio = value.periodoCadastro.inicio;
    this.cotacaoFilter.periodoCadastro.fim = value.periodoCadastro.fim;
    this.cotacaoFilter.periodoEnvio.inicio = value.periodoEnvio.inicio;
    this.cotacaoFilter.periodoEnvio.fim = value.periodoEnvio.fim;
    this.cotacaoFilter.periodoRetorno.inicio = value.periodoRetorno.inicio;
  }

  onGetFilterKey(): string {
    return this.FILTER_KEY;
  };

  onPopulateTable(dados: Array<any>) {
    this.rows.next(dados);
  }

  onGetFilterValue(): any {
    return this.cotacaoFilter;
  }

  public reset(event) {
    this.cotacaoFilter.nome = '';
    this.cotacaoFilter.situacaoCotacao = null;
    this.cotacaoFilter.periodoCadastro.inicio = null;
    this.cotacaoFilter.periodoCadastro.fim = null;
    this.cotacaoFilter.periodoEnvio.inicio = null;
    this.cotacaoFilter.periodoEnvio.fim = null;
    this.cotacaoFilter.periodoRetorno.inicio = null;
    this.oldValue = null;

    this.searchEvent(event);
  }

  public searchEvent(event: any) {
    this._authenticationService.isLogged().subscribe(el => {
      if (el === true) {
        super.searchEvent(event);
      }
    });
  }

  public edit(event) {
    let object = event.row;

    if (object.cotacao_quantidade_respostas > 0) {
      let url = this.URL_CONSULTA + object.cotacao_id;
      this.router.navigate([url]);
    } else {
      let url = this.URL_EDIT + object.cotacao_id;
      this.router.navigate([url]);
    }
  }

  public add(event) {
    this._authenticationService.isLogged().subscribe(el => {
      if (el === true) {
        this.loadEnderecos();
        this.dialogNovaCotacao.openDialog();
      }
    })
  }


  //ENDERECOS
  private loadEnderecos() {

    this._clienteService.getLogged().subscribe(
      _ret => {
        this.cliente = (_ret.object as Cliente);

        let index = 0;
        for (let x of this.cliente.cliente_enderecos) {
          (x as any).$$index = index++;
        }

        let _cot_end = this.cotacao.cotacao_endereco;

        if (_cot_end != undefined && _cot_end != null) {
          let _list = this.cliente.cliente_enderecos.filter(el => {
            return el.cliente_endereco_cep.cep_id == _cot_end.cotacao_endereco_cep.cep_id &&
              el.cliente_endereco_complemento.numero == _cot_end.cotacao_endereco_complemento.numero &&
              el.cliente_endereco_complemento.complemento == _cot_end.cotacao_endereco_complemento.complemento;
          });

          if (_list.length > 0) {
            _list[0].cliente_endereco_selecionado = true;
          }
        }


        this.enderecos.next(this.cliente.cliente_enderecos);
      },
      response => this.afterResponse(response)
    );
  }

  private createTableEndereco() {
    this.colsEndereco = [
      { prop: 'cliente_endereco_selecionado', title: this.translate.instant('CLIENTE.ENDERECO.PRINCIPAL'), sortable: false, selectable: false, maxWidth: 50, cellTemplate: this.cellCheckboxButton },
      { prop: 'cliente_endereco_alias', title: this.translate.instant('CLIENTE.ENDERECO.ALIAS'), sortable: false, selectable: true, maxWidth: 120 },
      { prop: 'cliente_endereco_cep.codigoPostal', title: this.translate.instant('CEP.CODIGO.POSTAL'), sortable: false, selectable: true, maxWidth: 100, hideOnMobile: true },
      { prop: 'cliente_endereco_cep.cep_bairro.bairro_cidade.cidade_estado.sigla', title: this.translate.instant('CEP.ESTADO'), sortable: false, selectable: true, maxWidth: 70, hideOnMobile: true },
      { prop: 'cliente_endereco_cep.cep_bairro.bairro_cidade.cidade_nome', title: this.translate.instant('CEP.CIDADE'), sortable: false, selectable: true, hideOnMobile: true },
      { prop: 'cliente_endereco_cep.cep_bairro.bairro_nome', title: this.translate.instant('CEP.BAIRRO'), sortable: false, selectable: false, hideOnMobile: true },
      { prop: 'cliente_endereco_cep.cep_nome', title: this.translate.instant('CEP.RUA'), sortable: false, selectable: true },
      { prop: 'cliente_endereco_complemento.numero', title: this.translate.instant('CLIENTE.ENDERECO.NUMERO'), sortable: false, selectable: true, maxWidth: 100, hideOnMobile: true },
      //{ prop: 'cliente_endereco_id', title: this.translate.instant('GEN.ACTION'), maxWidth: 30, sortable: false, cellTemplate: this._tableEndereco.cellDeleteButton },
    ];

  }

  public selecionarEndereco(event) {
    let _end = this.enderecos.value;
    let _end_cli = event.row;

    for (let x of _end) {
      x.cliente_endereco_selecionado = false;
    }

    let index = _end.findIndex(_el => (_el as any).$$index === _end_cli.$$index);
    _end[index].cliente_endereco_selecionado = true;

    this.enderecos.next(_end);
  }

  public selection(row: any, event: any, checked: boolean): void {
    row.cliente_endereco_selecionado = checked;

    let _end = this.enderecos.value;
    let idx = row.$$index;
    let index = _end.findIndex(_el => (_el as any).$$index === idx);
    if (index > -1) {
      _end.forEach(_el => _el.cliente_endereco_selecionado = false);

      _end[index].cliente_endereco_selecionado = checked;

      this.enderecos.next(_end);
    }
  }

  getData(row) {
    return row.cliente_endereco_selecionado;
  }

  public adicionarEndereco(): void {
    this._authenticationService.isLogged().subscribe(el => {
      if (el === true) {
        this.clienteEndereco = new ClienteEndereco();
        this.clienteEndereco.cliente_endereco_cep = undefined;

        let _end = this.enderecos.value;
        if (_end.length == 0) {
          this.clienteEndereco.cliente_endereco_principal = true;
        } else {
          this.clienteEndereco.cliente_endereco_principal = false;
        }

        this._ref.detectChanges();
        this.dialogEndereco.openDialog();
      } else if (el === false) {
        this.dialogNovaCotacao.closeDialog();
      }
    });
  }

  private createFormEndereco() {
    this.formEndereco = this.formBuilder.group({
      alias: ['', [
        Validators.required,
        Validators.minLength(3)
      ]],
      cep: ['', [
        Validators.required
      ]]
    });
  }

  public salvarEndereco(): void {

    this._authenticationService.isLogged().subscribe(el => {
      if (el === true) {
        let _end = this.enderecos.value;

        this.clienteEndereco.cliente_endereco_complemento = this.clienteEndereco.cliente_endereco_cep.endereco_complemento;
        let $$index = (this.clienteEndereco as any).$$index;

        if ($$index) {
          let index = _end.findIndex(_el => (_el as any).$$index === $$index);
          _end[index] = this.clienteEndereco;
        } else {
          (this.clienteEndereco as any).$$index = _end.length + 1;
          _end.push(this.clienteEndereco);

          this.clienteEndereco = new ClienteEndereco();
        }

        this.cliente.cliente_enderecos = _end;

        this.cliente.cliente_enderecos.forEach(el => {
          (el as any).cols = undefined;
        });

        this.dialogEndereco.closeDialog();
        this._clienteService.update(this.cliente.cliente_id, this.cliente).subscribe(
          _ret => {
            this.cliente = (_ret.object as Cliente);
            _end = this.cliente.cliente_enderecos;

            let index = 0;
            for (let x of _end) {
              (x as any).$$index = index++;
            }

            this.enderecos.next(_end);

          },
          response => this.afterResponse(response));

      }
    });
  }

  public salvarNovaCotacao() {
    this._authenticationService.isLogged().subscribe(el => {
      if (el === true) {
        var _cot = Object.assign({}, this.cotacao);
        let _end = this.enderecos.value;

        let _l = _end.filter(el => el.cliente_endereco_selecionado == true);
        let _endCli = _l[0];

        //replicar as informacoes de endereco do cliente para a cotacao
        let _cotacaoEndereco = new CotacaoEndereco();
        _cotacaoEndereco.cotacao_endereco_cep = _endCli.cliente_endereco_cep;
        _cotacaoEndereco.cotacao_endereco_complemento = _endCli.cliente_endereco_complemento;
        _cotacaoEndereco.cotacao_endereco_alias = _endCli.cliente_endereco_alias;
        _cot.cotacao_endereco = _cotacaoEndereco;

        let _m = moment(_cot.dataLimiteRetorno);
        let _d = _m.format('YYYY-MM-DD');
        _d = _d + 'T' + _cot.cotacao_hora;
        _cot.dataLimiteRetorno = moment(_d).toDate();

        this._service.insert(_cot).subscribe(
          _ret => this.afterSave(_ret),
          response => this.afterResponse(response));
      } else if (el === false){
        this.dialogNovaCotacao.closeDialog();
      }
    });
  }

  protected afterSave(data: any) {
    let _cot = data.object;
    this._sharedDataService.cotacao.next(_cot);

    this.dialogNovaCotacao.closeDialog();
    this.router.navigate([this.URL_PRODUTO]);
  }


}
