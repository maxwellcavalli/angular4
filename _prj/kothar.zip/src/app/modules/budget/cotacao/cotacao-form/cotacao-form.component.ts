import { Component, OnInit, ViewChild, ChangeDetectorRef, SimpleChanges, TemplateRef } from '@angular/core';
import { MxBaseController, MxResponseEntity } from 'mx-core';
import { MxDialogComponent } from 'mx-components';
import { BehaviorSubject, Subject } from 'rxjs';
import { Router, ActivatedRoute } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { FormGroup, FormBuilder, Validators, FormArray } from '@angular/forms';


import { Cotacao } from '../../../../shared/entity/cotacao';
import { CotacaoService } from '../../../../service/cotacao.service';
import { SharedDataService } from '../../../../shared/data/shared-data.service';
import { CotacaoItem } from '../../../../shared/entity/cotacao-item';
import { CotacaoItemArquivo } from '../../../../shared/entity/cotacao-item-arquivo';

import { ClienteEndereco } from '../../../../shared/entity/cliente-endereco';
import { Cliente } from '../../../../shared/entity/cliente';
import { ClienteService } from '../../../../service/cliente.service';
import { CotacaoEndereco } from '../../../../shared/entity/cotacao-endereco';


//import moment from 'moment/src/moment';
import * as moment from 'moment';
import { Menu } from '../../../../layout/template/menu';
import { AuthenticationService } from '../../../../service/security/authentication.service';
import { DetalhesProdutoComponent } from '../../../../shared/components/detalhes-produto/detalhes-produto.component';


@Component({
  selector: 'app-cotacao-form',
  templateUrl: './cotacao-form.component.html',
  styleUrls: ['./cotacao-form.component.css']
})
export class CotacaoFormComponent extends MxBaseController implements OnInit {

  @ViewChild('dialogArquivos') dialogArquivos: MxDialogComponent;
  @ViewChild('dialogSend') dialogSend: MxDialogComponent;
  @ViewChild('dialogEndereco') dialogEndereco: MxDialogComponent;

  @ViewChild('detalhesProduto') detalhesProduto: DetalhesProdutoComponent;

  @ViewChild('cellCheckboxButton') cellCheckboxButton: TemplateRef<any>;

  URL_LIST: String = "/modules/budget/cotacao/cotacao-list";
  URL_EDIT: String = "/modules/budget/cotacao/cotacao-form/";
  URL_PRODUTO: String = "/modules/budget/cotacao/cotacao-produtos/";

  cotacao: Cotacao = new Cotacao();
  form: FormGroup;

  selected_item_index: any;
  habilita_alteracoes: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(true);
  possui_itens: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
  permite_cancelar: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);

  private _destroy: Subject<Cotacao> = new Subject();

  /*endereco */
  clienteEndereco: ClienteEndereco = new ClienteEndereco();
  enderecos: BehaviorSubject<Array<ClienteEndereco>> = new BehaviorSubject<Array<ClienteEndereco>>(null);
  cols: any;
  cliente: Cliente;
  hasEnderecoSelecionado: boolean = false;
  formEndereco: FormGroup;

  title: String = '';
  ngOnDestroy() {

    this.habilita_alteracoes.unsubscribe();
    this.possui_itens.unsubscribe();
    this.permite_cancelar.unsubscribe();
    this.enderecos.unsubscribe();

    this._destroy.next();
    this._destroy.unsubscribe();
  }

  public ngOnInit() {
    this._authenticationService.isLogged().subscribe(el => {
      if (el === true) {
        this.init();
      }
    });

  }

  private init() {
    var id = this.route.params.subscribe(params => {
      var id = params['id'];

      if (!id)
        return;

      this._cotacaoService.get(id).subscribe(
        data => this.afterGet(data),
        response => this.afterResponse(response)
      );
    });

    this.createTableEndereco();
    this.listenCotacao();
    this.listenEndereco();
  }

  constructor(
    private formBuilder: FormBuilder,
    private _ref: ChangeDetectorRef,
    private router: Router,
    private route: ActivatedRoute,
    public translate: TranslateService,
    private _cotacaoService: CotacaoService,
    private _sharedDataService: SharedDataService,
    private _clienteService: ClienteService,
    private _authenticationService: AuthenticationService) {

    super(translate);
    this.createForm();

    this.validateComponentState();

    this.createFormEndereco();
    this.title = Menu.getHierarquiaByKey('menu_cotacao', this._sharedDataService.menus.value);
  }

  private listenEndereco() {
    this.enderecos
      .takeUntil(this._destroy)
      .subscribe(dados => {
        if (dados) {
          this.hasEnderecoSelecionado = dados.filter(_el => _el.cliente_endereco_selecionado == true).length > 0;
        }
      });
  }

  private listenCotacao() {
    this._sharedDataService.cotacao
      .takeUntil(this._destroy)
      .subscribe(_cot => {

        if (_cot != undefined && _cot != null) {
          this.cotacao = _cot;

          let _hasItens = (_cot as Cotacao)
            .cotacao_item.filter(v =>
              v.cotacao_item_id !== undefined &&
              v.cotacao_item_id !== null &&
              v.cotacao_item_id !== 0).length > 0;

          this.possui_itens.next(_hasItens);
          let cotacao_permite_alteracoes = this.cotacao.cotacao_permite_alteracoes;
          if (cotacao_permite_alteracoes === undefined) {
            cotacao_permite_alteracoes = true;
          }

          let cotacao_permite_cancelar = this.cotacao.cotacao_permite_cancelar;

          this.permite_cancelar.next(cotacao_permite_cancelar);
          this.cotacao.cotacao_permite_alteracoes = cotacao_permite_alteracoes;

          this.deleteItemControls();
          this.createFormArray();
          this.validateComponentState();

          this.habilita_alteracoes.next(cotacao_permite_alteracoes);

          this.form.markAsPristine({ onlySelf: false });
          this.form.controls['hora'].markAsPristine({ onlySelf: false });

          this.loadEnderecos();
        }
      });
  }

  public afterGet(data) {

    let _cot = (data.object as Cotacao)
    let _limite = _cot.dataLimiteRetorno;

    if (_limite) {
      let _m = moment(_limite);

      _cot.cotacao_hora = _m.format('HH:mm');
      _cot.dataLimiteRetorno = _m.toDate();
    } else {
      _cot.cotacao_hora = '';
    }

    this._sharedDataService.cotacao.next(_cot);
  }

  private createForm() {
    this.form = this.formBuilder.group({
      numero: [{ value: '', disabled: true }, []],
      nome: ['', [
        Validators.required,
        Validators.minLength(3)
      ]],
      data_cadastro: [{ value: null, disabled: true }, []],
      data_limite: [null, [
        Validators.required
      ]],
      hora: [null, [
        Validators.required
      ]],
      data_envio: [{ value: null, disabled: true }, []],
      itens: new FormArray([]),
      situacao: [{ value: '', disabled: true }, []],
    });
  }

  private saveLocal(): void {
    this._sharedDataService.cotacao.next(this.cotacao);
  }

  private deleteItemControls() {
    while ((this.form.controls['itens'] as FormArray).length > 0) {
      (this.form.controls['itens'] as FormArray).removeAt(0);
    }
  }

  public deleteItem(index) {
    if (confirm(this.translate.instant("GEN.DELETE.MESSAGE"))) {
      if (index > -1) {
        this.cotacao.cotacao_item.splice(index, 1);
        (this.form.controls['itens'] as FormArray).removeAt(index);
      }

      this.saveLocal();

      this.form.markAsDirty({ onlySelf: true });
      this._ref.detectChanges();
    }
  }

  private validateComponentState() {
    let disabled = !this.cotacao.cotacao_permite_alteracoes;

    this.form.controls['data_cadastro'].disable({ onlySelf: true });
    this.form.controls['data_limite'].disable({ onlySelf: true });

    if (disabled) {
      this.form.controls['nome'].disable({ onlySelf: true });
      this.form.controls['data_limite'].disable({ onlySelf: true });
      this.form.controls['hora'].disable({ onlySelf: true });

      (this.form.controls['itens'] as FormArray).controls.forEach(_d => {
        _d.disable({ onlySelf: true });
      });

    } else {
      this.form.controls['nome'].enable({ onlySelf: true });
      this.form.controls['data_limite'].enable({ onlySelf: true });
      this.form.controls['hora'].enable({ onlySelf: true });

      (this.form.controls['itens'] as FormArray).controls.forEach(_d => {
        _d.enable({ onlySelf: true });
      });
    }
  }

  private createFormArray() {
    this.cotacao.cotacao_item.forEach((item: CotacaoItem) => {
      this.formItens.push(this.createCustomGroup(item));
    });
  }

  private createCustomGroup(item: CotacaoItem) {
    if (item.cotacao_item_produto.generico) {
      return this.formBuilder.group({
        detalhamento: ['', [
          Validators.required,
          Validators.minLength(3)
        ]],

        quantidade: ['', [
          Validators.min(1)
        ]]
      })

    } else {
      return this.formBuilder.group({
        detalhamento: ['', [
        ]],

        quantidade: ['', [
          Validators.min(1)
        ]]
      })
    }
  }

  get itens(): Array<CotacaoItem> {
    return this.cotacao.cotacao_item;
  }

  get cotacaoItem(): CotacaoItem {
    return this.itens[this.selected_item_index];
  }

  get formItens(): FormArray {
    return this.form.controls['itens'] as FormArray;
  }

  public save() {
    this._authenticationService.isLogged().subscribe(el => {
      if (el === true) {
        var _cot = Object.assign({}, this.cotacao);

        let _m = moment(_cot.dataLimiteRetorno);
        let _d = _m.format('YYYY-MM-DD');
        _d = _d + 'T' + _cot.cotacao_hora;
        _cot.dataLimiteRetorno = moment(_d).toDate();

        if (_cot.cotacao_id) {
          this._cotacaoService.update(_cot.cotacao_id, _cot).subscribe(
            _ret => this.afterUpdate(_ret),
            response => this.afterResponse(response));
        } else {
          this._cotacaoService.insert(_cot).subscribe(
            _ret => this.afterSave(_ret),
            response => this.afterResponse(response));
        }
      }
    });
  }

  public cancelar(): void {
    this._authenticationService.isLogged().subscribe(el => {
      if (el === true) {
        if (confirm(this.translate.instant("GEN.CONFIRM.MESSAGE"))) {
          this._cotacaoService.cancelarCotacao(this.cotacao).subscribe(
            data => this.afterCancelar(data),
            response => this.afterResponse(response)
          );
        }
      }
    });
  }

  private afterCopiar(data: any) {
    let _o = data.object;
    this.afterGet(data);

    let url = this.URL_EDIT + _o.cotacao_id;
    this.router.navigate([url]);
  }

  private afterCancelar(data: any) {
    alert(this.translate.instant('COTACAO.MENSAGEM.CANCELADA'));

    this.afterGet(data);
  }

  protected afterUpdate(data) {
    super.defaultUpdateMessage();
    this.afterGet(data);

    this.form.markAsPristine({ onlySelf: true });

    this._ref.detectChanges();
  }

  public afterSave(responseEntity: MxResponseEntity) {
    this.form.markAsPristine({ onlySelf: true });

    super.defaultSaveMessage();
    let _o = (responseEntity.object as any);

    this.afterGet(responseEntity);

    let url = this.URL_EDIT + _o.cotacao_id;
    this.router.navigate([url]);
  }

  public copiar(): void {
    this._authenticationService.isLogged().subscribe(el => {
      if (el === true) {
        if (confirm(this.translate.instant("GEN.CONFIRM.MESSAGE"))) {
          this._cotacaoService.copiarCotacao(this.cotacao).subscribe(
            data => this.afterCopiar(data),
            response => this.afterResponse(response)
          );
        }

      }
    });
  }

  //file upload
  onStartFileUpload(event) {
    this.selected_item_index = event;
  }

  onFinishUpload(files: Array<any>) {
    let cotacaoItem = this.itens[this.selected_item_index];
    if (!cotacaoItem.cotacao_item_arquivos) {
      cotacaoItem.cotacao_item_arquivos = new Array<CotacaoItemArquivo>();
    }

    for (let i = 0; i < files.length; i++) {
      let obj = files[i];

      let cotacaoItemArquivo = new CotacaoItemArquivo();
      cotacaoItemArquivo.cotacao_item_arquivo_nome = obj.name;
      cotacaoItemArquivo.imagem64 = obj.content;

      cotacaoItem.cotacao_item_arquivos.push(cotacaoItemArquivo);
    }

    this.cotacao.cotacao_item[this.selected_item_index] = cotacaoItem;
    this.saveLocal();
  }

  public downloadArquivo(cotacaoItemArquivo: CotacaoItemArquivo) {
    let index = this.cotacaoItem.cotacao_item_arquivos.indexOf(cotacaoItemArquivo);
    cotacaoItemArquivo = this.cotacaoItem.cotacao_item_arquivos[index];

    if (cotacaoItemArquivo.imagem64 === undefined || cotacaoItemArquivo.imagem64 === '') {
      this._cotacaoService.getArquivo(cotacaoItemArquivo.cotacao_item_arquivo_id).subscribe(data => {
        let obj = data.object;
        cotacaoItemArquivo = (obj as any);

        this.cotacaoItem.cotacao_item_arquivos[index] = cotacaoItemArquivo;
        this.cotacao.cotacao_item[this.selected_item_index] = this.cotacaoItem;
        this.saveLocal();

        let base64: string = (cotacaoItemArquivo.imagem64 as string);
        let name: string = (cotacaoItemArquivo.cotacao_item_arquivo_nome as string);

        base64 = 'data:application/octet-stream;base64,' + base64;
        super.download(base64, name);
      });
    } else {
      let base64: string = (cotacaoItemArquivo.imagem64 as string);
      let name: string = (cotacaoItemArquivo.cotacao_item_arquivo_nome as string);

      base64 = 'data:application/octet-stream;base64,' + base64;
      super.download(base64, name);
    }
  }

  openDialog(index) {
    this.selected_item_index = index;

    let _cotIte = this.cotacao.cotacao_item[this.selected_item_index];
    this.dialogArquivos.title = _cotIte.cotacao_item_produto.produto_nome;
    this.dialogArquivos.openDialog();
  }

  openDialogDetalhes(index) {
    this.selected_item_index = index;
    let _cotIte = this.cotacao.cotacao_item[this.selected_item_index];
    let produto = _cotIte.cotacao_item_produto;

    this.detalhesProduto.openDialog(produto);
  }

  deleteArquivo(cotacaoItemArquivo: CotacaoItemArquivo) {
    let index = this.cotacaoItem.cotacao_item_arquivos.indexOf(cotacaoItemArquivo);
    if (index > -1) {
      this.cotacaoItem.cotacao_item_arquivos.splice(index, 1);
    }

    this.cotacao.cotacao_item[this.selected_item_index] = this.cotacaoItem;
    this.saveLocal();

    this.form.markAsDirty({ onlySelf: true });
    this._ref.detectChanges();
  }

  public openDialogSend() {
    this.dialogSend.openDialog();
  }

  public send() {
    this.dialogSend.closeDialog();

    this._authenticationService.isLogged().subscribe(el => {
      if (el === true) {
        if (confirm(this.translate.instant("GEN.CONFIRM.MESSAGE"))) {
          var _cot = Object.assign({}, this.cotacao);

          let _end = this.enderecos.value;
          let _sel = _end.filter(_el => _el.cliente_endereco_selecionado == true);
          let _endCli = _sel[0];

          //replicar as informacoes de endereco do cliente para a cotacao
          let _cotacaoEndereco = new CotacaoEndereco();
          _cotacaoEndereco.cotacao_endereco_cep = _endCli.cliente_endereco_cep;
          _cotacaoEndereco.cotacao_endereco_complemento = _endCli.cliente_endereco_complemento;
          _cotacaoEndereco.cotacao_endereco_alias = _endCli.cliente_endereco_alias;
          _cot.cotacao_endereco = _cotacaoEndereco;

          this._cotacaoService.enviarCotacao(_cot).subscribe(
            data => {

              this._sharedDataService.cotacao.next(data.object);
              alert(this.translate.instant('COTACAO.MENSAGEM.ENVIADO'));
            },
            response => {
              this.afterResponse(response);
            });
        }
      }
    });
  }


  //ENDERECOS
  private loadEnderecos() {
    this.cliente = this.cotacao.cotacao_cliente;
    this._clienteService.get(this.cliente.cliente_id).subscribe(
      _ret => {
        this.cliente = (_ret.object as Cliente);

        let index = 0;
        for (let x of this.cliente.cliente_enderecos) {
          (x as any).$$index = index++;
        }

        let _cot_end = this.cotacao.cotacao_endereco;

        if (_cot_end != undefined && _cot_end != null) {
          let _list = this.cliente.cliente_enderecos.filter(el => {
            return el.cliente_endereco_cep.cep_id == _cot_end.cotacao_endereco_cep.cep_id &&
              el.cliente_endereco_complemento.numero == _cot_end.cotacao_endereco_complemento.numero &&
              el.cliente_endereco_complemento.complemento == _cot_end.cotacao_endereco_complemento.complemento;
          });

          if (_list.length > 0) {
            _list[0].cliente_endereco_selecionado = true;
          }
        }

        if (!this.enderecos.isStopped) {
          this.enderecos.next(this.cliente.cliente_enderecos);
        }

      },
      response => this.afterResponse(response)
    );
  }

  private createTableEndereco() {
    this.cols = [
      { prop: 'cliente_endereco_selecionado', title: this.translate.instant('CLIENTE.ENDERECO.PRINCIPAL'), sortable: false, selectable: false, maxWidth: 50, cellTemplate: this.cellCheckboxButton },
      { prop: 'cliente_endereco_alias', title: this.translate.instant('CLIENTE.ENDERECO.ALIAS'), sortable: false, selectable: true, maxWidth: 120 },
      { prop: 'cliente_endereco_cep.codigoPostal', title: this.translate.instant('CEP.CODIGO.POSTAL'), sortable: false, selectable: true, maxWidth: 100, hideOnMobile: true },
      { prop: 'cliente_endereco_cep.cep_bairro.bairro_cidade.cidade_estado.sigla', title: this.translate.instant('CEP.ESTADO'), sortable: false, selectable: true, maxWidth: 70, hideOnMobile: true },
      { prop: 'cliente_endereco_cep.cep_bairro.bairro_cidade.cidade_nome', title: this.translate.instant('CEP.CIDADE'), sortable: false, selectable: true, hideOnMobile: true },
      { prop: 'cliente_endereco_cep.cep_bairro.bairro_nome', title: this.translate.instant('CEP.BAIRRO'), sortable: false, selectable: false, hideOnMobile: true },
      { prop: 'cliente_endereco_cep.cep_nome', title: this.translate.instant('CEP.RUA'), sortable: false, selectable: true },
      { prop: 'cliente_endereco_complemento.numero', title: this.translate.instant('CLIENTE.ENDERECO.NUMERO'), sortable: false, selectable: true, maxWidth: 100, hideOnMobile: true },
      //{ prop: 'cliente_endereco_id', title: this.translate.instant('GEN.ACTION'), maxWidth: 30, sortable: false, cellTemplate: this._tableEndereco.cellDeleteButton },
    ];

  }

  public selecionarEndereco(event) {
    let _end = this.enderecos.value;
    let _end_cli = event.row;

    for (let x of _end) {
      x.cliente_endereco_selecionado = false;
    }

    let index = _end.findIndex(_el => (_el as any).$$index === _end_cli.$$index);
    _end[index].cliente_endereco_selecionado = true;

    this.enderecos.next(_end);
  }

  public selection(row: any, event: any, checked: boolean): void {
    row.cliente_endereco_selecionado = checked;

    let _end = this.enderecos.value;
    let idx = row.$$index;
    let index = _end.findIndex(_el => (_el as any).$$index === idx);
    if (index > -1) {
      _end.forEach(_el => _el.cliente_endereco_selecionado = false);

      _end[index].cliente_endereco_selecionado = checked;

      this.enderecos.next(_end);
    }
  }

  getData(row) {
    return row.cliente_endereco_selecionado;
  }

  public adicionarEndereco(): void {
    this.clienteEndereco = new ClienteEndereco();
    this.clienteEndereco.cliente_endereco_cep = undefined;

    let _end = this.enderecos.value;
    if (_end.length == 0) {
      this.clienteEndereco.cliente_endereco_principal = true;
    } else {
      this.clienteEndereco.cliente_endereco_principal = false;
    }

    this._ref.detectChanges();
    this.dialogEndereco.openDialog();
  }

  private createFormEndereco() {
    this.formEndereco = this.formBuilder.group({
      alias: ['', [
        Validators.required,
        Validators.minLength(3)
      ]],
      cep: ['', [
        Validators.required
      ]]
    });
  }

  public salvarEndereco(): void {
    this._authenticationService.isLogged().subscribe(el => {
      if (el === true) {

        let _end = this.enderecos.value;

        this.clienteEndereco.cliente_endereco_complemento = this.clienteEndereco.cliente_endereco_cep.endereco_complemento;
        let $$index = (this.clienteEndereco as any).$$index;

        if ($$index) {
          let index = _end.findIndex(_el => (_el as any).$$index === $$index);
          _end[index] = this.clienteEndereco;
        } else {
          (this.clienteEndereco as any).$$index = _end.length + 1;
          _end.push(this.clienteEndereco);

          this.clienteEndereco = new ClienteEndereco();
        }

        this.cliente.cliente_enderecos = _end;

        this.cliente.cliente_enderecos.forEach(el => {
          (el as any).cols = undefined;
        });

        this.dialogEndereco.closeDialog();
        this._clienteService.update(this.cliente.cliente_id, this.cliente).subscribe(
          _ret => {
            this.cliente = (_ret.object as Cliente);
            _end = this.cliente.cliente_enderecos;

            let index = 0;
            for (let x of _end) {
              (x as any).$$index = index++;
            }

            this.enderecos.next(_end);

          },
          response => this.afterResponse(response));

      } else if (el === false) {
        this.dialogEndereco.closeDialog();
      }
    });
  }

  public adicionarProdutos() {
    this._authenticationService.isLogged().subscribe(el => {
      if (el === true) {
        this._sharedDataService.cotacao.next(this.cotacao);
        this.router.navigate([this.URL_PRODUTO]);
      }
    });
  }


}
