import { Component, OnInit, ViewChild, ChangeDetectorRef } from '@angular/core';
import { MxBaseController } from 'mx-core';
import { MxDialogComponent } from 'mx-components';
import { FormGroup, FormBuilder, Validators, FormArray } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import { Router, ActivatedRoute } from '@angular/router';


import { Cotacao } from '../../../../shared/entity/cotacao';
import { CotacaoItemHelper } from '../../../../shared/helper/consulta-cotacao/cotacao-item-helper';
import { CotacaoFornecedorHelper } from '../../../../shared/helper/consulta-cotacao/cotacao-fornecedor-helper';
import { ConsultaRespostaService } from '../../../../service/consulta-resposta.service';
import { MapsService } from '../../../../service/map.service';
import { RetornoConsultaCotacaoHelper } from '../../../../shared/helper/consulta-cotacao/retorno-consulta-cotacao-helper';
import { CotacaoFornecedor } from '../../../../shared/entity/cotacao-fornecedor';
import { CotacaoItemFornecedorValorHelper } from '../../../../shared/helper/consulta-cotacao/cotacao-item-fornecedor-valor-helper';
import { CotacaoItemFornecedorValor } from '../../../../shared/entity/cotacao-item-fornecedor-valor';
import { CotacaoService } from '../../../../service/cotacao.service';

//import moment from 'moment/src/moment';
import * as moment from 'moment';
import { Cliente } from '../../../../shared/entity/cliente';
import { Menu } from '../../../../layout/template/menu';
import { AuthenticationService } from '../../../../service/security/authentication.service';
import { AvaliacaoService } from '../../../../service/avaliacao.service';
import { Avaliacao } from '../../../../shared/entity/avaliacao';
import { CotacaoHelper } from '../../../../shared/helper/consulta-cotacao/cotacao-helper';

@Component({
  selector: 'app-cotacao-consulta',
  templateUrl: './cotacao-consulta.component.html',
  styleUrls: ['./cotacao-consulta.component.css']
})
export class CotacaoConsultaComponent extends MxBaseController implements OnInit {

  URL_LIST: String = "/modules/budget/cotacao/cotacao-list";
  URL_EDIT: String = "/modules/budget/cotacao/cotacao-form/";

  @ViewChild('dialogHistorico') dialogHistorico: MxDialogComponent;
  @ViewChild('dialogFornecedores') dialogFornecedores: MxDialogComponent;
  @ViewChild('dialogEnderecoFornecedor') dialogEnderecoFornecedor: MxDialogComponent;
  @ViewChild('dialogPendenciasFornecedor') dialogPendenciasFornecedor: MxDialogComponent;
  @ViewChild('dialogVoucher') dialogVoucher: MxDialogComponent;

  @ViewChild('dialogAvaliacao') dialogAvaliacao: MxDialogComponent;

  cotacao: Cotacao = new Cotacao();
  itens: Array<CotacaoItemHelper>;
  fornecedores: Array<CotacaoFornecedorHelper>;
  fornecedoresAll: Array<CotacaoFornecedorHelper>;

  form: FormGroup;
  formAvaliacao: FormGroup;

  cotacaoItemHelper: CotacaoItemHelper = new CotacaoItemHelper();
  cotacaoFornecedorHelper: CotacaoFornecedorHelper = new CotacaoFornecedorHelper();

  showMoreFornecedores: boolean = false;
  showVoucher: boolean = false;
  resposta_com_pendencias: boolean = false;
  cotacao_finalizada: boolean = false;

  dialog_info: any = {
    fornecedor: '',
    valor: ''
  }

  origin: any = {
    latitude: 0,
    longitude: 0
  };

  destination: any = {
    latitude: 0,
    longitude: 0
  };

  showDirections = false;
  showMap: boolean = false;
  title: String = '';

  /*avaliacao */
  respostaRecebeuProduto = null;
  motivos: Array<any>;
  motivoSelecionado: any;
  detalhamento: String;
  rating: Number = 0;

  avaliacao: Avaliacao;

  constructor(
    private consultaRespostaService: ConsultaRespostaService,
    private _mapsService: MapsService,
    public translate: TranslateService,
    private cdr: ChangeDetectorRef,

    public router: Router,
    public route: ActivatedRoute,
    private formBuilder: FormBuilder,
    private _cotacaoService: CotacaoService,
    private _authenticationService: AuthenticationService,
    private _avaliacaoService: AvaliacaoService) {

    super(translate);
    this.createForm()
    this.createFormAvaliacao();

    this.title = Menu.getHierarquiaByKey('menu_cotacao') + ' > ' + translate.instant('COTACAO.CONSULTA.TITLE');
  }

  private createForm() {
    this.form = this.formBuilder.group({
      numero: [{ value: '', disabled: true }, []],
      nome: [{ value: '', disabled: true }, []],
      data_cadastro: [{ value: '', disabled: true }, []],
      data_limite: [{ value: '', disabled: true }, []],
      hora: [{ value: '', disabled: true }, []],
      data_envio: [{ value: null, disabled: true }, []],
      situacao: [{ value: '', disabled: true }, []],
    });
  }

  private createFormAvaliacao() {
    this.formAvaliacao = this.formBuilder.group({
      recebeu_produto: [null, [Validators.required]],
      motivo: [null, []],
      detalhamento: [null, []],
      rating: [null, []],
    });
  }


  public ngOnInit() {
    this._authenticationService.isLogged().subscribe(el => {
      if (el === true) {
        this.init();
      }
    });
  }

  private init() {
    var id = this.route.params.subscribe(params => {
      var id = params['id'];

      if (!id)
        return;

      this.consultaRespostaService.get(id).subscribe(
        data => this.afterGet(data),
        response => this.afterResponse(response)
      );
    });

    this._avaliacaoService.getMotivos().subscribe(
      ret => {
        let _list = ret.object as Array<any>;
        this.motivos = new Array<any>();

        _list.forEach(el => {
          this.motivos.push(el);
        });
      },
      response => this.afterResponse(response)
    );
  }

  public afterGet(data: any) {
    let _retornoConsultaCotacaoHelper = (data.object as RetornoConsultaCotacaoHelper);
    let _cot = _retornoConsultaCotacaoHelper.cotacao;

    this.cotacao.cotacao_id = _cot.cotacao_id;
    this.cotacao.cotacao_nome = _cot.cotacao_nome;
    this.cotacao.dataCadastro = _cot.cotacao_data_cadastro;
    this.cotacao.dataLimiteRetorno = _cot.cotacao_data_limite_retorno;
    this.cotacao.dataEnvio = _cot.cotacao_data_envio;
    this.cotacao.cotacao_situacao_str = _cot.cotacao_situacao_str;
    this.cotacao.cotacao_endereco = _cot.cotacao_endereco;

    let _cli = new Cliente();
    _cli.cliente_nome = _cot.cotacao_cliente_nome;
    this.cotacao.cotacao_cliente = _cli;

    this.itens = _cot.cotacao_itens;

    let _limite = this.cotacao.dataLimiteRetorno;

    if (_limite) {
      let _m = moment(_limite);

      this.cotacao.cotacao_hora = _m.format('HH:mm');
      this.cotacao.dataLimiteRetorno = _m.toDate();
    } else {
      this.cotacao.cotacao_hora = '';
    }

    this.cotacao_finalizada = _cot.cotacao_finalizada;
    this.resposta_com_pendencias = this.itens.filter(el => el.cotacao_item_pendencias_valores).length > 0;

    this.loadFornecedores(_cot);
    this.loadAvaliacao();
  }

  private loadFornecedores(_cot: CotacaoHelper) {
    this.fornecedoresAll = _cot.cotacao_fornecedores;
    let _lim = 10;
    if (this.cotacao_finalizada === true) {
      _lim = 1;
    }

    this.fornecedoresAll.forEach(el => {

      if (this.cotacao_finalizada === true) {
        if (el.cotacao_fornecedor_colocacao === 1) {
          el.cotacao_fornecedor_icon = "grade";
        } else {
          //el.cotacao_fornecedor_icon = "sentiment_very_dissatisfied";
        }
      } else {
        if (el.cotacao_fornecedor_colocacao === 1) {
          //el.cotacao_fornecedor_icon = "sentiment_very_satisfied";
        } else {
          if (el.cotacao_fornecedor_pendencia === true) {
            el.cotacao_fornecedor_icon = "warning";
          } else {
            //el.cotacao_fornecedor_icon = "sentiment_very_dissatisfied";
          }
        }
      }
    });

    this.showMoreFornecedores = this.fornecedoresAll.length > _lim;
    //this.podeFinalizar = _cot.cotacao_pode_finalizar;

    //somente os 10 primeiros
    if (!this.resposta_com_pendencias) {
      this.fornecedores = this.fornecedoresAll.filter(el => el.cotacao_fornecedor_colocacao <= _lim);
    } else {
      this.fornecedores = new Array<CotacaoFornecedorHelper>();
      for (let i = 0; i < this.fornecedoresAll.length; i++) {
        this.fornecedores.push(this.fornecedoresAll[i]);

        if ((i + 1) > _lim) {
          break;
        }
      }
    }
  }

  private loadAvaliacao() {
    let _hasDataAvaliacao = this.cotacao.dataAvaliacao != null && this.cotacao.dataAvaliacao != undefined
    if (!_hasDataAvaliacao) {
      let _showAvaliacao = this.cotacao.dataLembreteAvaliacao == null || this.cotacao.dataLembreteAvaliacao == undefined;

      if (_showAvaliacao) {
        this.dialogAvaliacao.openDialog();
      }
    } else {
      this._avaliacaoService.findByCotacao(this.cotacao).subscribe(
        ret => {
          let _ava = ret.object as Avaliacao;
          this.avaliacao = _ava;

        },
        response => this.afterResponse(response)
      )
    }
  }

  public openDialogFornecedores() {
    this.dialogFornecedores.openDialog();
  }

  public openDialogEnderecoFornecedor(index) {
    this.cotacaoFornecedorHelper = this.fornecedoresAll[index];

    if (this.cotacao.cotacao_endereco.cotacao_endereco_complemento) {
      this.origin.latitude = this.cotacao.cotacao_endereco.cotacao_endereco_complemento.latitude
      this.origin.longitude = this.cotacao.cotacao_endereco.cotacao_endereco_complemento.longitude;
    }

    if (this.cotacaoFornecedorHelper.cotacao_fornecedor_fornecedor.fornecedor_endereco) {
      this.destination.latitude = this.cotacaoFornecedorHelper.cotacao_fornecedor_fornecedor.fornecedor_endereco.latitude
      this.destination.longitude = this.cotacaoFornecedorHelper.cotacao_fornecedor_fornecedor.fornecedor_endereco.longitude;
    }
    this.showDirections = true;
    this.showMap = true;

    this.dialogEnderecoFornecedor.title = (this.cotacaoFornecedorHelper.cotacao_fornecedor_fornecedor.fornecedor_nome as string);
    this.dialogEnderecoFornecedor.openDialog();

  }

  public closeDialogEndereco() {
    this.showDirections = false;
    this.showMap = false;
    this.dialogEnderecoFornecedor.closeDialog()
  }

  public aceitarCotacao() {
    this._authenticationService.isLogged().subscribe(el => {
      if (el === true) {
        if (this.cotacaoFornecedorHelper.cotacao_fornecedor_pendencia === false) {
          if (confirm(this.translate.instant('COTACAO.CONSULTA.ACEITAR.MENSAGEM'))) {
            let _cf = new CotacaoFornecedor();
            _cf.cotacao_fornecedor_id = this.cotacaoFornecedorHelper.cotacao_fornecedor_id;

            this.consultaRespostaService.aceitarFinalizar(_cf).subscribe(
              ret => {
                this.afterGet(ret);

                let _filtered = this.fornecedoresAll.filter(el => el.cotacao_fornecedor_id == this.cotacaoFornecedorHelper.cotacao_fornecedor_id);
                if (_filtered.length > 0) {
                  this.cotacaoFornecedorHelper = _filtered[0];
                }

                this.dialogPendenciasFornecedor.closeDialog();
                this.dialogVoucher.openDialog();
              },
              response => this.afterResponse(response)
            );
          }
        }

      }
    });
  }

  public openDialogVoucher() {
    let _l = this.fornecedoresAll.filter(el => el.cotacao_fornecedor_colocacao == 1);
    if (_l.length > 0) {
      this.cotacaoFornecedorHelper = _l[0];
      this.dialogVoucher.openDialog();

    }
  }

  public openDialogPendencias(index) {
    this.cotacaoFornecedorHelper = this.fornecedoresAll[index];

    let _valor: String = '';
    if (this.cotacaoFornecedorHelper.cotacao_fornecedor_pendencia === true) {
      _valor = this.cotacaoFornecedorHelper.cotacao_fornecedor_variacao_preco_min + " ~ " +
        this.cotacaoFornecedorHelper.cotacao_fornecedor_variacao_preco_max;
    } else {
      _valor = this.cotacaoFornecedorHelper.cotacao_fornecedor_valor_global_fmt;
    }

    this.dialog_info.fornecedor = this.cotacaoFornecedorHelper.cotacao_fornecedor_fornecedor.fornecedor_nome;
    this.dialog_info.valor = '(' + _valor + ')';

    this.showVoucher = (this.cotacaoFornecedorHelper.cotacao_fornecedor_colocacao === 1 && this.cotacao_finalizada);
    if (this.cotacaoFornecedorHelper.cotacao_fornecedor_itens.length > 0) {
      this.dialogPendenciasFornecedor.openDialog();
    }
  }

  public changeItemValor(cotacaoFornecedorItem, index, event) {
    let checked = event.target.checked;
    let indexItem = this.cotacaoFornecedorHelper.cotacao_fornecedor_itens.indexOf(cotacaoFornecedorItem);

    if (indexItem > -1) {
      this.cotacaoFornecedorHelper.cotacao_fornecedor_itens[indexItem].cotacao_item_fornecedor_valores.forEach(el => {
        el.cotacao_item_fornecedor_valor_selecionado = false;
      });

      this.cotacaoFornecedorHelper.cotacao_fornecedor_itens[indexItem].cotacao_item_fornecedor_valores[index].cotacao_item_fornecedor_valor_selecionado = checked;

      let marcaModelo = this.cotacaoFornecedorHelper.cotacao_fornecedor_itens[indexItem].cotacao_item_fornecedor_valores[index].cotacao_item_fornecedor_valor_marca_modelo;
      let id = this.cotacaoFornecedorHelper.cotacao_fornecedor_itens[indexItem].cotacao_item_fornecedor_valores[index].cotacao_item_fornecedor_valor_id;

      let cotacaoItemFornecedorValorHelper = this.cotacaoFornecedorHelper.cotacao_fornecedor_itens[indexItem].cotacao_item_fornecedor_valores[index];
      this.alterarValorSelecionado(cotacaoItemFornecedorValorHelper);
    }
  }

  public changeItemValorRow(cotacaoFornecedorItem, index) {

    if (!this.cotacao_finalizada) {

      let indexItem = this.cotacaoFornecedorHelper.cotacao_fornecedor_itens.indexOf(cotacaoFornecedorItem);
      let checked = this.cotacaoFornecedorHelper.cotacao_fornecedor_itens[indexItem].cotacao_item_fornecedor_valores[index].cotacao_item_fornecedor_valor_selecionado;

      if (indexItem > -1) {
        this.cotacaoFornecedorHelper.cotacao_fornecedor_itens[indexItem].cotacao_item_fornecedor_valores.forEach(el => {
          el.cotacao_item_fornecedor_valor_selecionado = false;
        });

        this.cotacaoFornecedorHelper.cotacao_fornecedor_itens[indexItem].cotacao_item_fornecedor_valores[index].cotacao_item_fornecedor_valor_selecionado = !checked;

        let indexFornecedor = this.fornecedoresAll.indexOf(this.cotacaoFornecedorHelper);
        if (indexFornecedor > -1) {
          this.fornecedoresAll[indexFornecedor] = this.cotacaoFornecedorHelper;
        }

        let cotacaoItemFornecedorValorHelper = this.cotacaoFornecedorHelper.cotacao_fornecedor_itens[indexItem].cotacao_item_fornecedor_valores[index];
        this.alterarValorSelecionado(cotacaoItemFornecedorValorHelper);
      }
    }
  }

  private alterarValorSelecionado(cotacaoItemFornecedorValorHelper: CotacaoItemFornecedorValorHelper) {
    this._authenticationService.isLogged().subscribe(el => {
      if (el === true) {
        let cotacaoItemFornecedorValor = new CotacaoItemFornecedorValor();
        cotacaoItemFornecedorValor.cotacao_item_fornecedor_valor_id = cotacaoItemFornecedorValorHelper.cotacao_item_fornecedor_valor_id;
        cotacaoItemFornecedorValor.selecionado = cotacaoItemFornecedorValorHelper.cotacao_item_fornecedor_valor_selecionado;

        this.consultaRespostaService.alterarValorSelecionado(cotacaoItemFornecedorValor).subscribe(
          data => {
            this.afterGet(data);

            let _filtered = this.fornecedoresAll.filter(el => el.cotacao_fornecedor_id == this.cotacaoFornecedorHelper.cotacao_fornecedor_id);
            if (_filtered.length > 0) {
              this.cotacaoFornecedorHelper = _filtered[0];

              let _valor: String = '';
              if (this.cotacaoFornecedorHelper.cotacao_fornecedor_pendencia === true) {
                _valor = this.cotacaoFornecedorHelper.cotacao_fornecedor_variacao_preco_min + " - " +
                  this.cotacaoFornecedorHelper.cotacao_fornecedor_variacao_preco_max;
              } else {
                _valor = this.cotacaoFornecedorHelper.cotacao_fornecedor_valor_global_fmt;
              }

              this.dialog_info.fornecedor = this.cotacaoFornecedorHelper.cotacao_fornecedor_fornecedor.fornecedor_nome;
              this.dialog_info.valor = '(' + _valor + ')';

            }
          },
          response => this.afterResponse(response)
        );

      }
    });
  }

  public copiar(): void {
    this._authenticationService.isLogged().subscribe(el => {
      if (el === true) {
        if (confirm(this.translate.instant("GEN.CONFIRM.MESSAGE"))) {
          this._cotacaoService.copiarCotacao(this.cotacao).subscribe(
            data => this.afterCopiar(data),
            response => this.afterResponse(response)
          );
        }
      }
    });
  }

  private afterCopiar(data: any) {
    let _o = data.object;

    let url = this.URL_EDIT + _o.cotacao_id;
    this.router.navigate([url]);
  }

  public toggleDetails(item) {
    item.toggle_details = !item.toggle_details;
  }

  public onChangeRecebeuProduto(event) {
    this.formAvaliacao.controls['motivo'].setValidators(null);
    this.formAvaliacao.controls['rating'].setValidators(null);

    if (this.respostaRecebeuProduto == 'S') {
      this.formAvaliacao.controls['rating'].setValidators([Validators.required]);
    } else if (this.respostaRecebeuProduto == 'D') {
      this.formAvaliacao.controls['motivo'].setValidators([Validators.required]);
    }

    this.formAvaliacao.controls['motivo'].updateValueAndValidity();
    this.formAvaliacao.controls['rating'].updateValueAndValidity();

    this.motivoSelecionado = undefined;
    this.cdr.markForCheck();
  }

  public saveAvaliacao() {
    if (this.respostaRecebeuProduto == 'N') {
      let _l = this.fornecedoresAll.filter(el => el.cotacao_fornecedor_colocacao == 1);
      console.log(_l);
      
    }
  }
}
