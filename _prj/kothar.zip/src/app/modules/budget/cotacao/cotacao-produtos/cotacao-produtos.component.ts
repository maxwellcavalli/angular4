import { Component, OnInit, ViewChild } from '@angular/core';
import { MxBaseController, MxPageFilter } from 'mx-core';
import { ProdutoFilter } from '../../../../shared/helper/produto-filter';
import { BehaviorSubject, Subject } from 'rxjs';
import { Produto } from '../../../../shared/entity/produto';
import { PageEvent } from '@angular/material';
import { Cotacao } from '../../../../shared/entity/cotacao';
import { ProdutoService } from '../../../../service/produto.service';
import { SharedDataService } from '../../../../shared/data/shared-data.service';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { AuthenticationService } from '../../../../service/security/authentication.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ProdutoImagem } from '../../../../shared/entity/produto-imagem';
import { MxGalleryImageContent, MxDialogComponent } from 'mx-components';
import { CotacaoItem } from '../../../../shared/entity/cotacao-item';
import { CotacaoService } from '../../../../service/cotacao.service';

@Component({
  selector: 'app-cotacao-produtos',
  templateUrl: './cotacao-produtos.component.html',
  styleUrls: ['./cotacao-produtos.component.css']
})
export class CotacaoProdutosComponent extends MxBaseController implements OnInit {

  @ViewChild('dialogItemDetail') dialogItemDetail: MxDialogComponent;

  //pesquisa de produtos
  length = 100;
  pageSize = 10;
  pageSizeOptions = [5, 10, 25, 100];

  pageFilter: MxPageFilter = new MxPageFilter();
  produtoFilter: ProdutoFilter = new ProdutoFilter()
  produtos: BehaviorSubject<Array<Produto>> = new BehaviorSubject<Array<Produto>>(null);
  pageEvent: PageEvent;
  mostrarPaginador: Boolean = false;

  title: String = '';

  //nova cotacao
  cotacao = new Cotacao();

  quantidade: Number = 1;
  detalhes: string = '';

  mostrarDetalhesProduto: boolean = false;
  images: BehaviorSubject<Array<MxGalleryImageContent>> = new BehaviorSubject<Array<MxGalleryImageContent>>(null);
  produto: Produto;
  form: FormGroup;

  private _destroy: Subject<Cotacao> = new Subject<Cotacao>();

  constructor(
    private _produtoService: ProdutoService,
    private _sharedDataService: SharedDataService,
    public router: Router,
    public translate: TranslateService,
    private _authenticationService: AuthenticationService,
    private formBuilder: FormBuilder,
    private _cotacaoService: CotacaoService) {

    super(translate);

    this.form = formBuilder.group({
      detalhamento: [null, [Validators.required]],
      quantidade: [null, []]
    });

    this.title = translate.instant('COTACAO.PRODUTO.TITLE');
  }

  private listenCotacao() {
    this._sharedDataService.cotacao
      .takeUntil(this._destroy)
      .subscribe(_cot => {
        if (_cot) {
          this.cotacao = _cot;
        }
      });
  }

  get hasCotacao() {
    return this.cotacao != null && this.cotacao != undefined &&
      this.cotacao.cotacao_id != null && this.cotacao.cotacao_id != undefined;
  }

  ngOnInit() {
    this._authenticationService.isLogged().subscribe(el => {
      if (el === true) {
        this.listenCotacao();
        this.searchProdutos(null);
      }
    });
  }

  ngOnDestroy() {

    this.images.unsubscribe();
    this.produtos.unsubscribe();
    this._destroy.next();
    this._destroy.unsubscribe();
  }

  public page(event: any) {
    this.pageEvent = event;
    this.searchProdutos(event);
  }

  public search() {
    this._authenticationService.isLogged().subscribe(el => {
      if (el === true) {
        this.searchProdutos(null);
      }
    });

  }

  private searchProdutos(pageEvent: PageEvent) {

    this.pageFilter.filterValue = this.produtoFilter.nome;

    if (pageEvent != null) {
      this.pageFilter.page.pageNumber = pageEvent.pageIndex;
      this.pageFilter.page.size = pageEvent.pageSize;
    } else {
      this.pageFilter.page.pageNumber = 0;
      this.pageFilter.page.size = this.pageSize;
    }

    this._produtoService.search(this.pageFilter).subscribe(
      retorno => {
        let _dados = (retorno.object as any).content;

        this.pageFilter.page.totalElements = (retorno.object as any).totalElements;
        this.pageFilter.page.totalPages = (retorno.object as any).totalPages;

        this.mostrarPaginador = this.pageFilter.page.totalPages > 1;

        let _list = new Array<Produto>();

        for (let _d of _dados) {
          if ((_d as Produto).produto_imagem_principal) {
            let _pi = (_d as Produto).produto_imagem_principal;

            this._produtoService.getThumb(_pi.produto_imagem_id).subscribe(
              retImg => {
                (_d as Produto).produto_imagem_principal = (retImg.object as ProdutoImagem);
                (_d as Produto).possui_imagem = true;
              });
          } else {
            (_d as Produto).possui_imagem = false;
          }

          _list.push(_d);
        }

        this.produtos.next(_list);
      },
      response => this.afterResponse(response)
    );
  }

  public openDialogProduto(produto: Produto) {
    if (this.cotacao !== undefined && this.cotacao !== null &&
      this.cotacao.cotacao_id !== undefined && this.cotacao.cotacao_id !== null) {
      this.getProduto(produto.produto_id);
    }
  }

  public adicionarProduto(produto: Produto) {

    this._authenticationService.isLogged().subscribe(el => {
      if (el === true) {
        let exists = this.cotacao.cotacao_item.filter(el => el.cotacao_item_produto.produto_id == this.produto.produto_id).length > 0;
        if (!exists) {
          let _item = new CotacaoItem();
          _item.cotacao_item_produto = this.produto;
          _item.quantidade = this.quantidade;

          this.cotacao.cotacao_item.push(_item);

          this._cotacaoService.update(this.cotacao.cotacao_id, this.cotacao).subscribe(
            ret => {
              let _cot = (ret.object as Cotacao)

              this._sharedDataService.cotacao.next(_cot);
              this.dialogItemDetail.closeDialog();
            },
            response => this.afterResponse(response));
        } else {
          this.dialogItemDetail.closeDialog();
        }

      } else if (el === false){
        this.dialogItemDetail.closeDialog();
      }
    });
  }

  private getProduto(id: Number) {
    this._produtoService.get(id).subscribe(
      ret => {
        let _prod = (ret.object as Produto);
        let _generico = _prod.generico;
        if (_generico) {
          this.form.controls['detalhamento'].setValidators([Validators.required, Validators.minLength(5)]);
        } else {
          this.form.controls['detalhamento'].setValidators(null);
        }

        this.form.controls['detalhamento'].updateValueAndValidity();
        let _imagens = new Array<MxGalleryImageContent>();

        this.mostrarDetalhesProduto = _prod.detalhamento !== undefined && _prod.detalhamento !== null &&
          _prod.detalhamento.replace(new RegExp('\\/', 'g'), '') !== '';

        let count = 0;
        _prod.produto_imagens.forEach(el => {
          this._produtoService.getImagem(el.produto_imagem_id).subscribe(
            img => {
              let _img = (img.object as ProdutoImagem);

              let _imgContent: MxGalleryImageContent = new MxGalleryImageContent();
              _imgContent.content = _img.imagem64;

              _imagens.push(_imgContent);

              count++;

              if (count == _prod.produto_imagens.length) {
                this.images.next(_imagens);
              }
            },
            responseImg => this.afterResponse(responseImg));
        });


        this.quantidade = 1;
        this.detalhes = null;

        this.produto = _prod;
        this.dialogItemDetail.openDialog();
      },
      response => this.afterResponse(response));
  }


}
