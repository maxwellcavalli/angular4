import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { BehaviorSubject } from 'rxjs';
import { MxDataTableComponent } from 'mx-components';
import { TranslateService } from '@ngx-translate/core';
import { Router, ActivatedRoute } from '@angular/router';


import { LoggedCrudController } from '../../../../shared/guard/logged-crud-controller';
import { Cliente } from '../../../../shared/entity/cliente';
import { ClienteService } from '../../../../service/cliente.service';
import { AuthenticationService } from '../../../../service/security/authentication.service';
import { Menu } from '../../../../layout/template/menu';

@Component({
  selector: 'app-cliente-list',
  templateUrl: './cliente-list.component.html',
  styleUrls: ['./cliente-list.component.css']
})
export class ClienteListComponent extends LoggedCrudController<Cliente> {

  URL_LIST: String = "/modules/general/cliente/cliente-list";
  URL_EDIT: String = "/modules/general/cliente/cliente-form/";
  FILTER_KEY: string = "cliente_filter"

  filtroNome: String = '';
  form: FormGroup;

  displayAdd: boolean = false;

  title: String = '';

  rows: BehaviorSubject<any> = new BehaviorSubject<any>(null);
  cols: any;

  @ViewChild('table') _table: MxDataTableComponent;

  ngOnInit() {
    this._authenticationService.isLogged().subscribe(el => {
      if (el === true) {
        super.ngOnInit();
        let _user = this._authenticationService.getUser();
        this.displayAdd = _user.admin;

        this.cols = [];
        this.cols.push({ prop: 'cliente_nome', title: this.translate.instant('GEN.NAME'), sortable: true, selectable: true });
        this.cols.push({ prop: 'cpf_format', title: this.translate.instant('CLIENTE.CPF'), selectable: true, maxWidth: 150 });
        if (_user.admin) {
          this.cols.push({ prop: 'cliente_id', title: this.translate.instant('GEN.ACTION'), maxWidth: 30, sortable: false, cellTemplate: this._table.cellDeleteButton });
        }
      }
    });
  }

  constructor(public _service: ClienteService,
    public translate: TranslateService,
    protected _authenticationService: AuthenticationService,
    public router: Router,
    public route: ActivatedRoute,
    formBuilder: FormBuilder) {

    super(_service, translate, _authenticationService, router, route, false);

    super.reloadFilterL(null);
    this.createDefaultSearchListener();

    this.form = formBuilder.group({
      nome: ['', []],
    });

    this.title = Menu.getHierarquiaByKey('menu_cliente');
  }

  ngOnDestroy() {
    this.rows.unsubscribe();
  }

  onUpdateFilterValue(value: any): void {
    this.filtroNome = value;
  }

  onGetFilterKey(): string {
    return this.FILTER_KEY;
  };

  onPopulateTable(dados: Array<any>) {
    this.rows.next(dados);
  }

  onGetFilterValue(): any {
    if (this.filtroNome) {
      return this.filtroNome;
    } else {
      return super.onGetFilterValue();
    }
  }

  public reset(event) {
    this.oldValue = null;
    this.filtroNome = '';
    this.searchEvent(event);
  }

  public searchEvent(event: any) {
    this._authenticationService.isLogged().subscribe(el => {
      if (el === true) {
        super.searchEvent(event);
      }
    });
  }

  public edit(event) {
    let object = event.row;
    let url = this.URL_EDIT + object.cliente_id;
    this.router.navigate([url]);
  }

  public add(event) {
    this._authenticationService.isLogged().subscribe(el => {
      if (el === true) {
        let url = this.URL_EDIT + "/new";
        this.router.navigate([url]);
      }
    });
  }

}
