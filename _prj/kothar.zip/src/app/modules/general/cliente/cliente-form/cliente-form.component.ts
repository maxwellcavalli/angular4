import { Component, OnInit, ViewChild, TemplateRef, ChangeDetectorRef } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { TranslateService } from '@ngx-translate/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { MxDataTableComponent, MxDialogComponent } from 'mx-components';


import { LoggedCrudController } from '../../../../shared/guard/logged-crud-controller';
import { Cliente } from '../../../../shared/entity/cliente';
import { ClienteEndereco } from '../../../../shared/entity/cliente-endereco';
import { ClienteService } from '../../../../service/cliente.service';
import { AuthenticationService } from '../../../../service/security/authentication.service';
import { MxResponseEntity } from 'mx-core';
import { Menu } from '../../../../layout/template/menu';
import { SharedDataService } from '../../../../shared/data/shared-data.service';

@Component({
  selector: 'app-cliente-form',
  templateUrl: './cliente-form.component.html',
  styleUrls: ['./cliente-form.component.css']
})
export class ClienteFormComponent extends LoggedCrudController<Cliente> implements OnInit {

  URL_LIST: String = "/modules/general/cliente/cliente-list";
  URL_EDIT: String = "/modules/general/cliente/cliente-form/";

  @ViewChild('tableEndereco') _tableEndereco: MxDataTableComponent;
  @ViewChild('dialogEndereco') dialogEndereco: MxDialogComponent;

  //@ViewChild('cellDeleteButton') cellDeleteButton: TemplateRef<any>;
  @ViewChild('cellCheckboxButton') cellCheckboxButton: TemplateRef<any>;

  title: String = '';

  cliente: Cliente = new Cliente();
  form: FormGroup;
  formEndereco: FormGroup;

  //enderecos: BehaviorSubject<Array<ClienteEndereco>> = new BehaviorSubject<Array<ClienteEndereco>>(null);
  clienteEndereco: ClienteEndereco = new ClienteEndereco();
  //_enderecos: Array<any>;

  rows: BehaviorSubject<any> = new BehaviorSubject<any>(null);
  cols: any;

  constructor(public _service: ClienteService,
    public translate: TranslateService,
    protected _authenticationService: AuthenticationService,
    public router: Router,
    public route: ActivatedRoute,
    formBuilder: FormBuilder,
    private cd: ChangeDetectorRef,
    private _sharedDataService: SharedDataService) {

    super(_service, translate, _authenticationService, router, route, false);

    this.form = formBuilder.group({
      nome: ['', [
        Validators.required,
        Validators.minLength(3)
      ]],
      cpf: ['', [
        Validators.required
      ]],
      username: ['', [
        Validators.required,
        Validators.minLength(5)
      ]],
      password: ['', [
        Validators.required,
        Validators.minLength(5)
      ]],
      telefone: ['', []],
      email: ['', [
        Validators.required,
        Validators.minLength(10)
      ]]
    },
    );

    this.formEndereco = formBuilder.group({
      alias: ['', [
        Validators.required,
        Validators.minLength(3)
      ]],
      cep: ['', [
        Validators.required
      ]]
    });

    this.title = Menu.getHierarquiaByKey('menu_cliente', this._sharedDataService.menus.value);
  }

  ngOnInit() {
    this._authenticationService.isLogged().subscribe(el => {
      if (el === true) {
        super.ngOnInit();
        this.createTableEndereco();
      }
    });
  }

  ngOnDestroy() {
    this.rows.unsubscribe();
  }

  private createTableEndereco() {
    this.cols = [
      { prop: 'cliente_endereco_principal', title: this.translate.instant('CLIENTE.ENDERECO.PRINCIPAL'), sortable: false, selectable: false, maxWidth: 50, cellTemplate: this.cellCheckboxButton },
      { prop: 'cliente_endereco_alias', title: this.translate.instant('CLIENTE.ENDERECO.ALIAS'), sortable: false, selectable: true, maxWidth: 120 },
      { prop: 'cliente_endereco_cep.codigoPostal', title: this.translate.instant('CEP.CODIGO.POSTAL'), sortable: false, selectable: true, maxWidth: 100, hideOnMobile: true },
      { prop: 'cliente_endereco_cep.cep_bairro.bairro_cidade.cidade_estado.sigla', title: this.translate.instant('CEP.ESTADO'), sortable: false, selectable: true, maxWidth: 70, hideOnMobile: true },
      { prop: 'cliente_endereco_cep.cep_bairro.bairro_cidade.cidade_nome', title: this.translate.instant('CEP.CIDADE'), sortable: false, selectable: true, hideOnMobile: true },
      { prop: 'cliente_endereco_cep.cep_bairro.bairro_nome', title: this.translate.instant('CEP.BAIRRO'), sortable: false, selectable: false, hideOnMobile: true },
      { prop: 'cliente_endereco_cep.cep_nome', title: this.translate.instant('CEP.RUA'), sortable: false, selectable: true },
      { prop: 'cliente_endereco_complemento.numero', title: this.translate.instant('CLIENTE.ENDERECO.NUMERO'), sortable: false, selectable: true, maxWidth: 100, hideOnMobile: true },
      { prop: 'cliente_endereco_id', title: this.translate.instant('GEN.ACTION'), maxWidth: 30, sortable: false, cellTemplate: this._tableEndereco.cellDeleteButton },
    ];
  }

  public afterGet(data: any): void {
    this.cliente = data.object;

    let _enderecos = this.cliente.cliente_enderecos;

    let index = 0;
    for (let x of _enderecos) {
      (x as any).$$index = index++;
    }

    this.rows.next(_enderecos);

    this.form.get('username').disable({ onlySelf: this.editing });
    this.form.get('password').setValidators(null);
    this.form.get('password').updateValueAndValidity();
  }

  public save(): void {
    this._authenticationService.isLogged().subscribe(el => {
      if (el === true) {
        this.cliente.cliente_enderecos = this.rows.value;
        super.saveOrUpdate(this.cliente.cliente_id, this.cliente);

      }
    });
  }

  public afterSave(responseEntity: MxResponseEntity): void {
    super.afterSave(responseEntity);
    let _o = (responseEntity.object as any);

    this.afterGet(responseEntity);

    let url = this.URL_EDIT + _o.cliente_id;
    this.router.navigate([url]);
  }

  public afterUpdate(data) {
    super.afterUpdate(data);
    this.afterGet(data);
  }

  public alterarEndereco(event: any): void {
    let idx = event.row.$$index;
    let _enderecos = this.rows.value;

    let index = _enderecos.findIndex(_el => (_el as any).$$index === idx);
    if (index > -1) {
      this.clienteEndereco = _enderecos[index];
    }

    this.dialogEndereco.openDialog();
  }

  public deleteEndereco(event: any): void {
    let value = event.value;
    let row = event.row;

    if (confirm(this.translate.instant("GEN.DELETE.MESSAGE"))) {
      let _enderecos = this.rows.value;

      let idx = row.$$index;
      let index = _enderecos.findIndex(_el => (_el as any).$$index === idx);
      if (index > -1) {
        _enderecos.splice(index, 1);
        this.rows.next(_enderecos);
      }
    }
  }

  public adicionarEndereco(): void {
    this.clienteEndereco = new ClienteEndereco();
    this.clienteEndereco.cliente_endereco_cep = undefined;

    let _enderecos = this.rows.value;

    if (_enderecos.length == 0) {
      this.clienteEndereco.cliente_endereco_principal = true;
    } else {
      this.clienteEndereco.cliente_endereco_principal = false;
    }

    this.cd.detectChanges();
    this.dialogEndereco.openDialog();
  }

  public salvarEndereco(): void {
    this.clienteEndereco.cliente_endereco_complemento = this.clienteEndereco.cliente_endereco_cep.endereco_complemento;
    let $$index = (this.clienteEndereco as any).$$index;
    let _enderecos = this.rows.value;

    if ($$index) {
      let index = _enderecos.findIndex(_el => (_el as any).$$index === $$index);
      _enderecos[index] = this.clienteEndereco;
    } else {
      (this.clienteEndereco as any).$$index = _enderecos.length + 1;
      _enderecos.push(this.clienteEndereco);

      this.clienteEndereco = new ClienteEndereco();
    }

    this.rows.next(_enderecos);
    this.cd.detectChanges();
    this.dialogEndereco.closeDialog();
  }

  public selection(row: any, event: any, checked: boolean): void {
    let _enderecos = this.rows.value;

    let idx = row.$$index;
    let index = _enderecos.findIndex(_el => (_el as any).$$index === idx);
    if (index > -1) {
      _enderecos.forEach(_el => _el.cliente_endereco_principal = false);
      _enderecos[index].cliente_endereco_principal = checked;

      this.rows.next(_enderecos);
    }
  }

  getData(row) {
    return row.cliente_endereco_principal;
  }

}
