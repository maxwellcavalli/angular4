import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ClienteListComponent } from './cliente-list/cliente-list.component';
import { ClienteFormComponent } from './cliente-form/cliente-form.component';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../../../shared/shared.module';
import { PainelCepModule } from '../../../shared/components/painel-cep/painel-cep.module';

const routes: Routes = [
  {
    path: '',
    children: [
      { path: 'cliente-list', component: ClienteListComponent },
      { path: 'cliente-form/new', component: ClienteFormComponent },
      { path: 'cliente-form/:id', component: ClienteFormComponent }
    ]
  }
];


@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    SharedModule,
    PainelCepModule
  ],
  declarations: [ClienteListComponent, ClienteFormComponent]
})
export class ClienteModule { }
