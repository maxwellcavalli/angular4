import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    children: [
      { path: 'categoria-produto', loadChildren: './categoria-produto/categoria-produto.module#CategoriaProdutoModule'},
      { path: 'grupo-produto', loadChildren: './grupo-produto/grupo-produto.module#GrupoProdutoModule'},
      { path: 'produto', loadChildren: './produto/produto.module#ProdutoModule'},

      { path: 'estado', loadChildren: './estado/estado.module#EstadoModule'},
      { path: 'cidade', loadChildren: './cidade/cidade.module#CidadeModule'},
      { path: 'bairro', loadChildren: './bairro/bairro.module#BairroModule'},
      { path: 'cep', loadChildren: './cep/cep.module#CepModule'},

      { path: 'cliente', loadChildren: './cliente/cliente.module#ClienteModule'},
      { path: 'fornecedor', loadChildren: './fornecedor/fornecedor.module#FornecedorModule'}

    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class GeneralRoutingModule { }
