import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { BehaviorSubject } from 'rxjs';
import { MxDataTableComponent } from 'mx-components';
import { TranslateService } from '@ngx-translate/core';
import { Router, ActivatedRoute } from '@angular/router';

import { AuthenticationService } from '../../../../service/security/authentication.service';
import { ProdutoService } from '../../../../service/produto.service';
import { Produto } from '../../../../shared/entity/produto';
import { LoggedCrudController } from '../../../../shared/guard/logged-crud-controller';
import { Menu } from '../../../../layout/template/menu';
import { SharedDataService } from '../../../../shared/data/shared-data.service';

@Component({
  selector: 'app-produto-list',
  templateUrl: './produto-list.component.html',
  styleUrls: ['./produto-list.component.css']
})
export class ProdutoListComponent extends LoggedCrudController<Produto> {

  URL_LIST: String = "/modules/general/produto/produto-list";
  URL_EDIT: String = "/modules/general/produto/produto-form/";

  FILTER_KEY: string = "produto_filter"

  filtroNome: String = '';
  form: FormGroup;

  title: String = '';

  rows: BehaviorSubject<any> = new BehaviorSubject<any>(null);
  cols: any;

  @ViewChild('table') _table: MxDataTableComponent;

  ngOnInit() {

    this._authenticationService.isLogged().subscribe(el => {
      if (el === true) {
        super.ngOnInit();

        this.cols = [
          { prop: 'produto_nome', title: this.translate.instant('GEN.NAME'), sortable: true, selectable: true },
          { prop: 'produto_grupo_produto.grupo_produto_nome', title: this.translate.instant('PRODUCT.GROUP'), sortable: true, selectable: true, hideOnMobile: true },
          { prop: 'generico', title: this.translate.instant('PRODUCT.GENERIC'), sortable: false, selectable: true, maxWidth: 70, cellTemplate: this._table.cellCheckbox, hideOnMobile: true },
          { prop: 'produto_situacao', title: this.translate.instant('PRODUCT.STATUS'), sortable: false, maxWidth: 130, hideOnMobile: true },
          { prop: 'produto_id', title: this.translate.instant('GEN.ACTION'), maxWidth: 30, sortable: false, cellTemplate: this._table.cellDeleteButton }
        ];

      }
    });
  }

  ngOnDestroy() {
    this.rows.unsubscribe();
  }

  constructor(public _service: ProdutoService,
    public translate: TranslateService,
    protected _authenticationService: AuthenticationService,
    public router: Router,
    public route: ActivatedRoute,
    formBuilder: FormBuilder,
    private _sharedDataService: SharedDataService) {

    super(_service, translate, _authenticationService, router, route, false);
    super.reloadFilterL(null);
    this.createDefaultSearchListener();

    this.form = formBuilder.group({
      nome: ['', []],
    });

    this.title = Menu.getHierarquiaByKey('menu_produto', this._sharedDataService.menus.value);
  }

  onUpdateFilterValue(value: any): void {
    this.filtroNome = value;
  }

  onGetFilterKey(): string {
    return this.FILTER_KEY;
  };

  onPopulateTable(dados: Array<any>) {
    this.rows.next(dados);
  }

  onGetFilterValue(): any {
    if (this.filtroNome) {
      return this.filtroNome;
    } else {
      return super.onGetFilterValue();
    }
  }

  public edit(event) {
    let object = event.row;
    let url = this.URL_EDIT + object.produto_id;
    this.router.navigate([url]);
  }

  reset(event) {
    this.oldValue = null
    this.filtroNome = '';
    super.searchEvent(event);
  }

  public searchEvent(event: any) {
    this._authenticationService.isLogged().subscribe(el => {
      if (el === true) {
        super.searchEvent(event);
      }
    });
  }

  public add(event) {
    this._authenticationService.isLogged().subscribe(el => {
      if (el === true) {
        let url = this.URL_EDIT + "/new";
        this.router.navigate([url]);
      }
    });
  }

}
