import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProdutoListComponent } from './produto-list/produto-list.component';
import { ProdutoFormComponent } from './produto-form/produto-form.component';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../../../shared/shared.module';
import { AutoCompleteModule } from '../../../shared/components/auto-complete/auto-complete.module';

const routes: Routes = [
  {
    path: '',
    children: [
      { path: 'produto-list', component: ProdutoListComponent },
      { path: 'produto-form/new', component: ProdutoFormComponent },
      { path: 'produto-form/:id', component: ProdutoFormComponent }
    ]
  }
];


@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    SharedModule,
    AutoCompleteModule
  ],
  declarations: [ProdutoListComponent, ProdutoFormComponent]
})
export class ProdutoModule { }
