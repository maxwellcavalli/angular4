import { Component, OnInit, ViewChild } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import { Router, ActivatedRoute } from '@angular/router';
import { MxResponseEntity } from 'mx-core';
import { MxDialogComponent } from 'mx-components';


import { LoggedCrudController } from '../../../../shared/guard/logged-crud-controller';
import { Produto } from '../../../../shared/entity/produto';
import { ProdutoImagem } from '../../../../shared/entity/produto-imagem';
import { ProdutoService } from '../../../../service/produto.service';
import { AuthenticationService } from '../../../../service/security/authentication.service';
import { CategoriaService } from '../../../../service/categoria.service';
import { Menu } from '../../../../layout/template/menu';

@Component({
  selector: 'app-produto-form',
  templateUrl: './produto-form.component.html',
  styleUrls: ['./produto-form.component.css']
})
export class ProdutoFormComponent extends LoggedCrudController<Produto> implements OnInit {

  @ViewChild('dialogImagem') dialogImagem: MxDialogComponent;

  URL_LIST: String = "/modules/general/produto/produto-list";
  URL_EDIT: String = "/modules/general/produto/produto-form/";

  produto: Produto = new Produto();
  produto_imagens: BehaviorSubject<Array<ProdutoImagem>> = new BehaviorSubject<Array<ProdutoImagem>>(null);
  produtoImagem: ProdutoImagem;

  form: FormGroup;

  mostrarImagens: boolean = true;
  mostrarDetalhes: boolean = false;

  title: String = '';

  constructor(public _service: ProdutoService,
    public translate: TranslateService,
    public router: Router,
    public route: ActivatedRoute,
    private formBuilder: FormBuilder,
    protected _authenticationService: AuthenticationService,
    public _categoriaService: CategoriaService) {

    super(_service, translate, _authenticationService, router, route, true);

    this.createServerObject = true;

    this.form = formBuilder.group({
      nome: ['', [
        Validators.required,
        Validators.minLength(3)
      ]],
      group: ['', [
        Validators.required
      ]],
      generico: ['', []],
      detalhamento: [{ value: '' }, []],
      status: [{ value: '', disabled: true }, []]
    });

    this.title = Menu.getHierarquiaByKey('menu_produto');
  }

  ngOnInit() {
    this._authenticationService.isLogged().subscribe(el => {
      if (el === true) {
        super.ngOnInit();
      }
    });
  }

  ngOnDestroy() {
    this.produto_imagens.unsubscribe();
  }

  get urlToOrigin() {
    let returnUrl = this.route.snapshot.queryParams["returnUrl"];
    if (returnUrl === null || returnUrl == undefined) {
      returnUrl = this.URL_LIST;
    }

    return returnUrl;
  }

  protected getDomain(id): void {
    this._service.getProdutoComplete(id).subscribe(
      data => {
        this.afterGet(data);
      },
      response => this.afterResponse(response));
  }

  verifyDetails(event) {

    if (event.checked) {
      this.form.controls['detalhamento'].disable({ onlySelf: true });
      this.mostrarImagens = false;
    } else {
      this.form.controls['detalhamento'].enable({ onlySelf: true });
      this.mostrarImagens = true;
    }
  }

  public afterGet(data: any) {
    this.produto = data.object;

    let _arquivos = this.produto.produto_imagens;
    let _tmp = new Array<ProdutoImagem>();

    if (_arquivos != undefined && _arquivos != null) {
      _arquivos.forEach(el => {
        this._service.getImagem(el.produto_imagem_id).subscribe(ret => {
          let obj = ret.object as ProdutoImagem;

          _tmp.push(obj);
        });

        this.produto_imagens.next(_tmp);
      });
    }

    this.mostrarDetalhes = !this.produto.generico && (this.produto.detalhamento !== '' && this.produto.detalhamento != null);

    if (this.editing) {
      if (this.produto.generico) {
        this.form.controls['detalhamento'].disable({ onlySelf: true });
        this.mostrarImagens = false;
      } else {
        this.form.controls['detalhamento'].enable({ onlySelf: true });
        this.mostrarImagens = true;
      }
    }
  }

  public save() {
    this._authenticationService.isLogged().subscribe(el => {
      if (el === true) {
        this.produto.produto_imagens = this.produto_imagens.value;
        super.saveOrUpdate(this.produto.produto_id, this.produto);

      }
    });
  }

  public afterUpdate(data: MxResponseEntity) {
    super.afterUpdate(data);

    this.afterGet(data);
  }

  public afterSave(responseEntity: MxResponseEntity) {
    super.afterSave(responseEntity);
    let _o = (responseEntity.object as any);
    this.afterGet(responseEntity);

    let url = this.URL_EDIT + _o.produto_id;
    this.router.navigate([url]);
  }

  onFinishUpload(files: Array<any>) {
    let _arquivos = this.produto_imagens.value;

    if (_arquivos === undefined || _arquivos === null) {
      _arquivos = new Array<ProdutoImagem>();
    }

    for (let i = 0; i < files.length; i++) {
      let obj = files[i];

      let _pi = new ProdutoImagem();
      _pi.produto_imagem_nome = obj.name;
      _pi.imagem64 = obj.content;
      _pi.produto_imagem_principal = false;

      _arquivos.push(_pi);
    }

    this.produto_imagens.next(_arquivos);
  }

  public changePrincipal(i) {
    let _arquivos = this.produto_imagens.value;
    let _sel = _arquivos[i].produto_imagem_principal;

    _arquivos.forEach(el => el.produto_imagem_principal = false);
    _arquivos[i].produto_imagem_principal = !_sel;

    this.produto_imagens.next(_arquivos);
  }

  public openDialogImagem(i) {
    let _arquivos = this.produto_imagens.value;
    this.produtoImagem = _arquivos[i];
    this.dialogImagem.openDialog();
  }

  public deleteImagem(i) {
    if (confirm(this.translate.instant('GEN.CONFIRM.MESSAGE'))) {
      let _arquivos = this.produto_imagens.value;
      _arquivos.splice(i, 1);
      this.produto_imagens.next(_arquivos);
    }
  }

  public ativarImagem(i) {
    let _arquivos = this.produto_imagens.value;
    let _pi = _arquivos[i];

    _pi.ativo = true;

    _arquivos[i] = _pi;

    this.produto_imagens.next(_arquivos);
  }

  public desativarImagem(i) {
    let _arquivos = this.produto_imagens.value;
    let _pi = _arquivos[i];

    _pi.ativo = false;

    _arquivos[i] = _pi;

    this.produto_imagens.next(_arquivos);
  }

}
