import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';

import { Router, ActivatedRoute } from '@angular/router';
import { MxDataTableComponent } from 'mx-components';
import { BehaviorSubject } from 'rxjs';


import { CategoriaService } from '../../../../service/categoria.service';
import { Categoria } from '../../../../shared/entity/categoria';
import { LoggedCrudController } from '../../../../shared/guard/logged-crud-controller';
import { AuthenticationService } from '../../../../service/security/authentication.service';
import { Menu } from '../../../../layout/template/menu';

@Component({
  selector: 'app-categoria-produto-list',
  templateUrl: './categoria-produto-list.component.html',
  styleUrls: ['./categoria-produto-list.component.css']
})
export class CategoriaProdutoListComponent extends LoggedCrudController<Categoria> {

  URL_LIST: String = "/modules/general/categoria-produto/categoria-produto-list";
  URL_EDIT: String = "/modules/general/categoria-produto/categoria-produto-form/";

  FILTER_KEY: string = "categoria_filter"

  filtroNome: String = '';
  form: FormGroup;
  title: String = '';

  rows: BehaviorSubject<any> = new BehaviorSubject<any>(null);
  cols: any;

  @ViewChild('table') _table: MxDataTableComponent;

  constructor(public _service: CategoriaService,
    public translate: TranslateService,
    protected _authenticationService: AuthenticationService,
    public router: Router,
    public route: ActivatedRoute,
    formBuilder: FormBuilder) {

    super(_service, translate, _authenticationService, router, route, false);
    super.reloadFilterL(null);

    this.form = formBuilder.group({
      nome: ['', []],
    });

    this.createDefaultSearchListener();

    this.title = Menu.getHierarquiaByKey('menu_categoria');
  }

  onUpdateFilterValue(value: any): void {
    this.filtroNome = value;
  }

  onGetFilterKey(): string {
    return this.FILTER_KEY;
  };

  onPopulateTable(dados: Array<any>) {
    this.rows.next(dados);
  }

  onGetFilterValue(): any {
    if (this.filtroNome) {
      return this.filtroNome;
    } else {
      return super.onGetFilterValue();
    }
  }

  ngOnInit() {
    this._authenticationService.isLogged().subscribe(el => {
      if (el === true) {
        super.ngOnInit();

        this.cols = [
          { prop: 'categoria_nome', title: this.translate.instant('GEN.NAME'), sortable: true, selectable: true },
          { prop: 'categoria_id', title: this.translate.instant('GEN.ACTION'), maxWidth: 30, sortable: false, cellTemplate: this._table.cellDeleteButton }
        ]

      }
    });
  }

  ngOnDestroy() {
    this.rows.unsubscribe();
  }

  public reset(event) {
    this.oldValue = null;
    this.filtroNome = '';
    this.searchEvent(event);
  }

  public searchEvent(event: any) {
    this._authenticationService.isLogged().subscribe(el => {
      if (el === true) {
        super.searchEvent(event);
      }
    });
  }

  public edit(event) {
    let object = event.row;
    let url = this.URL_EDIT + object.categoria_id;
    this.router.navigate([url]);
  }

  public add(event) {
    this._authenticationService.isLogged().subscribe(el => {
      if (el === true) {
        let url = this.URL_EDIT + "/new";
        this.router.navigate([url]);

      }
    });
  }
}
