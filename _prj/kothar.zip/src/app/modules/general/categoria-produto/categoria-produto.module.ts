import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';

import { CategoriaProdutoListComponent } from './categoria-produto-list/categoria-produto-list.component';
import { CategoriaProdutoFormComponent } from './categoria-produto-form/categoria-produto-form.component';
import { SharedModule } from '../../../shared/shared.module';

const routes: Routes = [
  {
    path: '',
    children: [
      { path: 'categoria-produto-list', component: CategoriaProdutoListComponent },
      { path: 'categoria-produto-form/new', component: CategoriaProdutoFormComponent },
      { path: 'categoria-produto-form/:id', component: CategoriaProdutoFormComponent }
    ]
  }
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    SharedModule
  ],
  declarations: [CategoriaProdutoListComponent, CategoriaProdutoFormComponent]
})
export class CategoriaProdutoModule { }
