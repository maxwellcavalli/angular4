import { Component, OnInit } from '@angular/core';
import { MxResponseEntity } from 'mx-core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import { Router, ActivatedRoute } from '@angular/router';

import { Categoria } from '../../../../shared/entity/categoria';
import { CategoriaService } from '../../../../service/categoria.service';
import { AuthenticationService } from '../../../../service/security/authentication.service';
import { LoggedCrudController } from '../../../../shared/guard/logged-crud-controller';
import { Menu } from '../../../../layout/template/menu';
import { SharedDataService } from '../../../../shared/data/shared-data.service';

@Component({
  selector: 'app-categoria-produto-form',
  templateUrl: './categoria-produto-form.component.html',
  styleUrls: ['./categoria-produto-form.component.css']
})
export class CategoriaProdutoFormComponent extends LoggedCrudController<Categoria> implements OnInit {

  categoria: Categoria = new Categoria();
  form: FormGroup;
  title: String = '';

  URL_LIST: String = "/modules/general/categoria-produto/categoria-produto-list";
  URL_EDIT: String = "/modules/general/categoria-produto/categoria-produto-form/";

  constructor(public _service: CategoriaService,
    public translate: TranslateService,
    protected _authenticationService: AuthenticationService,
    public router: Router,
    public route: ActivatedRoute,
    formBuilder: FormBuilder,
    private _sharedDataService: SharedDataService) {

    super(_service, translate, _authenticationService, router, route, false);

    this.form = formBuilder.group({
      nome: ['', [
        Validators.required,
        Validators.minLength(3)
      ]]
    });

    this.title = Menu.getHierarquiaByKey('menu_categoria', this._sharedDataService.menus.value);
  }

  ngOnInit() {
    this._authenticationService.isLogged().subscribe(el => {
      if (el === true) {
        super.ngOnInit();
      }
    });
  }

  public afterGet(data: any) {
    this.categoria = data.object;
  }

  public save() {
    this._authenticationService.isLogged().subscribe(el => {
      if (el === true) {
        super.saveOrUpdate(this.categoria.categoria_id, this.categoria);

      }
    });
  }

  public afterSave(responseEntity: MxResponseEntity) {
    super.afterSave(responseEntity);
    let _o = (responseEntity.object as any);

    let url = this.URL_EDIT + _o.categoria_id;
    this.router.navigate([url]);
  }

  getImagem(readerEvt, midia) {
    let file = readerEvt.target.files[0];
    if (file) {
      var reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = function () {
        midia.imagem64 = btoa(reader.result);
      };
      reader.onerror = function (error) {
        console.log('Erro ao ler a imagem : ', error);
      };
    } else {
      midia.imagem64 = null;
    }
  }
}
