import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { BehaviorSubject } from 'rxjs';
import { MxDataTableComponent } from 'mx-components';
import { TranslateService } from '@ngx-translate/core';
import { Router, ActivatedRoute } from '@angular/router';

import { AuthenticationService } from '../../../../service/security/authentication.service';
import { BairroService } from '../../../../service/bairro.service';
import { LoggedCrudController } from '../../../../shared/guard/logged-crud-controller';
import { Bairro } from '../../../../shared/entity/bairro';
import { Menu } from '../../../../layout/template/menu';
import { SharedDataService } from '../../../../shared/data/shared-data.service';

@Component({
  selector: 'app-bairro-list',
  templateUrl: './bairro-list.component.html',
  styleUrls: ['./bairro-list.component.css']
})
export class BairroListComponent extends LoggedCrudController<Bairro> {

  URL_LIST: String = "/modules/general/bairro/bairro-list";
  URL_EDIT: String = "/modules/general/bairro/bairro-form/";

  FILTER_KEY: string = "bairro_filter"

  form: FormGroup;

  filtroBairro: String = '';
  filtroCidade: String = '';

  title: String = '';

  rows: BehaviorSubject<any> = new BehaviorSubject<any>(null);
  cols: any;

  @ViewChild('table') _table: MxDataTableComponent;

  ngOnInit() {
    this._authenticationService.isLogged().subscribe(el => {
      if (el === true) {

        super.ngOnInit();

        this.cols = [
          { prop: 'bairro_cidade.cidade_estado.sigla', title: this.translate.instant('BAIRRO.ESTADO'), sortable: true, selectable: true, maxWidth: 70, hideOnMobile: true },
          { prop: 'bairro_cidade.cidade_nome', title: this.translate.instant('BAIRRO.CIDADE'), sortable: true, selectable: true },
          { prop: 'bairro_nome', title: this.translate.instant('GEN.NAME'), sortable: true, selectable: true },
          { prop: 'bairro_id', title: this.translate.instant('GEN.ACTION'), maxWidth: 30, sortable: false, cellTemplate: this._table.cellDeleteButton }
        ];

      }
    });
  }

  ngOnDestroy() {
    this.rows.unsubscribe();
  }

  constructor(public _service: BairroService,
    public translate: TranslateService,
    protected _authenticationService: AuthenticationService,
    public router: Router,
    public route: ActivatedRoute,
    formBuilder: FormBuilder,
    private _sharedDataService: SharedDataService) {

    super(_service, translate, _authenticationService, router, route, false);
    super.reloadFilterL(null);

    this.pageFilterN.subscribe(_filter => {
      this.isFilterUpdatedP();

      _filter.filterValue = this.onGetFilterValue();
      this.onSaveFilter();

      this._service.searchComplex(_filter).subscribe(
        _ret => {
          this.afterSearch(_ret);
          let _dados = (_ret.object as any).content;

          this.onPopulateTable(_dados as Array<any>)
        },
        response => {
          this.afterResponse(response);
        });
    });

    this.form = formBuilder.group({
      bairro: ['', []],
      cidade: ['', []]
    });

    this.title = Menu.getHierarquiaByKey('menu_bairro', this._sharedDataService.menus.value);
  }

  onUpdateFilterValue(value: any): void {
    this.filtroBairro = value.bairro;
    this.filtroCidade = value.cidade;
  }

  onGetFilterKey(): string {
    return this.FILTER_KEY;
  };

  onPopulateTable(dados: Array<any>) {
    this.rows.next(dados);
  }

  onGetFilterValue(): any {
    let filterValue = {
      bairro: this.filtroBairro,
      cidade: this.filtroCidade
    }

    return filterValue;
  }

  public reset(event) {
    this.oldValue = null;

    this.filtroBairro = '';
    this.filtroCidade = '';
    this.searchEvent(event);
  }

  public searchEvent(event: any) {
    this._authenticationService.isLogged().subscribe(el => {
      if (el === true) {
        super.searchEvent(event);
      }
    });
  }

  public edit(event) {
    let object = event.row;
    let url = this.URL_EDIT + object.bairro_id;
    this.router.navigate([url]);
  }

  public add(event) {
    this._authenticationService.isLogged().subscribe(el => {
      if (el === true) {
        let url = this.URL_EDIT + "/new";
        this.router.navigate([url]);

      }
    });
  }

}