import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BairroFormComponent } from './bairro-form/bairro-form.component';
import { BairroListComponent } from './bairro-list/bairro-list.component';
import { RouterModule, Routes } from '@angular/router';

import { SharedModule } from '../../../shared/shared.module';
import { AutoCompleteModule } from '../../../shared/components/auto-complete/auto-complete.module';

const routes: Routes = [
  {
    path: '',
    children: [
      { path: 'bairro-list', component: BairroListComponent },
      { path: 'bairro-form/new', component: BairroFormComponent },
      { path: 'bairro-form/:id', component: BairroFormComponent }
    ]
  }
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    SharedModule,
    AutoCompleteModule
  ],
  declarations: [BairroFormComponent, BairroListComponent]
})
export class BairroModule { }
