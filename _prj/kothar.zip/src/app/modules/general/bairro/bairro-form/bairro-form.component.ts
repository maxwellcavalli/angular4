import { Component, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { MxResponseEntity } from 'mx-core';


import { BairroService } from '../../../../service/bairro.service';
import { AuthenticationService } from '../../../../service/security/authentication.service';
import { LoggedCrudController } from '../../../../shared/guard/logged-crud-controller';
import { Bairro } from '../../../../shared/entity/bairro';
import { Menu } from '../../../../layout/template/menu';
import { SharedDataService } from '../../../../shared/data/shared-data.service';

@Component({
  selector: 'app-bairro-form',
  templateUrl: './bairro-form.component.html',
  styleUrls: ['./bairro-form.component.css']
})
export class BairroFormComponent extends LoggedCrudController<Bairro> implements OnInit {

  bairro: Bairro = new Bairro();
  form: FormGroup;

  URL_LIST: String = "/modules/general/bairro/bairro-list";
  URL_EDIT: String = "/modules/general/bairro/bairro-form/";

  title: String = '';

  constructor(public _service: BairroService,
    public translate: TranslateService,
    protected _authenticationService: AuthenticationService,
    public router: Router,
    public route: ActivatedRoute,
    formBuilder: FormBuilder,
    private _sharedDataService: SharedDataService) {

    super(_service, translate, _authenticationService, router, route, false);

    this.form = formBuilder.group({
      nome: ['', [
        Validators.required,
        Validators.minLength(3),
      ]],
      cidade: ['', [
        Validators.required
      ]]
    });

    this.title = Menu.getHierarquiaByKey('menu_bairro', this._sharedDataService.menus.value);
  }

  ngOnInit() {
    this._authenticationService.isLogged().subscribe(el => {
      if (el === true) {
        super.ngOnInit();
      }
    });
  }

  public afterGet(data: any) {
    this.bairro = data.object;
  }

  public save() {
    this._authenticationService.isLogged().subscribe(el => {
      if (el === true) {
        super.saveOrUpdate(this.bairro.bairro_id, this.bairro);
      }
    });
  }

  public afterSave(responseEntity: MxResponseEntity) {
    super.afterSave(responseEntity);
    let _o = (responseEntity.object as any);

    let url = this.URL_EDIT + _o.bairro_id;
    this.router.navigate([url]);
  }

}
