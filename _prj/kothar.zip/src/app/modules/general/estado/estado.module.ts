import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';

import { EstadoListComponent } from './estado-list/estado-list.component';
import { EstadoFormComponent } from './estado-form/estado-form.component';
import { SharedModule } from '../../../shared/shared.module';

const routes: Routes = [
  {
    path: '',
    children: [
      { path: 'estado-list', component: EstadoListComponent },
      { path: 'estado-form/new', component: EstadoFormComponent },
      { path: 'estado-form/:id', component: EstadoFormComponent }
    ]
  }
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    SharedModule

  ],
  declarations: [EstadoListComponent, EstadoFormComponent]
})
export class EstadoModule { }
