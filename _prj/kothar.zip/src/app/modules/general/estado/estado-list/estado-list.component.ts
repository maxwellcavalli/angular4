import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { BehaviorSubject } from 'rxjs';
import { MxDataTableComponent } from 'mx-components';
import { TranslateService } from '@ngx-translate/core';
import { ActivatedRoute, Router } from '@angular/router';

import { LoggedCrudController } from '../../../../shared/guard/logged-crud-controller';
import { Estado } from '../../../../shared/entity/estado';
import { EstadoService } from '../../../../service/estado.service';
import { AuthenticationService } from '../../../../service/security/authentication.service';
import { Menu } from '../../../../layout/template/menu';

@Component({
  selector: 'app-estado-list',
  templateUrl: './estado-list.component.html',
  styleUrls: ['./estado-list.component.css']
})
export class EstadoListComponent extends LoggedCrudController<Estado> {

  URL_LIST: String = "/modules/general/estado/estado-list";
  URL_EDIT: String = "/modules/general/estado/estado-form/";

  FILTER_KEY: string = "estado_filter"

  filtroNome: String = '';
  form: FormGroup;

  title: String = '';

  rows: BehaviorSubject<any> = new BehaviorSubject<any>(null);
  cols: any;

  @ViewChild('table') _table: MxDataTableComponent;

  constructor(public _service: EstadoService,
    public translate: TranslateService,
    protected _authenticationService: AuthenticationService,
    public router: Router,
    public route: ActivatedRoute,
    formBuilder: FormBuilder) {

    super(_service, translate, _authenticationService, router, route, false);

    super.reloadFilterL(null);
    this.createDefaultSearchListener();

    this.form = formBuilder.group({
      nome: ['', []],
    });

    this.title = Menu.getHierarquiaByKey('menu_estado');
  }

  ngOnInit() {
    this._authenticationService.isLogged().subscribe(el => {
      if (el === true) {
        super.ngOnInit();

        this.cols = [
          { prop: 'sigla', title: this.translate.instant('ESTADO.SIGLA'), sortable: true, selectable: true, maxWidth: 70 },
          { prop: 'estado_nome', title: this.translate.instant('GEN.NAME'), sortable: true, selectable: true },
          { prop: 'estado_id', title: this.translate.instant('GEN.ACTION'), maxWidth: 30, sortable: false, cellTemplate: this._table.cellDeleteButton }
        ];
      }
    });
  }

  ngOnDestroy() {
    this.rows.unsubscribe();
  }

  onUpdateFilterValue(value: any): void {
    this.filtroNome = value;
  }

  onGetFilterKey(): string {
    return this.FILTER_KEY;
  };

  onPopulateTable(dados: Array<any>) {
    this.rows.next(dados);
  }

  onGetFilterValue(): any {
    if (this.filtroNome) {
      return this.filtroNome;
    } else {
      return super.onGetFilterValue();
    }
  }

  public reset(event) {
    this.oldValue = null;
    this.filtroNome = '';
    this.searchEvent(event);
  }

  public searchEvent(event: any) {
    this._authenticationService.isLogged().subscribe(el => {
      if (el === true) {
        super.searchEvent(event);
      }
    });
  }

  public edit(event) {
    let object = event.row;
    let url = this.URL_EDIT + object.estado_id;
    this.router.navigate([url]);
  }

  public add(event) {
    this._authenticationService.isLogged().subscribe(el => {
      if (el === true) {
        let url = this.URL_EDIT + "/new";
        this.router.navigate([url]);
      }
    });
  }

}
