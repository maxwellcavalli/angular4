import { Component, OnInit } from '@angular/core';
import { MxResponseEntity } from 'mx-core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import { Router, ActivatedRoute } from '@angular/router';

import { AuthenticationService } from '../../../../service/security/authentication.service';
import { EstadoService } from '../../../../service/estado.service';
import { Estado } from '../../../../shared/entity/estado';
import { LoggedCrudController } from '../../../../shared/guard/logged-crud-controller';
import { Menu } from '../../../../layout/template/menu';

@Component({
  selector: 'app-estado-form',
  templateUrl: './estado-form.component.html',
  styleUrls: ['./estado-form.component.css']
})
export class EstadoFormComponent extends LoggedCrudController<Estado> implements OnInit {

  URL_LIST: String = "/modules/general/estado/estado-list";
  URL_EDIT: String = "/modules/general/estado/estado-form/";

  estado: Estado = new Estado();
  form: FormGroup;

  title: String = '';

  constructor(public _service: EstadoService,
    public translate: TranslateService,
    protected _authenticationService: AuthenticationService,
    public router: Router,
    public route: ActivatedRoute,
    formBuilder: FormBuilder) {

    super(_service, translate, _authenticationService, router, route, false);

    this.form = formBuilder.group({
      nome: ['', [
        Validators.required,
        Validators.minLength(3)
      ]],
      sigla: ['', [
        Validators.required,
        Validators.minLength(2),
        Validators.maxLength(3),
      ]]
    });

    this.title = Menu.getHierarquiaByKey('menu_estado');
  }

  ngOnInit() {
    this._authenticationService.isLogged().subscribe(el => {
      if (el === true) {
        super.ngOnInit();
      }
    });
  }

  public afterGet(data: any) {
    this.estado = data.object;
  }

  public save() {
    this._authenticationService.isLogged().subscribe(el => {
      if (el === true) {
        super.saveOrUpdate(this.estado.estado_id, this.estado);

      }
    });
  }

  public afterSave(responseEntity: MxResponseEntity) {
    super.afterSave(responseEntity);
    let _o = (responseEntity.object as any);

    let url = this.URL_EDIT + _o.estado_id;
    this.router.navigate([url]);
  }

}
