import { Component, OnInit } from '@angular/core';
import { MxResponseEntity } from 'mx-core';
import { TranslateService } from '@ngx-translate/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';


import { LoggedCrudController } from '../../../../shared/guard/logged-crud-controller';
import { Cep } from '../../../../shared/entity/cep';
import { CepService } from '../../../../service/cep.service';
import { AuthenticationService } from '../../../../service/security/authentication.service';
import { Menu } from '../../../../layout/template/menu';
import { SharedDataService } from '../../../../shared/data/shared-data.service';

@Component({
  selector: 'app-cep-form',
  templateUrl: './cep-form.component.html',
  styleUrls: ['./cep-form.component.css']
})
export class CepFormComponent extends LoggedCrudController<Cep> implements OnInit {

  cep: Cep = new Cep();
  form: FormGroup;

  URL_LIST: String = "/modules/general/cep/cep-list";
  URL_EDIT: String = "/modules/general/cep/cep-form/";

  title: String = '';

  constructor(public _service: CepService,
    public translate: TranslateService,
    protected _authenticationService: AuthenticationService,
    public router: Router,
    public route: ActivatedRoute,
    formBuilder: FormBuilder,
    private _sharedDataService: SharedDataService) {

    super(_service, translate, _authenticationService, router, route, false);

    this.form = formBuilder.group({
      nome: ['', [
        Validators.required,
        Validators.minLength(3),
      ]],
      codigoPostal: ['', [
        Validators.required,
        Validators.minLength(8),
      ]],
      bairro: ['', [
        Validators.required
      ]]
    });

    this.title = Menu.getHierarquiaByKey('menu_cep', this._sharedDataService.menus.value);
  }

  ngOnInit() {
    this._authenticationService.isLogged().subscribe(el => {
      if (el === true) {
        super.ngOnInit();
      }
    });
  }

  public afterGet(data: any) {
    this.cep = data.object;
  }

  public save() {
    this._authenticationService.isLogged().subscribe(el => {
      if (el === true) {
        super.saveOrUpdate(this.cep.cep_id, this.cep);
      }
    });
  }

  public afterSave(responseEntity: MxResponseEntity) {
    super.afterSave(responseEntity);
    let _o = (responseEntity.object as any);

    let url = this.URL_EDIT + _o.cep_id;
    this.router.navigate([url]);
  }

}
