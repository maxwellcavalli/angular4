import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CepListComponent } from './cep-list/cep-list.component';
import { CepFormComponent } from './cep-form/cep-form.component';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../../../shared/shared.module';
import { AutoCompleteModule } from '../../../shared/components/auto-complete/auto-complete.module';

const routes: Routes = [
  {
    path: '',
    children: [
      { path: 'cep-list', component: CepListComponent },
      { path: 'cep-form/new', component: CepFormComponent },
      { path: 'cep-form/:id', component: CepFormComponent }
    ]
  }
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    SharedModule,
    AutoCompleteModule
  ],
  declarations: [CepListComponent, CepFormComponent]
})
export class CepModule { }
