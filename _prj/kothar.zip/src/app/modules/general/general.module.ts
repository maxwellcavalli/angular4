import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { GeneralRoutingModule } from './general-routing.module';

@NgModule({
  imports: [
    CommonModule,
    GeneralRoutingModule
  ],
  declarations: []
})
export class GeneralModule { }
