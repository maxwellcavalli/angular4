import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';

import { SharedModule } from '../../../shared/shared.module';
import { GrupoProdutoListComponent } from './grupo-produto-list/grupo-produto-list.component';
import { GrupoProdutoFormComponent } from './grupo-produto-form/grupo-produto-form.component';
import { AutoCompleteModule } from '../../../shared/components/auto-complete/auto-complete.module';

const routes: Routes = [
  {
    path: '',
    children: [
      { path: 'grupo-produto-list', component: GrupoProdutoListComponent },
      { path: 'grupo-produto-form/new', component: GrupoProdutoFormComponent },
      { path: 'grupo-produto-form/:id', component: GrupoProdutoFormComponent }
    ]
  }
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    SharedModule,

    AutoCompleteModule
  ],
  declarations: [GrupoProdutoListComponent, GrupoProdutoFormComponent]
})
export class GrupoProdutoModule { }
