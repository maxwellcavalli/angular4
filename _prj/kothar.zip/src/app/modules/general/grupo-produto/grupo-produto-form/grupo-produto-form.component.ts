import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import { Router, ActivatedRoute } from '@angular/router';

import { AuthenticationService } from '../../../../service/security/authentication.service';
import { MxResponseEntity } from 'mx-core';
import { GrupoProdutoService } from '../../../../service/grupo-produto.service';
import { GrupoProduto } from '../../../../shared/entity/grupo-produto';
import { LoggedCrudController } from '../../../../shared/guard/logged-crud-controller';
import { Menu } from '../../../../layout/template/menu';

@Component({
  selector: 'app-grupo-produto-form',
  templateUrl: './grupo-produto-form.component.html',
  styleUrls: ['./grupo-produto-form.component.css']
})
export class GrupoProdutoFormComponent extends LoggedCrudController<GrupoProduto> implements OnInit {

  URL_LIST: String = "/modules/general/grupo-produto/grupo-produto-list";
  URL_EDIT: String = "/modules/general/grupo-produto/grupo-produto-form/";

  grupoProduto: GrupoProduto = new GrupoProduto();
  form: FormGroup;

  title: String = '';

  constructor(public _service: GrupoProdutoService,
    public translate: TranslateService,
    protected _authenticationService: AuthenticationService,
    public router: Router,
    public route: ActivatedRoute,
    formBuilder: FormBuilder) {

    super(_service, translate, _authenticationService, router, route, false);

    this.form = formBuilder.group({
      nome: ['', [
        Validators.required,
        Validators.minLength(3)
      ],
      ],
      parentGroup: ['', []]
    });
    this.title = Menu.getHierarquiaByKey('menu_grupo_produto');
  }

  ngOnInit() {
    super.ngOnInit();
  }

  public afterGet(data: any) {
    this.grupoProduto = data.object;
  }

  public save() {
    let grupoParent = this.grupoProduto.grupo_produto_parent;
    if (typeof grupoParent === 'string') {
      this.grupoProduto.grupo_produto_parent = null;
    }

    super.saveOrUpdate(this.grupoProduto.grupo_produto_id, this.grupoProduto);
  }

  public afterSave(responseEntity: MxResponseEntity) {
    super.afterSave(responseEntity);
    let _o = (responseEntity.object as any);

    let url = this.URL_EDIT + _o.grupo_produto_id;
    this.router.navigate([url]);
  }

}
