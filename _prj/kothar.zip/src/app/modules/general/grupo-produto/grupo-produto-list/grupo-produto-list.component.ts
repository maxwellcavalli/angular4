import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { BehaviorSubject } from 'rxjs';
import { MxDataTableComponent } from 'mx-components';


import { LoggedCrudController } from '../../../../shared/guard/logged-crud-controller';
import { GrupoProduto } from '../../../../shared/entity/grupo-produto';
import { GrupoProdutoService } from '../../../../service/grupo-produto.service';
import { TranslateService } from '@ngx-translate/core';
import { AuthenticationService } from '../../../../service/security/authentication.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Menu } from '../../../../layout/template/menu';

@Component({
  selector: 'app-grupo-produto-list',
  templateUrl: './grupo-produto-list.component.html',
  styleUrls: ['./grupo-produto-list.component.css']
})
export class GrupoProdutoListComponent extends LoggedCrudController<GrupoProduto> {

  @ViewChild('table') _table: MxDataTableComponent;

  URL_LIST: String = "/modules/general/grupo-produto/grupo-produto-list";
  URL_EDIT: String = "/modules/general/grupo-produto/grupo-produto-form/";
  FILTER_KEY: string = "grupo_produto_filter"

  filtroNome: String = '';

  form: FormGroup;

  rows: BehaviorSubject<any> = new BehaviorSubject<any>(null);
  cols: any;

  title: String = '';

  ngOnInit() {
    this._authenticationService.isLogged().subscribe(el => {
      if (el === true) {
        super.ngOnInit();

        this.cols = [
          { prop: 'grupo_produto_nome', title: this.translate.instant('GEN.NAME'), sortable: true, selectable: true },
          { prop: 'grupo_produto_parent.grupo_produto_nome', title: this.translate.instant('PRODUCT.GROUP.PARENT'), sortable: true, selectable: true },
          { prop: 'grupo_produto_id', title: this.translate.instant('GEN.ACTION'), maxWidth: 30, sortable: false, cellTemplate: this._table.cellDeleteButton }
        ];

        this.createDefaultSearchListener();

      }
    });
  }

  ngOnDestroy() {
    this.rows.unsubscribe();
  }

  constructor(public _service: GrupoProdutoService,
    public translate: TranslateService,
    protected _authenticationService: AuthenticationService,
    public router: Router,
    public route: ActivatedRoute,
    formBuilder: FormBuilder) {

    super(_service, translate, _authenticationService, router, route, false);
    super.reloadFilterL(null);

    this.form = formBuilder.group({
      nome: ['', []],
    });



    this.title = Menu.getHierarquiaByKey('menu_grupo_produto');
  }

  onUpdateFilterValue(value: any): void {
    this.filtroNome = value;
  }

  onGetFilterKey(): string {
    return this.FILTER_KEY;
  };

  onPopulateTable(dados: Array<any>) {
    this.rows.next(dados);
  }

  onGetFilterValue(): any {
    if (this.filtroNome) {
      return this.filtroNome;
    } else {
      return super.onGetFilterValue();
    }
  }

  public edit(event) {
    let object = event.row;
    let url = this.URL_EDIT + object.grupo_produto_id;
    this.router.navigate([url]);
  }

  public searchEvent(event: any) {
    this._authenticationService.isLogged().subscribe(el => {
      if (el === true) {
        super.searchEvent(event);
      }
    });

  }

  reset(event) {
    this.oldValue = null;

    this.filtroNome = '';
    this.searchEvent(event);
  }

  public add(event) {
    this._authenticationService.isLogged().subscribe(el => {
      if (el === true) {
        let url = this.URL_EDIT + "/new";
        this.router.navigate([url]);

      }
    });
  }
}