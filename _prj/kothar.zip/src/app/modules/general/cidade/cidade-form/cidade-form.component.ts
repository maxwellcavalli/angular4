import { Component, OnInit } from '@angular/core';
import { MxResponseEntity } from 'mx-core';
import { TranslateService } from '@ngx-translate/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';

import { Cidade } from '../../../../shared/entity/cidade';
import { LoggedCrudController } from '../../../../shared/guard/logged-crud-controller';
import { CidadeService } from '../../../../service/cidade.service';
import { AuthenticationService } from '../../../../service/security/authentication.service';
import { Menu } from '../../../../layout/template/menu';

@Component({
  selector: 'app-cidade-form',
  templateUrl: './cidade-form.component.html',
  styleUrls: ['./cidade-form.component.css']
})
export class CidadeFormComponent extends LoggedCrudController<Cidade> implements OnInit {

  cidade: Cidade = new Cidade();
  form: FormGroup;

  URL_LIST: String = "/modules/general/cidade/cidade-list";
  URL_EDIT: String = "/modules/general/cidade/cidade-form/";

  title: String = '';

  constructor(public _service: CidadeService,
    public translate: TranslateService,
    protected _authenticationService: AuthenticationService,
    public router: Router,
    public route: ActivatedRoute,
    formBuilder: FormBuilder) {

    super(_service, translate, _authenticationService, router, route, false);

    this.form = formBuilder.group({
      nome: ['', [
        Validators.required,
        Validators.minLength(3)
      ]],
      estado: ['', [
        Validators.required
      ]]
    });

    this.title = Menu.getHierarquiaByKey('menu_cidade');
  }

  ngOnInit() {
    this._authenticationService.isLogged().subscribe(el => {
      if (el === true) {
        super.ngOnInit();
      }
    });
  }

  public afterGet(data: any) {
    this.cidade = data.object;
  }

  public save() {
    this._authenticationService.isLogged().subscribe(el => {
      if (el === true) {
        super.saveOrUpdate(this.cidade.cidade_id, this.cidade);

      }
    });
  }

  public afterSave(responseEntity: MxResponseEntity) {
    super.afterSave(responseEntity);
    let _o = (responseEntity.object as any);

    let url = this.URL_EDIT + _o.cidade_id;
    this.router.navigate([url]);
  }

}
