import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { BehaviorSubject } from 'rxjs';
import { MxDataTableComponent } from 'mx-components';
import { TranslateService } from '@ngx-translate/core';
import { Router, ActivatedRoute } from '@angular/router';

import { LoggedCrudController } from '../../../../shared/guard/logged-crud-controller';
import { Cidade } from '../../../../shared/entity/cidade';
import { CidadeService } from '../../../../service/cidade.service';
import { AuthenticationService } from '../../../../service/security/authentication.service';
import { Menu } from '../../../../layout/template/menu';
import { SharedDataService } from '../../../../shared/data/shared-data.service';

@Component({
  selector: 'app-cidade-list',
  templateUrl: './cidade-list.component.html',
  styleUrls: ['./cidade-list.component.css']
})
export class CidadeListComponent extends LoggedCrudController<Cidade> {

  URL_LIST: String = "/modules/general/cidade/cidade-list";
  URL_EDIT: String = "/modules/general/cidade/cidade-form/";

  FILTER_KEY: string = "cidade_filter"

  form: FormGroup;

  filtroCidade: String = '';
  filtroEstado: String = '';

  title: String = '';

  rows: BehaviorSubject<any> = new BehaviorSubject<any>(null);
  cols: any;

  @ViewChild('table') _table: MxDataTableComponent;

  constructor(public _service: CidadeService,
    public translate: TranslateService,
    protected _authenticationService: AuthenticationService,
    public router: Router,
    public route: ActivatedRoute,
    formBuilder: FormBuilder,
    private _sharedDataService: SharedDataService) {
    super(_service, translate, _authenticationService, router, route, false);

    super.reloadFilterL(null);


    this.form = formBuilder.group({
      cidade: ['', []],
      estado: ['', []]
    });

    this.title = Menu.getHierarquiaByKey('menu_cidade', this._sharedDataService.menus.value);
  }

  ngOnInit() {
    this._authenticationService.isLogged().subscribe(el => {
      if (el === true) {
        super.ngOnInit();

        this.pageFilterN.subscribe(_filter => {
          this.isFilterUpdatedP();

          _filter.filterValue = this.onGetFilterValue();
          this.onSaveFilter();

          this._service.searchComplex(_filter).subscribe(
            _ret => {
              this.afterSearch(_ret);
              let _dados = (_ret.object as any).content;

              this.onPopulateTable(_dados as Array<any>)
            },
            response => {
              this.afterResponse(response);
            });
        });

        this.cols = [
          { prop: 'cidade_estado.estado_nome', title: this.translate.instant('CIDADE.ESTADO'), sortable: true, selectable: true, maxWidth: 200 },
          { prop: 'cidade_nome', title: this.translate.instant('GEN.NAME'), sortable: true, selectable: true },
          { prop: 'cidade_id', title: this.translate.instant('GEN.ACTION'), maxWidth: 30, sortable: false, cellTemplate: this._table.cellDeleteButton }
        ];

      }
    });
  }

  ngOnDestroy() {
    this.rows.unsubscribe();
  }

  onUpdateFilterValue(value: any): void {
    this.filtroCidade = value.cidade;
    this.filtroEstado = value.estado;
  }

  onGetFilterKey(): string {
    return this.FILTER_KEY;
  };

  onPopulateTable(dados: Array<any>) {
    this.rows.next(dados);
  }

  onGetFilterValue(): any {
    let filterValue = {
      cidade: this.filtroCidade,
      estado: this.filtroEstado
    }

    return filterValue;
  }

  public reset(event) {
    this.oldValue = null;

    this.filtroCidade = '';
    this.filtroEstado = '';
    this.searchEvent(event);
  }

  public searchEvent(event: any) {
    this._authenticationService.isLogged().subscribe(el => {
      if (el === true) {
        super.searchEvent(event);
      }
    });
  }

  public edit(event) {
    let object = event.row;
    let url = this.URL_EDIT + object.cidade_id;
    this.router.navigate([url]);
  }

  public add(event) {
    this._authenticationService.isLogged().subscribe(el => {
      if (el === true) {
        let url = this.URL_EDIT + "/new";
        this.router.navigate([url]);
      }
    });
  }
}
