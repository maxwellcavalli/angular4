import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CidadeFormComponent } from './cidade-form/cidade-form.component';
import { CidadeListComponent } from './cidade-list/cidade-list.component';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../../../shared/shared.module';

import { AutoCompleteModule } from '../../../shared/components/auto-complete/auto-complete.module';

const routes: Routes = [
  {
    path: '',
    children: [
      { path: 'cidade-list', component: CidadeListComponent },
      { path: 'cidade-form/new', component: CidadeFormComponent },
      { path: 'cidade-form/:id', component: CidadeFormComponent }
    ]
  }
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    SharedModule,

    AutoCompleteModule
  ],
  declarations: [CidadeFormComponent, CidadeListComponent]
})
export class CidadeModule { }
