import { Component, OnInit, ViewChild, ChangeDetectorRef } from '@angular/core';
import { LoggedCrudController } from '../../../../shared/guard/logged-crud-controller';
import { Fornecedor } from '../../../../shared/entity/fornecedor';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { BehaviorSubject } from 'rxjs';
import { MxDataTableComponent } from 'mx-components';
import { MxResponseEntity } from 'mx-core';
import { Router, ActivatedRoute } from '@angular/router';

import { Cliente } from '../../../../shared/entity/cliente';
import { FornecedorService } from '../../../../service/fornecedor.service';
import { TranslateService } from '@ngx-translate/core';
import { AuthenticationService } from '../../../../service/security/authentication.service';
import { GrupoProdutoService } from '../../../../service/grupo-produto.service';
import { ClienteFornecedor } from '../../../../shared/entity/cliente-fornecedor';
import { EnderecoComplemento } from '../../../../shared/entity/endereco-complemento';
import { GrupoProduto } from '../../../../shared/entity/grupo-produto';

import { MxTreeViewComponent } from 'mx-components';
import { Menu } from '../../../../layout/template/menu';
import { SharedDataService } from '../../../../shared/data/shared-data.service';

@Component({
	selector: 'app-fornecedor-form',
	templateUrl: './fornecedor-form.component.html',
	styleUrls: ['./fornecedor-form.component.css']
})
export class FornecedorFormComponent extends LoggedCrudController<Fornecedor> implements OnInit {

	URL_LIST: String = "/modules/general/fornecedor/fornecedor-list";
	URL_EDIT: String = "/modules/general/fornecedor/fornecedor-form/";

	fornecedor: Fornecedor = new Fornecedor();
	form: FormGroup;

	@ViewChild("treeview") treeview: MxTreeViewComponent;

	nodes: BehaviorSubject<any> = new BehaviorSubject<any>(null);
	rows: BehaviorSubject<any> = new BehaviorSubject<any>(null);
	cols: any;
	@ViewChild('table') _table: MxDataTableComponent;

	admin: boolean = false;

	cliente: Cliente;
	title: string = '';


	ngOnInit() {
		let _user = this._authenticationService.getUser();
		this.admin = _user.admin;

		this._authenticationService.isLogged().subscribe(el => {
			if (el === true) {
				super.ngOnInit();

				if (this.admin) {
					this.createDataTable();
				}
			}
		});
	}

	constructor(public _service: FornecedorService,
		public translate: TranslateService,
		protected _authenticationService: AuthenticationService,
		public router: Router,
		public route: ActivatedRoute,
		formBuilder: FormBuilder,
		private _grupoProdutoService: GrupoProdutoService,
		private cdr: ChangeDetectorRef,
		private _sharedDataService: SharedDataService) {

		super(_service, translate, _authenticationService, router, route, false);

		this.form = formBuilder.group({
			nome: ['', [
				Validators.required,
				Validators.minLength(3)
			]],
			cpf_cnpj: ['', [
				Validators.required
			]],
			cep: ['', [
				Validators.required
			]],
			telefone: ['', [
				Validators.required,
				Validators.minLength(10)
			]],
			email: ['', [
				Validators.required,
				Validators.minLength(10)
			]],
			cliente: ['', []],
			identificador: [{ value: null, disabled: false }, []]
		});

		if (!this.editing) {
			this.loadTree();
		}

		this.title = Menu.getHierarquiaByKey('menu_fornecedor', this._sharedDataService.menus.value);
	}

	ngOnDestroy() {
		this.rows.unsubscribe();
	}

	private createDataTable() {
		this.cols = [
			{ prop: 'cliente.cliente_nome', title: this.translate.instant('GEN.NAME') },
			{ prop: 'cliente.cpf_format', title: this.translate.instant('FORNECEDOR.CLIENTE.CPF'), maxWidth: 180, hideOnMobile: true },
			{ prop: 'internalIndex', title: this.translate.instant('GEN.ACTION'), maxWidth: 30, sortable: false, cellTemplate: this._table.cellDeleteButton }
		];
	}

	deleteCliente(event) {
		let _clientes = this.rows.value;

		let index = -1;
		for (let x = 0; x < _clientes.length; x++) {
			if (_clientes[x].internalIndex === event.value) {
				index = x;
				break;
			}
		}

		if (index > -1) {
			_clientes.splice(index, 1);

			this.rows.next(_clientes);
		}
	}

	vincularCliente() {
		if (typeof this.cliente !== 'object') {
			alert(this.translate.instant('FORNECEDOR.CLIENTE.INVALID'));
			this.cliente = null;
		} else {
			let _clientes = this.rows.value;

			let hasCliente = false;
			for (let x of _clientes) {
				if (x.cliente.cliente_id === this.cliente.cliente_id) {
					hasCliente = true;
					break;
				}
			}

			if (hasCliente === true) {
				alert(this.translate.instant('FORNECEDOR.CLIENTE.DUPLICATED'));
				this.cliente = null;
			} else {
				let rf = new ClienteFornecedor();
				rf.cliente = this.cliente;
				rf.internalIndex = _clientes.length + 1;

				_clientes.push(rf);

				this.cliente = null;

				this.rows.next(_clientes);
			}
		}
	}

	private enderecoComplemento() {
		this.fornecedor.fornecedor_cep.endereco_complemento = this.fornecedor.fornecedor_endereco;
		if (!this.fornecedor.fornecedor_cep.endereco_complemento) {
			this.fornecedor.fornecedor_cep.endereco_complemento = new EnderecoComplemento();
		}
	}

	private populateClientes() {
		if (this.admin) {
			if (this.fornecedor.clientes) {
				let internalIndex = 0;
				for (let x of this.fornecedor.clientes) {
					x.internalIndex = internalIndex++;
				}

				this.rows.next(this.fornecedor.clientes);
			}
		}
	}

	public afterGet(data: any) {
		this.fornecedor = data.object;
		this.populateClientes();

		this.enderecoComplemento();

		if (this.editing)
			this.loadTree();

		this.cdr.detectChanges();
	}

	public save() {
		this._authenticationService.isLogged().subscribe(el => {
			if (el === true) {
				let cep = this.fornecedor.fornecedor_cep
				this.fornecedor.fornecedor_endereco = cep.endereco_complemento;

				let selectedGrupoTree = new Array<GrupoProduto>()
				let selecteds = this.treeview.getAllSelected(false);
				for (let x of selecteds) {
					selectedGrupoTree.push(x.object);
				}

				this.fornecedor.fornecedor_grupo = selectedGrupoTree;
				super.saveOrUpdate(this.fornecedor.fornecedor_id, this.fornecedor);

			}
		});
	}

	protected afterUpdate(data) {
		super.defaultUpdateMessage();
		this.afterGet(data);
	}

	public afterSave(responseEntity: MxResponseEntity) {
		super.afterSave(responseEntity);
		let _o = (responseEntity.object as any);

		this.fornecedor = _o;

		let url = this.URL_EDIT + _o.fornecedor_id;
		this.router.navigate([url]);
	}

	private loadTree() {
		this._grupoProdutoService.getGrouped().subscribe(data => {
			let grupoTree = data.object;

			if (this.fornecedor.fornecedor_grupo) {
				for (let g of grupoTree) {
					this.processGroups(g);
				}
			}

			let _nodes = [];
			for (let grupo of grupoTree) {
				let tree = this.createTreeViewData(grupo);
				_nodes.push(tree);
			}

			this.nodes.next(_nodes);
		});
	}

	private createTreeViewData(grupo: GrupoProduto): any {
		let tree = {
			id: grupo.grupo_produto_id,
			name: grupo.grupo_produto_nome,
			expanded: false,
			children: [],
			checked: grupo.selecionado,
			object: grupo,
			indeterminate: false
		};

		if (grupo.grupo_produto_children) {
			for (let child of grupo.grupo_produto_children) {
				let treeChild = this.createTreeViewData(child);
				tree.children.push(treeChild);
			}
		}

		return tree;
	}

	private processGroups(grupoProduto: GrupoProduto): void {
		let selecionado = false;
		for (let x of this.fornecedor.fornecedor_grupo) {
			if (x.grupo_produto_id === grupoProduto.grupo_produto_id) {
				selecionado = true;
				break;
			}
		}

		if (selecionado) {
			grupoProduto.selecionado = true;
		}

		for (let child of grupoProduto.grupo_produto_children) {
			this.processGroups(child);
		}
	}
}
