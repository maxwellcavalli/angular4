import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FornecedorListComponent } from './fornecedor-list/fornecedor-list.component';
import { FornecedorFormComponent } from './fornecedor-form/fornecedor-form.component';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../../../shared/shared.module';
import { AutoCompleteModule } from '../../../shared/components/auto-complete/auto-complete.module';
import { PainelCepModule } from '../../../shared/components/painel-cep/painel-cep.module';

const routes: Routes = [
  {
    path: '',
    children: [
      { path: 'fornecedor-list', component: FornecedorListComponent },
      { path: 'fornecedor-form/new', component: FornecedorFormComponent },
      { path: 'fornecedor-form/:id', component: FornecedorFormComponent }
    ]
  }
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    SharedModule,
    AutoCompleteModule,
    PainelCepModule
    
  ],
  declarations: [FornecedorListComponent, FornecedorFormComponent]
})
export class FornecedorModule { }
