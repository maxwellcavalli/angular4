export class MxCustomSort {
    field: string = '';
    direction: string;
  }