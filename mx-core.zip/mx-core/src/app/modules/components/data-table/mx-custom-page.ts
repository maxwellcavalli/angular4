export class MxCustomPage {
  recordCount: number = 0;
  pageIndex: number = 0;
  pageSize: number = 10;
  pageSizeOptions: Array<number> = [5, 10, 25, 100];
}