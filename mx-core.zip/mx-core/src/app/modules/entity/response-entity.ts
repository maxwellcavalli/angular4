export class MxResponseEntity {
    object: object;
    errorMessage: string;
}
