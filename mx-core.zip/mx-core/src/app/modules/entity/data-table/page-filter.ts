import { MxPage } from "./page";
import { MxSort } from "./sort";

export class MxPageFilter {
    filterValue: any = '';
    page: MxPage = new MxPage();
    sort: MxSort = new MxSort();
}