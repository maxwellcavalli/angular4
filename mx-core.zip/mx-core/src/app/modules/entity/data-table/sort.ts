export class MxSort {
    propertyName: string;
    orderType: string;

}