export abstract class MxBaseEntity {

}