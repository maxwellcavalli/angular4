# MxComponents
This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 1.4.6.
