//export * from './src/app/modules/shared/shared.module'

export * from './src/app/modules/components/data-table'
export * from './src/app/modules/controller'
export * from './src/app/modules/entity'
export * from './src/app/modules/service'
